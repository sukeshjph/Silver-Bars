const path = require('path');
const webpack = require('webpack');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const LodashModuleReplacementPlugin = require('lodash-webpack-plugin');

function generateConfig(entry, srcPath, env, plugins = []) {
    const isProd = env === 'production';
    const commonPlugins = [
        new webpack.DefinePlugin({
            PRODUCTION: JSON.stringify(isProd),
        }),
        new LodashModuleReplacementPlugin({
            shorthands: true,
            collections: true,
            paths: true,
        }), // only includes used features of lodash
        new webpack.IgnorePlugin(/^\.\/locale$/, /moment$/), // removes momentjs locale,
    ];

    return {
        entry,
        mode: env,
        externals: {},
        output: {
            path: path.join(srcPath, 'dist'),
            filename: !isProd ? '[name].bundle.js' : '[name].[contenthash:4].js', // hashed files in prod invalidating cache after new build
            chunkFilename: !isProd ? '[name].chunk.js' : '[name].[chunkhash:4].chunk.js',
        },
        plugins: [...commonPlugins, ...plugins],
        resolve: {
            modules: [path.resolve('./src'), path.resolve('./node_modules')],
            extensions: ['.js', '.jsx', '.ts', '.tsx', '.json'],
        },
        module: {
            rules: [
                {
                    test: /\.(js|jsx|ts|tsx)$/,
                    include: [/node_modules\/sabre-js-common/, /src/],
                    use: ['babel-loader', 'eslint-loader'],
                },
                {
                    test: /\.(eot|ttf|woff|otf|woff2)$/,
                    use: {
                        loader: 'file-loader?name=/fonts/[name].[ext]',
                        options: {
                            name: 'assets/fonts/[name].[ext]',
                        },
                    },
                },
                {
                    test: /\.(jpg|svg|png|gif|jpeg)$/,
                    use: {
                        loader: 'file-loader?name=/images/[name].[ext]',
                        options: {
                            name: !isProd
                                ? 'assets/images/[name].[ext]'
                                : 'assets/images/[name].[ext]?[hash:4]', // hashed files to invalidate cache after new build
                        },
                    },
                },
                {
                    test: /\.scss$/,
                    use: [
                        isProd ? MiniCssExtractPlugin.loader : 'style-loader',
                        'css-loader',
                        'sass-loader',
                    ],
                },
                {
                    test: /\.css$/,
                    use: [isProd ? MiniCssExtractPlugin.loader : 'style-loader', 'css-loader'],
                },
            ],
        },
        optimization: {
            runtimeChunk: 'single',
            splitChunks: {
                maxInitialRequests: Infinity,
                minSize: 0,
                cacheGroups: {
                    default: false,
                    vendors: false,
                    vendor: {
                        test: /[\\/]node_modules[\\/]/,
                        name(module) {
                            // get the name. E.g. node_modules/packageName
                            const packageName = module.context.match(
                                /[\\/]node_modules[\\/](.*?)([\\/]|$)/,
                            )[1];
                            return `npm.${packageName.replace('@', '')}`;
                        },
                    } /* extract packages like Material-UI,Lodash separate files to share between async chunks(de-duplication)*/,
                    styles: {
                        minSize: 0,
                        test: /\.css$/,
                    }, // css caching
                },
            },
        },
    };
}

module.exports = generateConfig;
