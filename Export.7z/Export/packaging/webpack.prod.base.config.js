const webpack = require('webpack');
// const UglifyJsPlugin = require('uglifyjs-webpack-plugin');
const TerserPlugin = require('terser-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const OptimizeCssAssetsPlugin = require('optimize-css-assets-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');

const prodConfig = {
    devtool: false,
    optimization: {
        minimize: true,
        minimizer: [
            new TerserPlugin({
                cache: true,
                parallel: true,
                sourceMap: true,
                terserOptions: {
                    output: {
                        comments: false,
                    },
                },
            }),
        ],
        usedExports: true,
        sideEffects: true,
    },
};

const prodPlugins = [
    new HtmlWebpackPlugin({
        template: './src/index.html',
        inject: true,
        hash: true,
        filename: 'index.html',
    }),
    new webpack.HashedModuleIdsPlugin(),
    new webpack.DefinePlugin({
        ISLOCAL: JSON.stringify(false),
        'process.env.NODE_ENV': JSON.stringify('production'),
    }),
    new webpack.optimize.AggressiveMergingPlugin(),
    new MiniCssExtractPlugin({
        filename: '[name].[contenthash:4].css',
    }), // Extract css files in Prod to allow browser caching
    new OptimizeCssAssetsPlugin(),
];

module.exports = {
    config: prodConfig,
    plugins: prodPlugins,
};

/* new webpack.optimize.ModuleConcatenationPlugin(), : Scope hoisting didn't work with code splitting 
   new webpack.SourceMapDevToolPlugin({
                test: [/\.js$/],
                exclude: 'vendor',
                filename: 'app.[hash].js.map',
                append: '//# sourceMappingURL=[url]',
                moduleFilenameTemplate: '[resource-path]',
                fallbackModuleFilenameTemplate: '[resource-path]',
            }) : Use to enable Sourcemaps in Production(Doesn't produce full sourcemaps currently)
*/
