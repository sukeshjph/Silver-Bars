import _ from 'lodash';

export default (filterText, dataSet, propertyName) => {
    const searchString = filterText.trim();

    if (searchString === '') {
        return dataSet;
    }
    const regEx = new RegExp(searchString, 'gi');

    if (propertyName) {
        return _.filter(dataSet, dataItem => _.includes(dataItem[propertyName].toLowerCase(), filterText.toLowerCase()));
    }

    return dataSet.filter(item =>
        Object.keys(item)
            .map(key => item[key] ? item[key].toString():item[key])
            .some(_.method('match', regEx))
    );
};
