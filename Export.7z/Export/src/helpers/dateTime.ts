/* eslint-disable no-restricted-globals */

import moment from 'moment';

const DATE_FORMAT = 'DD MMM YYYY';
const DATE_TIME_FORMAT = 'DD MMM YYYY HH:mm';
const PARSING_DATE_TIME_FORMAT = 'YYYYMMDDHHmmss'; // '20170511144901'

export const now = () => moment().format(PARSING_DATE_TIME_FORMAT);

export const gridDateSorter = (date1, date2) => {
    const date1millis = moment(date1, DATE_TIME_FORMAT).valueOf();
    const date2millis = moment(date2, DATE_TIME_FORMAT).valueOf();

    if (isNaN(date1millis) && isNaN(date2millis)) {
        return 0;
    }
    if (isNaN(date1millis)) {
        return -1;
    }
    if (isNaN(date2millis)) {
        return 1;
    }
    return date1millis - date2millis;
};

export const formatDateTime = value =>
    moment(value, PARSING_DATE_TIME_FORMAT).format(DATE_TIME_FORMAT);

export const formatDate = value => {
    if (value) {
        return moment(value, PARSING_DATE_TIME_FORMAT).format(DATE_FORMAT);
    }
    return null;
};

