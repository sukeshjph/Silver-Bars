import _ from 'lodash';
import { BATCH_SORT_ORDER } from '../components/batchManager/batchManagerConstants';

export default (batches) =>
    _.compact(_.map(BATCH_SORT_ORDER, (batchName) => _.find(batches, batch => batch.name === batchName)));