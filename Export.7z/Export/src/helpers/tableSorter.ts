import _ from 'lodash';

export const tableSorter = (state, orderBy, sortItems) => {
    let order = 'asc';
    const data = _.sortBy(state[sortItems], orderBy);
    if (state.orderBy === orderBy && state.order === 'asc') {
        order = 'desc';
        _.reverse(data);
    }
    return { data, order, orderBy };
};