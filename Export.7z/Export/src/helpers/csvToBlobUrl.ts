import * as Papa from 'papaparse';

export const csvToBlobUrl = (csv) => {
    if (!csv) {
        return false;
    }
    const csvAsString = Papa.unparse(csv);
    return window.URL.createObjectURL(new Blob([csvAsString], {type : 'text/csv'}));
};