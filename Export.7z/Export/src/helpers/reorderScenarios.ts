import _ from 'lodash';
import getAffectedBatches from './getAffectedBatches';
import { BATCH_SORT_ORDER } from '../components/batchManager/batchManagerConstants';

const setPendingProperty = (pending, scenario) => {
    const match = _.find(pending, { ukId: scenario.ukId});
    if (match) {
        return {
            ...scenario,
            pending: true,
        }
    }
    return scenario;
};

const setAffectedBatchesProperty = (batches, scenario) =>({
    ...scenario,
    affectedBatches: _.map(getAffectedBatches(batches, scenario, true), batch => {
        // Reduce days of the week to three characters
        if (_.includes(BATCH_SORT_ORDER.slice(0, 5), batch)) {
            return batch.substr(0, 3);
        }
        return batch;
    }).join(', '),
});


const setTagsProperty = scenario =>({
    ...scenario,
    tags: scenario.tags ? scenario.tags.split(', ') : '',
});



// Iterate through scenarios
// - update a scenario that has a pending item awaiting approval.
// - update a scenario that exists in a batch
// - convert tags field to array
// Finally, sort them by name.
export default (scenarios, pendingScenarios, batches) =>
    _.sortBy(
        _.map(scenarios, scenario => {
            let updatedScenario = scenario;
            updatedScenario = setPendingProperty(pendingScenarios, updatedScenario);
            updatedScenario = setAffectedBatchesProperty(batches, updatedScenario);
            updatedScenario = setTagsProperty(updatedScenario);
            return updatedScenario;
        }),
        ['name']
    );