import React from 'react';
import { HashRouter as Router } from 'react-router-dom';
import http from './helpers/http';
import { initialise } from './common/config';
import { StressTestingContainer } from './components';

class App extends React.Component {
    state = {
        hasConfigLoaded: false,
    };

    async componentDidMount() {
        try {
            const configJson = await http.getConfigFromServer();
            if (Object.keys(configJson).length !== 0) {
                initialise(configJson);
                this.setState({ hasConfigLoaded: true });
            } else {
                throw new Error('no config found');
            }
        } catch (error) {
            console.log(error.message); //eslint-disable-line
        }
    }

    render() {
        const { hasConfigLoaded } = this.state;

        return (
            hasConfigLoaded && (
                <Router>
                    <StressTestingContainer />
                </Router>
            )
        );
    }
}

export default App;
