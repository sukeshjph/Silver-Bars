/* do operator has been replaced by tap in Rxjs 6.5 */
import { of } from 'rxjs';
import {
    mergeMap,
    catchError,
    filter,
    map,
    tap,
    ignoreElements,
    withLatestFrom,
} from 'rxjs/operators';
import { combineEpics, Epic, StateObservable } from 'redux-observable';
import { isActionOf, RootState } from 'typesafe-actions';
import { AllOtherRootActionsType } from '../interfaces/globals';
import * as AllActions from '../actions';
import { getConfig } from '../common/config';
import * as authentication from '../helpers/authentication';
import http from '../helpers/http';

const fetchFilesToCompare: Epic<AllOtherRootActionsType> = action$ =>
    action$.pipe(
        filter(isActionOf(AllActions.fetchDiff)),
        mergeMap(action => {
            const { ukId, file, fileVersionToCompare } = action.payload;
            return http
                .getData(
                    `${
                        getConfig().SdxService
                    }/batchmanagement/Scenario/fileCompare?ukId=${ukId}&fileVersion=${file}&fileVersion2=${fileVersionToCompare}`,
                )
                .pipe(
                    map(diff => AllActions.fetchDiffComplete(diff, ukId)),
                    catchError(err =>
                        of(
                            AllActions.fetchDiffErrors({
                                error: `An error has occurred. The files cannot be compared.\n ${
                                    err.message
                                }`,
                            }),
                        ),
                    ),
                );
        }),
    );

const signIn: Epic<AllOtherRootActionsType> = (
    action$
) =>
    action$.pipe(
        filter(isActionOf(AllActions.signIn)),
        mergeMap(action =>
            authentication.signIn(action.payload.username, action.payload.password).pipe(
                map(uvaData =>
                    AllActions.signInComplete({
                        uvaData,
                    }),
                ),
                catchError(error => of(AllActions.signInError({ error }))),
            ),
        ),
    );

const signOut: Epic<AllOtherRootActionsType> = action$ =>
    action$.pipe(
        filter(isActionOf(AllActions.signOut)),
        tap(() => authentication.signOut()),
        mergeMap(() => ignoreElements()),
    );

const authorise: Epic<AllOtherRootActionsType, AllOtherRootActionsType, RootState> = (
    action$,
    state$: StateObservable<RootState>,
) =>
    action$.pipe(
        filter(isActionOf(AllActions.signInComplete)),
        withLatestFrom(state$),
        mergeMap(([, state]) =>
            http
                .getData(
                    `${getConfig().SdxService}/batchmanagementEntitlements/${state.USER.userName}`,
                )
                .pipe(
                    map(entitlements => {
                        authentication.setEntitlements(entitlements);
                        return AllActions.entitlementsComplete(entitlements);
                    }),
                    catchError(error => of(AllActions.entitlementsError({ error }))),
                ),
        ),
    );

export default combineEpics(fetchFilesToCompare, signIn, signOut, authorise);
