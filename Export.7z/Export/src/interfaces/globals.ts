import { ActionType } from 'typesafe-actions';
import { SummaryReducerType } from '../components/batchSummary/batchSummaryReducer';
import { DetailsReducerType } from '../components/batchDetails/batchDetailsReducer';
import { DownloadsReducerType } from '../components/downloads/downloadsReducer';
import { BatchAuditReducerType } from '../components/batchAudit/batchAuditReducer';
import { InboxReducerType } from '../components/inbox/inboxReducer';
import { ScenarioAuditReducerType } from '../components/scenarioAudit/scenarioAuditReducer';
import { ScheduleReducerType } from '../components/batchSchedule/batchScheduleReducer';
import { BatchCreateReducerType } from '../components/batchCreate/batchCreateReducer';
import * as AllActions from '../actions';

// Event Types
export type InputEvent = React.ChangeEvent<HTMLInputElement>;
export type InputMouseEvent = React.MouseEvent<HTMLInputElement>;
export type ButtonEvent = React.MouseEvent<HTMLButtonElement>;

// Generic types
export interface StringTMap<T> {
    [key: string]: T;
}
export interface NumberTMap<T> {
    [key: number]: T;
}

export interface StringAnyMap extends StringTMap<any> {}
export interface NumberAnyMap extends NumberTMap<any> {}

export interface StringStringMap extends StringTMap<string> {}
export interface NumberStringMap extends NumberTMap<string> {}

export interface StringNumberMap extends StringTMap<number> {}
export interface NumberNumberMap extends NumberTMap<number> {}

export interface StringBooleanMap extends StringTMap<boolean> {}
export interface NumberBooleanMap extends NumberTMap<boolean> {}

// Generic React component Props extraction
type GetComponentClassProps<T> = T extends new (props: infer P) => any ? P : any;

type GetStatelessComponentProps<T> = T extends (
    props: infer P & { children?: React.ReactNode },
) => any
    ? P
    : any;

// type MyComponentClassPropsExtracted = GetComponentClassProps<typeof MyComponentClass>;

// type MyStatelessComponentPropsExtracted = GetStatelessComponentProps<typeof MyStatelessComponent>;

// Global DTO

type STypes = 'Batch' | 'Scenario';

export interface IScenario {
    type: STypes;
    id: string;
    ukId: string;
    comments: string;
    validFrom: string;
    validTo: string;
    modifiedBy: string;
    addedBy: string;
    name: string;
    description: string;
    action: 'CREATE' | 'UPDATE';
    proposedFileVersion: number;
    activeFileVersion: number;
    category: string;
    tags: Array<string> | null;
    attachmentsUploaded: boolean;
    mtcrApprovalCommittee: null;
    pending: boolean;
}

export interface IBatch {
    type: STypes;
    id: string;
    ukId: string;
    comments: string;
    validFrom: string;
    validTo: string;
    modifiedBy: string;
    addedBy: string;
    scenarios: IScenario[];
    name: string;
    pctNode: string | null;
    pctNodeId: string | null;
    cobDate: any | null;
    action: string;
    addedScenarios: string;
    removedScenarios: string;
    activeScenarios: string;
    scheduleDto: any;
}

export interface navLinksType {
    title: string;
    to: string;
    text: string;
    id: string;
}

export interface IErrorTypeProps {
    message?: string;
    className?: string;
    important?: boolean;
    showError?: boolean;
}

// Reducer types
export interface AppState {
    BATCHES: SummaryReducerType;
    BATCH_CREATE: BatchCreateReducerType;
    BATCH_DETAILS: DetailsReducerType;
    BATCH_AUDITS: BatchAuditReducerType;
    BATCH_SCHEDULES: ScheduleReducerType;
    DOWNLOADS: DownloadsReducerType;
    INBOX: InboxReducerType;
    DIFF: any;
    SCENARIOS: any;
    SCENARIO_AUDITS: ScenarioAuditReducerType;
    USER: any;
}

export interface IAuthReducer {
    isSigningIn: boolean;
    failedAuthentication: boolean;
    userDisplayName: string;
    entitlements: string;
}

export interface IDiffReducer {
    diff: any | {};
    isFetchingDiff: boolean;
    fetchDiffError: string;
}

// Action types
export type ErrorType = {
    error: string;
};

export type AllOtherRootActionsType = ActionType<typeof AllActions>;

// Component Types

// Column Definition
export interface IColumnDef {
    label: string;
    key: string;
    formatter?: (date: Date) => string;
    className?: string;
    sortable?: boolean;
    csvFormatter?: (date: Date) => string;
}
