export const initialise = () => undefined;

export const getConfig = () => ({
    SdxService: 'http://uklpadsab104a:7777/sdx',
    UvaService: 'http://uklpadtoy11a.uk.standardchartered.com:8080/ums',
    downloadService: 'http://uklpadfsd03.uk:9091/api/1/datasets',
});
