import { createReducer, StateType } from 'typesafe-actions';
import * as AllActions from '../actions';
import { IDiffReducer, AllOtherRootActionsType } from '../interfaces/globals';

const initialState = {
    diff: {},
    isFetchingDiff: false,
    fetchDiffError: '',
};

const DiffReducer = createReducer<IDiffReducer, AllOtherRootActionsType>(
    initialState as IDiffReducer,
)
    .handleAction(AllActions.fetchDiff, state => ({
        ...state,
        isFetchingDiff: true,
        fetchDiffError: '',
    }))
    .handleAction(AllActions.fetchDiffComplete, (state, action) => ({
        ...state,
        isFetchingDiff: false,
        diff: {
            ...action.payload.diff,
            ukId: action.payload.ukId,
        },
    }))
    .handleAction(AllActions.fetchDiffErrors, (state, action) => ({
        ...state,
        isFetchingDiff: false,
        diff: {},
        fetchDiffError: action.payload.error,
    }));

export type DiffReducerType = StateType<typeof DiffReducer>;

export default DiffReducer;
