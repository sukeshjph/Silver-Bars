import _ from 'lodash';
import { inboxActionTypes } from '../../../components/inbox/inboxConstants';
import reducer from '../../../components/inbox/inboxReducer';

const initialState = {
    inbox: [],
    isFetchingInbox: false,
    isSaving: false,
};

const testError = 'Test error';

describe('Inbox reducer', () => {
    it('returns the initial state', () => {
        expect(reducer(undefined, {})).toEqual(initialState);
    });

    describe('FETCH_INBOX', () => {
        const action = {
            type: inboxActionTypes.FETCH_INBOX,
        };
        it('sets isFetchingInbox to true', () => {
            expect(reducer(undefined, action).isFetchingInbox).toBe(true);
        });
        it('clears any inbox errors', () => {
            const state = {
                ...initialState,
                inboxError: 'an error',
            };
            expect(reducer(state, action).inboxError).toBe('');
        });
    });
    
    describe('FETCH_INBOX_COMPLETE', () => {
        const inbox = [{ ukId: 1, validFrom: 1 }, { ukId: 2, validFrom: 2 }, { ukId: 3, validFrom: 3 }, ];
        const scenarios = [{ ukId: 1, activeFileVersion: 5 }, { ukId: 2, activeFileVersion: 6 }, { ukId: 3, activeFileVersion: 7 }];
        const action = {
            type: inboxActionTypes.FETCH_INBOX_COMPLETE,
            payload: { inbox, scenarios },
        };
        const state = {
            ...initialState,
            isFetchingInbox: true,
        };
        it('sets isFetchingInbox to false', () => {
            expect(reducer(state, action).isFetchingInbox).toBe(false);
        });
        it('adds inbox data to state, sorted by descending validFrom date', () => {
            expect(_.map(reducer(state, action).inbox, 'validFrom')).toEqual([3, 2, 1]);
        });
        it('adds currentActiveFileVersion property to each inbox item', () => {
            expect(_.map(reducer(state, action).inbox, 'currentActiveFileVersion')).toEqual([7,6,5]);
        });
    });
    
    describe('FETCH_INBOX_ERROR', () => {
        const action = {
            type: inboxActionTypes.FETCH_INBOX_ERROR,
            payload: { error: testError },
        };
        const state = {
            ...initialState,
            isFetchingInbox: true,
        };
        it('sets isFetchingInbox to false', () => {
            expect(reducer(state, action).isFetchingInbox).toBe(false);
        });
        it('adds the inbox error to state', () => {
            expect(reducer(state, action).inboxError).toBe(testError);
        });
    });

    
    
    
    describe('APPROVE_SCENARIO', () => {
        const action = {
            type: inboxActionTypes.APPROVE_SCENARIO,
        };
        it('sets isSaving to true', () => {
            expect(reducer(undefined, action).isSaving).toBe(true);
        });
        it('clears any save errors', () => {
            const state = {
                ...initialState,
                saveError: 'an error',
            };
            expect(reducer(state, action).saveError).toBe('');
        });
    });
    
    describe('APPROVE_SCENARIO_COMPLETE', () => {
        it('sets isSaving to false', () => {
            const action = {
                type: inboxActionTypes.APPROVE_SCENARIO_COMPLETE,
            };
            const state = {
                ...initialState,
                isSaving: true,
            };
            expect(reducer(state, action).isSaving).toBe(false);
        });
    });
    
    describe('APPROVE_SCENARIO_ERROR', () => {
        const action = {
            type: inboxActionTypes.APPROVE_SCENARIO_ERROR,
            payload: { error: testError },
        };
        const state = {
            ...initialState,
            isSaving: true,
        };
        it('sets isSaving to false', () => {
            expect(reducer(state, action).isSaving).toBe(false);
        });
        it('adds the save error to state', () => {
            expect(reducer(state, action).saveError).toBe(testError);
        });
    });

    
    
    
    describe('DECLINE_SCENARIO', () => {
        const action = {
            type: inboxActionTypes.DECLINE_SCENARIO,
        };
        it('sets isSaving to true', () => {
            expect(reducer(undefined, action).isSaving).toBe(true);
        });
        it('clears any save errors', () => {
            const state = {
                ...initialState,
                saveError: 'an error',
            };
            expect(reducer(state, action).saveError).toBe('');
        });
    });
    
    describe('DECLINE_SCENARIO_COMPLETE', () => {
        it('sets isSaving to false', () => {
            const action = {
                type: inboxActionTypes.DECLINE_SCENARIO_COMPLETE,
            };
            const state = {
                ...initialState,
                isSaving: true,
            };
            expect(reducer(state, action).isSaving).toBe(false);
        });
    });
    
    describe('DECLINE_SCENARIO_ERROR', () => {
        const action = {
            type: inboxActionTypes.DECLINE_SCENARIO_ERROR,
            payload: { error: testError },
        };
        const state = {
            ...initialState,
            isSaving: true,
        };
        it('sets isSaving to false', () => {
            expect(reducer(state, action).isSaving).toBe(false);
        });
        it('adds the save error to state', () => {
            expect(reducer(state, action).saveError).toBe(testError);
        });
    });
});
