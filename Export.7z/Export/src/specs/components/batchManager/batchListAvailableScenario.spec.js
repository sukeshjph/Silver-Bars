import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import BatchListAvailableScenario from '../../../components/batchManager/batchListAvailableScenario';

describe('BatchListAvailableScenario component', () => {

    let wrapper;
    const initialProps = {
        scenario: {
            pending: false,
            activeFileVersion: 1,
        },
        limitReached: false,
        displayName: 'display name',
        addScenarioToBatch: jest.fn(),
    };

    beforeEach(() => {
        wrapper = shallow(<BatchListAvailableScenario { ...initialProps } />);
    });

    describe('initialisation', () => {
        it('should render with initial props', () => {
            expect(toJson(wrapper)).toMatchSnapshot();
        });
        it('renders a li tag', () => {
            expect(wrapper.find('.stress-batch__list__item')).toHaveLength(1);
        });
        it('renders aan empty div if the scenario has no activeFileVersion', () => {
            const newProps = {
                ...initialProps,
                scenario: {
                    pending: false,
                    activeFileVersion: null,
                },
            };
            wrapper = shallow(<BatchListAvailableScenario { ...newProps } />);
            expect(wrapper.find('.stress-batch__list__item')).toHaveLength(0);
        });
    });

    describe('add button', () => {

        const getButton = () =>
            wrapper.find('.stress__batch__list__add-button').at(0);

        it('is not disabled if props.limitReached is false', () => {
            expect(getButton().prop('disabled')).toBe(false);
        });
        it('is disabled if props.limitReached is true', () => {
            const newProps = {
                ...initialProps,
                limitReached: true,
            };
            wrapper = shallow(<BatchListAvailableScenario { ...newProps } />);
            expect(getButton().prop('disabled')).toBe(true);
        });
        it('calls props.addScenarioToBatch on click', () => {
            getButton().simulate('click');
            expect(initialProps.addScenarioToBatch).toHaveBeenCalled();
        });
    });

});