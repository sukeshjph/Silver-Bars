import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import BatchListSelectedScenario from '../../../components/batchManager/batchListSelectedScenario';

describe('BatchListSelectedScenario component', () => {

    let wrapper;
    const initialProps = {
        userAction: 'added',
        displayName: 'display name',
        removeScenarioFromBatch: jest.fn(),
    };

    beforeEach(() => {
        wrapper = shallow(<BatchListSelectedScenario { ...initialProps } />);
    });

    describe('initialisation', () => {
        it('should render with initial props', () => {
            expect(toJson(wrapper)).toMatchSnapshot();
        });
        it('displays a userAction chip', () => {
            const chip = wrapper.find('.stress__batch__action--added');
            expect(chip).toHaveLength(1);
            expect(chip.at(0).text(0)).toBe(initialProps.userAction);
        });
    });

    describe('remove button', () => {
        it('is visible if the userAction is not "removed"', () => {
            expect(wrapper.find('.stress__batch__list__remove-button')).toHaveLength(1);
        });
        it('calls props.removeScenarioFromBatch on click', () => {
            wrapper.find('.stress__batch__list__remove-button').at(0).simulate('click');
            expect(initialProps.removeScenarioFromBatch).toHaveBeenCalled();
        });
        it('is hidden if the userAction is "removed"', () => {
            const newProps = {
                ...initialProps,
                userAction: 'removed',
            };
            wrapper = shallow(<BatchListSelectedScenario { ...newProps } />);
            expect(wrapper.find('.stress__batch__list__remove-button')).toHaveLength(0);
        });
    });

});