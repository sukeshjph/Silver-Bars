import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import BatchListHeader from '../../../components/batchManager/batchListHeader';
import mockBatchListResponse from '../../mocks/mockBatchListResponse';

describe('BatchListHeader component', () => {

    let wrapper;
    const initialProps = {
        heading: 'heading',
        added: 'Added 1',
        removed: 'Removed 1',
        filterText: 'filter text',
        handleTextChange: jest.fn(),
        removeAllScenariosFromBatch: jest.fn(),
        cloneBatch: jest.fn(),
        batches: mockBatchListResponse,
        disableCloneButton: false,
        selectedBatch: jest.fn(),
    };

    beforeEach(() => {
        wrapper = shallow(<BatchListHeader { ...initialProps } />);
    });

    describe('initialisation', () => {
        it('should render with initial props', () => {
            expect(toJson(wrapper)).toMatchSnapshot();
        });
        it('sets state.filterText to props.filterText', () => {
            expect(wrapper.state('filterText')).toBe(initialProps.filterText);
        });
        it('sets state.isCloneDialogOpen to false', () => {
            expect(wrapper.state('isCloneDialogOpen')).toBe(false);
        });
    });

    describe('receiving filterText prop', () => {
        it('updates state.filterText', () => {
            wrapper.setProps({ filterText: 'new filter text' });
            wrapper.update();
            expect(wrapper.state('filterText')).toBe('new filter text');
        });
    });

    describe('added and removed chips', () => {
        it('are visible if props.added and props.removed are defined', () => {
            const addedChip = wrapper.find('.stress__batch__action--added');
            const removedChip = wrapper.find('.stress__batch__action--removed');
            expect(addedChip).toHaveLength(1);
            expect(addedChip.at(0).text()).toBe(initialProps.added);
            expect(removedChip).toHaveLength(1);
            expect(removedChip.at(0).text()).toBe(initialProps.removed);
        });
        it('are hidden if props.added and props.removed are not defined', () => {
            const newProps = {
                ...initialProps,
                added: null,
                removed: null,
            };
            wrapper = shallow(<BatchListHeader { ...newProps } />);
            expect(wrapper.find('.stress__batch__action--added')).toHaveLength(0);
            expect(wrapper.find('.stress__batch__action--removed')).toHaveLength(0);
        });
    });

    describe('clone button', () => {

        const getButton = () => wrapper.find('.stress-batch__list__header__clone-button');

        it('is visible if props.cloneBatch and props.batches are defined', () => {
            expect(getButton()).toHaveLength(1);
        });
        it('is hidden if props.cloneBatch or props.batches are not defined', () => {
            const newProps = {
                ...initialProps,
                cloneBatch: null,
            };
            wrapper = shallow(<BatchListHeader { ...newProps } />);
            expect(getButton()).toHaveLength(0);
        });
        it('is disabled if props.disableCloneButton is true', () => {
            const newProps = {
                ...initialProps,
                disableCloneButton: true,
            };
            wrapper = shallow(<BatchListHeader { ...newProps } />);
            expect(getButton().at(0).prop('disabled')).toBe(true);
        });
        it('toggles state.isCloneDialogOpen when clicked', () => {
            getButton().simulate('click');
            expect(wrapper.state('isCloneDialogOpen')).toBe(true);
            getButton().simulate('click');
            expect(wrapper.state('isCloneDialogOpen')).toBe(false);
        });
    });

    describe('batch modal', () => {
        it('is hidden', () => {
            expect(wrapper.find('BatchCloneDialog')).toHaveLength(0);
        });
        it('is visible if state.isCloneDialogOpen is true', () => {
            wrapper.setState({ isCloneDialogOpen: true });
            expect(wrapper.find('BatchCloneDialog')).toHaveLength(1);
        });
    });

    describe('remove all button', () => {
        const getButton = () => wrapper.find('.stress-batch__list__header__remove-button');

        it('is visible if props.removeAllScenariosFromBatch is defined', () => {
            expect(getButton()).toHaveLength(1);
        });
        it('it triggers props.removeAllScenariosFromBatch on click', () => {
            getButton().at(0).simulate('click');
            expect(initialProps.removeAllScenariosFromBatch).toHaveBeenCalled();
        });
        it('it resets state.filtertext on click', () => {
            wrapper.state({ filterText: 'updated' });
            getButton().at(0).simulate('click');
            expect(wrapper.state('filterText')).toBe('');
        });
    });

});