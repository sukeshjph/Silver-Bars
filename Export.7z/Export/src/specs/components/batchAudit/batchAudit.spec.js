import React from 'react';
import { shallow, mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import { BatchAudit } from '../../../components/batchAudit';
import ErrorMessage from '../../../components/shared/errorMessage';
import mockBatchAuditListResponse from '../../mocks/mockBatchAuditListResponse';
import mockBatchListResponse from '../../mocks/mockBatchListResponse';
import LoadingData from '../../../components/shared/loadingData';

jest.mock('../../../common/config');
jest.mock('../../../helpers/dateTime');
jest.mock('../../../helpers/tableSorter');
jest.mock('../../../components/shared/userPopover');

describe('BatchAudit component', () => {
    const initialProps = {
        actions: {
            signOut: () => undefined,
            fetchBatches: () => undefined,
            fetchBatchAudits: () => undefined,
        },
        model: {
            batches: mockBatchListResponse,
            batchAudits: mockBatchAuditListResponse,
            isFetchingBatches: false,
            isFetchingBatchAudits: false,
            batchAuditsError: '',
            batchesError: '',
        },
        user: {
            userDisplayName: '',
            entitlements: '',
            userName: 'Steve',
        },
    };
    let wrapper;

    beforeEach(() => {
        wrapper = shallow(<BatchAudit {...initialProps} />);
    });

    describe('rendering', () => {
        it('should render with initial props and state', () => {
            expect(toJson(wrapper)).toMatchSnapshot();
        });
    });

    describe('component mounting', () => {
        it('fetches batch audit data', () => {
            const fetchBatchAuditsSpy = jest.spyOn(initialProps.actions, 'fetchBatchAudits');
            mount(<BatchAudit {...initialProps} />);
            expect(fetchBatchAuditsSpy).toHaveBeenCalled();
        });
    });

    describe('loading', () => {
        it('displays a spinner if batches are loading', () => {
            const newProps = {
                ...initialProps,
                model: {
                    ...initialProps.model,
                    isFetchingBatches: true,
                },
            };
            wrapper.setProps(newProps);
            expect(
                wrapper
                    .find(LoadingData)
                    .shallow()
                    .childAt(0),
            ).toHaveLength(1);
        });
        it('displays a spinner if batch audits are loading', () => {
            const newProps = {
                ...initialProps,
                model: {
                    ...initialProps.model,
                    isFetchingBatchAudits: true,
                },
            };
            wrapper.setProps(newProps);
            expect(
                wrapper
                    .find(LoadingData)
                    .shallow()
                    .childAt(0),
            ).toHaveLength(1);
        });
    });

    describe('loading error', () => {
        const getErrorMessages = wrap =>
            wrap
                .find(ErrorMessage)
                .reduce((messages, errNode) => [...messages, errNode.props().message], []);

        it('displays a message to the user if batch audits cannot be loaded', () => {
            const newProps = {
                ...initialProps,
                model: {
                    ...initialProps.model,
                    batchAuditsError: 'an error',
                },
            };
            wrapper.setProps(newProps);
            expect(getErrorMessages(wrapper)).toContain(
                'Sorry, an unexpected error has occurred. Batch audit data cannot be displayed.',
            );
        });
        it('displays a message to the user if batches cannot be loaded', () => {
            const newProps = {
                ...initialProps,
                model: {
                    ...initialProps.model,
                    batchesError: 'an error',
                },
            };
            wrapper.setProps(newProps);
            expect(getErrorMessages(wrapper)).toContain(
                'Sorry, an unexpected error has occurred. Batch audit data cannot be displayed.',
            );
        });
    });

    describe('receiving props', () => {
        it('updates state.batchAudits and applies correct filters', () => {
            const newBatchAudits = [{}, {}];
            jest.spyOn(wrapper.instance(), 'filterDataSet');
            wrapper.setState({ filterText: '' });
            wrapper.setProps({
                ...initialProps,
                model: {
                    ...initialProps.model,
                    batchAudits: newBatchAudits,
                },
            });
            expect(wrapper.instance().filterDataSet).toHaveBeenCalledWith('', newBatchAudits);
            expect(wrapper.state('batchAudits')).toEqual(newBatchAudits);
        });
    });

    describe('Batch text filter', () => {
        const filterText = 'filter text';
        it('adds the filter string to state', () => {
            wrapper.instance().handleFilterTextChange(filterText, mockBatchAuditListResponse);
            expect(wrapper.state('filterText')).toBe(filterText);
        });
        it('adds the filtered batchAudits to state', () => {
            wrapper.instance().handleFilterTextChange(filterText, mockBatchAuditListResponse);
            expect(wrapper.state('batchAudits')).toEqual(mockBatchAuditListResponse);
        });
    });

    describe('no records in filter', () => {
        it('displays a message to the user', () => {
            wrapper.setState({ batchAudits: [] });
            expect(wrapper.find(ErrorMessage).props().message).toContain(
                'There are no batch audits matching your filters.',
            );
        });
    });

    describe('sorting the columns', () => {
        const triggerSort = () => {
            wrapper.instance().sortHandler({}, 'comment');
        };
        it('adds tableSorter results to state', () => {
            triggerSort();
            expect(wrapper.state('batchAudits')).toEqual(['mockDataResult']);
            expect(wrapper.state('order')).toBe('mockOrderResult');
            expect(wrapper.state('orderBy')).toBe('mockOrderByResult');
        });
    });
});
