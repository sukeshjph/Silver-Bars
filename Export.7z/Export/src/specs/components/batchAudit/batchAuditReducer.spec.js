import orderBy from 'lodash.orderby';
import { batchAuditActionTypes } from '../../../components/batchAudit/batchAuditConstants';
import reducer from '../../../components/batchAudit/batchAuditReducer';
import mockBatchAuditListResponse from '../../mocks/mockBatchAuditListResponse';

const initialState = {
    batchAudits: [],
    isFetchingBatchAudits: false,
    batchAuditsError: '',
};

const testError = 'Test error';

describe('Batch Audit reducer', () => {
    it('returns the initial state', () => {
        expect(reducer(undefined, {})).toEqual(initialState);
    });

    describe('FETCH_BATCH_AUDITS', () => {
        const action = {
            type: batchAuditActionTypes.FETCH_BATCH_AUDITS,
        };
        it('sets isFetchingBatchAudits to true', () => {
            expect(reducer(undefined, action).isFetchingBatchAudits).toBe(true);
        });
        it('clears any batch audit errors', () => {
            const state = {
                ...initialState,
                batchAuditsError: testError,
            };
            expect(reducer(state, action).batchAuditsError).toBe('');
        });
    });

    describe('FETCH_BATCH_AUDITS_COMPLETE', () => {
        const action = {
            type: batchAuditActionTypes.FETCH_BATCH_AUDITS_COMPLETE,
            payload: {
                batchAudits: mockBatchAuditListResponse,
            },
        };
        const state = {
            ...initialState,
            isFetchingBatchAudits: true,
        };
        it('sets isFetchingBatchAudits to false', () => {
            expect(reducer(state, action).isFetchingBatchAudits).toBe(false);
        });
        it('adds batch audit data to state', () => {
            expect(reducer(state, action).batchAudits).toHaveLength(
                mockBatchAuditListResponse.length,
            );
        });
        it('sorts the batchAudits by descending validFrom date', () => {
            const sortedBatchAuditIds = orderBy(mockBatchAuditListResponse, ['validFrom'], 'desc');
            expect(reducer(state, action).batchAudits).toEqual(sortedBatchAuditIds);
        });
    });

    describe('FETCH_BATCH_AUDITS_ERROR', () => {
        const action = {
            type: batchAuditActionTypes.FETCH_BATCH_AUDITS_ERROR,
            payload: { error: testError },
        };
        const state = {
            ...initialState,
            isFetchingBatchAudits: true,
        };
        it('sets isFetchingBatchAudits to false', () => {
            expect(reducer(state, action).isFetchingBatchAudits).toBe(false);
        });
        it('adds the batchAuditsError to state', () => {
            expect(reducer(state, action).batchAuditsError).toBe(testError);
        });
    });
});
