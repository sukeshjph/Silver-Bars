import orderBy from 'lodash.orderby';
import { scenarioAuditActionTypes } from '../../../components/scenarioAudit/scenarioAuditConstants';
import reducer from '../../../components/scenarioAudit/scenarioAuditReducer';
import mockScenarioAuditListResponse from '../../mocks/mockScenarioAuditListResponse';

const initialState = {
    scenarioAudits: [],
    isFetchingScenarioAudits: false,
    scenarioAuditsError: '',
};

const testError = 'Test error';

describe('Scenario Audit reducer', () => {
    it('returns the initial state', () => {
        expect(reducer(undefined, {})).toEqual(initialState);
    });

    describe('FETCH_SCENARIO_AUDITS', () => {
        const action = {
            type: scenarioAuditActionTypes.FETCH_SCENARIO_AUDITS,
        };
        it('sets isFetchingScenarioAudits to true', () => {
            expect(reducer(undefined, action).isFetchingScenarioAudits).toBe(true);
        });
        it('clears any scenario audit errors', () => {
            const state = {
                ...initialState,
                scenarioAuditsError: testError,
            };
            expect(reducer(state, action).scenarioAuditsError).toBe('');
        });
    });

    describe('FETCH_SCENARIO_AUDITS_COMPLETE', () => {
        const action = {
            type: scenarioAuditActionTypes.FETCH_SCENARIO_AUDITS_COMPLETE,
            payload: {
                scenarioAudits: mockScenarioAuditListResponse,
            },
        };
        const state = {
            ...initialState,
            isFetchingScenarioAudits: true,
        };
        it('sets isFetchingScenarioAudits to false', () => {
            expect(reducer(state, action).isFetchingScenarioAudits).toBe(false);
        });
        it('adds scenario audit data to state', () => {
            expect(reducer(state, action).scenarioAudits).toHaveLength(
                mockScenarioAuditListResponse.length,
            );
        });
        it('sorts the scenarioAudits by descending validFrom date', () => {
            const sortedBatchAuditIds = orderBy(
                mockScenarioAuditListResponse,
                ['validFrom'],
                'desc',
            );
            expect(reducer(state, action).scenarioAudits).toEqual(sortedBatchAuditIds);
        });
    });

    describe('FETCH_SCENARIO_AUDITS_ERROR', () => {
        const action = {
            type: scenarioAuditActionTypes.FETCH_SCENARIO_AUDITS_ERROR,
            payload: { error: testError },
        };
        const state = {
            ...initialState,
            isFetchingScenarioAudits: true,
        };
        it('sets isFetchingScenarioAudits to false', () => {
            expect(reducer(state, action).isFetchingScenarioAudits).toBe(false);
        });
        it('adds the scenarioAuditsError to state', () => {
            expect(reducer(state, action).scenarioAuditsError).toBe(testError);
        });
    });
});
