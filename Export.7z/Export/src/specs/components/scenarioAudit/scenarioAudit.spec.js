import React from 'react';
import { shallow, mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import { ScenarioAudit } from '../../../components/scenarioAudit';
import ErrorMessage from '../../../components/shared/errorMessage';
import mockScenarioAuditListResponse from '../../mocks/mockScenarioAuditListResponse';
import LoadingData from '../../../components/shared/loadingData';

jest.mock('../../../common/config');
jest.mock('../../../helpers/dateTime');
jest.mock('../../../helpers/tableSorter');
jest.mock('../../../components/shared/userPopover');

describe('ScenarioAudit component', () => {
    const initialProps = {
        model: {
            scenarioAudits: mockScenarioAuditListResponse,
            isFetchingScenarioAudits: false,
            scenarioAuditsError: '',
        },
        actions: {
            signOut: () => undefined,
            fetchScenarioAudits: () => undefined,
        },
        user: {
            userDisplayName: '',
            entitlements: '',
        },
    };
    let wrapper;

    const setUp = props => {
        wrapper = shallow(<ScenarioAudit {...props} />);
    };

    describe('rendering', () => {
        it('should render with initial props and state', () => {
            setUp(initialProps);
            expect(toJson(wrapper)).toMatchSnapshot();
        });
    });

    describe('loading', () => {
        it('displays a spinner', () => {
            const newProps = {
                ...initialProps,
                model: {
                    ...initialProps.model,
                    isFetchingScenarioAudits: true,
                },
            };
            setUp(newProps);
            expect(
                wrapper
                    .find(LoadingData)
                    .shallow()
                    .childAt(0),
            ).toHaveLength(1);
        });
    });

    describe('loading error', () => {
        it('displays a message to the user', () => {
            const newProps = {
                ...initialProps,
                model: {
                    ...initialProps.model,
                    scenarioAuditsError: 'Oooooh',
                },
            };
            setUp(newProps);
            wrapper.setState({ scenarioAudits: ['some value'] });
            expect(wrapper.find(ErrorMessage)).toHaveLength(1);
        });
    });

    describe.skip('component mounting', () => {
        it('fetches batch and scenario data', () => {
            setUp(initialProps);
            const spy = jest.spyOn(initialProps.actions, 'fetchScenarioAudits');
            mount(<ScenarioAudit {...initialProps} />);
            expect(spy).toHaveBeenCalled();
        });
    });

    describe('receiving props', () => {
        it('updates state.scenarioAudits', () => {
            setUp(initialProps);
            const newScenarioAudits = [{}, {}];
            wrapper.setProps({
                ...initialProps,
                model: {
                    ...initialProps.model,
                    scenarioAudits: newScenarioAudits,
                },
            });
            expect(wrapper.state('scenarioAudits')).toEqual(newScenarioAudits);
        });
    });

    describe('Text filter', () => {
        const filterText = 'filter text';
        const filteredAudits = [{}, {}];
        it('updates state with args provided by DataSetFilter component', () => {
            setUp(initialProps);
            wrapper.instance().handleFilterTextChange(filterText, filteredAudits);
            expect(wrapper.state('filterText')).toBe(filterText);
            expect(wrapper.state('scenarioAudits')).toBe(filteredAudits);
        });
    });

    describe('sorting the columns', () => {
        const triggerSort = () => {
            wrapper.instance().sortHandler({}, 'comment');
        };
        it('adds tableSorter results to state', () => {
            setUp(initialProps);
            triggerSort();
            expect(wrapper.state('scenarioAudits')).toEqual(['mockDataResult']);
            expect(wrapper.state('order')).toBe('mockOrderResult');
            expect(wrapper.state('orderBy')).toBe('mockOrderByResult');
        });
    });
});
