import fileDownload from 'js-file-download';
import { downloadActionTypes } from '../../../components/downloads/downloadsConstants';
import reducer, {
    getDataSetView,
    getEmptyDsView,
    getDatasetViewWithLoadingFiles,
    getViewName,
} from '../../../components/downloads/downloadsReducer';
import { fileListPayload } from '../../mocks/mockDownloadReducerPayload';
import { datasetDetails } from '../../mocks/mockDownloadAPIResponse';

jest.mock('js-file-download');
jest.mock('../../../components/downloads/getFilesFilteredByExtensions', () =>
    jest.fn(sourceFileList => sourceFileList),
);

const initialState = {
    dataSetView: {
        columns: [],
        rows: [],
        viewname: '',
        csvFileName: '',
    },
    filesInProgress: [],
    currentDataSetIdWithFileRequest: '',
    currentRvOrderBy: {},
    currentRvFilter: [],
    isFetchingDataSetList: false,
    isFetchingFiles: false,
    isDownloadingFile: false,
    error: '',
};

const error = { message: 'download error' };

describe('Download reducer', () => {
    it('returns the initial state', () => {
        expect(reducer(undefined, {})).toEqual(initialState);
    });

    describe('FETCH_FILE_LIST group', () => {
        describe('FETCH_FILE_LIST reducer', () => {
            it('sets isFetchingDataSetList to true when loading the list', () => {
                const action = {
                    type: downloadActionTypes.FETCH_FILE_LIST,
                    payload: {
                        testing: 'payload',
                        deep: {
                            nesting: [],
                        },
                    },
                };
                expect(reducer(undefined, action)).toEqual({
                    ...initialState,
                    isFetchingDataSetList: true,
                    filesInProgress: [],
                });
            });
        });
        describe('FETCH_FILE_LIST_COMPLETE reducer', () => {
            describe('With empty dataset Lists', () => {
                const emptyFileList = fileListPayload.map(fileListObj => ({
                    ...fileListObj,
                    dataSetList: [],
                }));
                const action = {
                    type: downloadActionTypes.FETCH_FILE_LIST_COMPLETE,
                    payload: emptyFileList,
                };

                let outcome;
                beforeEach(() => {
                    outcome = reducer({ isFetchingDataSetList: true }, action);
                });
                it('sets isFetchingDataSetList to false', () => {
                    expect(outcome.isFetchingDataSetList).toBe(false);
                });
                it('returns the empty datasetView', () => {
                    expect(outcome.dataSetView).toEqual(
                        getEmptyDsView(getViewName('appsets/marketrisk/stress')),
                    );
                });
            });

            describe('With non empty dataset Lists', () => {
                const action = {
                    type: downloadActionTypes.FETCH_FILE_LIST_COMPLETE,
                    payload: fileListPayload,
                };
                let outcome;
                beforeEach(() => {
                    outcome = reducer({ isFetchingDataSetList: true }, action);
                });
                it('sets isFetchingDataSetList to false', () => {
                    expect(outcome.isFetchingDataSetList).toBe(false);
                });
                it('returns the fileList', () => {
                    expect(Object.keys(outcome.dataSetView)).toHaveLength(4);
                });
                it('should have Batch Date column', () => {
                    const { columns } = outcome.dataSetView;
                    expect(columns.findIndex(col => col.columnName === 'batchDate')).not.toBe(-1);
                });
            });
        });
        describe('FETCH_FILE_LIST_ERROR reducer', () => {
            const action = {
                type: downloadActionTypes.FETCH_FILE_LIST_ERROR,
                payload: { error },
            };
            const state = {
                isFetchingDataSetList: true,
            };
            it('sets isFetchingDataSetList to false', () => {
                const outcome = reducer(state, action);
                expect(outcome.isFetchingDataSetList).toEqual(false);
            });

            it('returns the error', () => {
                const outcome = reducer(state, action);
                expect(outcome.error).toEqual(error);
            });
        });
    });

    describe('FETCH_FILE_DETAILS group', () => {
        describe('FETCH_FILE_DETAILS reducer', () => {
            const { dataSetId: datasetId } = datasetDetails;
            const action = {
                type: downloadActionTypes.FETCH_FILE_DETAILS,
                payload: { datasetId },
            };

            const oldState = {
                ...initialState,
                dataSetView: getDataSetView(fileListPayload),
                currentDataSetIdWithFileRequest: datasetId,
                isFetchingFiles: true,
            };

            let outcome;

            beforeEach(() => {
                outcome = reducer(oldState, action);
            });
            it('sets isFetchingFiles to true when loading the dataset details', () => {
                expect(outcome.isFetchingFiles).toBeTruthy();
            });

            it('File row is added to dataSetView', () => {
                const {
                    dataSetView: { rows },
                    currentDataSetIdWithFileRequest,
                } = outcome;

                const fileRow = rows.find(row => row.oldDataSetId === datasetId && row.columns);
                expect(fileRow.files).toHaveLength(0);
                expect(currentDataSetIdWithFileRequest).toBe(datasetId);
            });
        });
        describe('FETCH_FILE_DETAILS_COMPLETE reducer', () => {
            const { dataSetId: datasetId, blobs: files } = datasetDetails;
            const action = {
                type: downloadActionTypes.FETCH_FILE_DETAILS_COMPLETE,
                payload: { datasetId, files },
            };

            const oldState = {
                ...initialState,
                dataSetView: getDatasetViewWithLoadingFiles(
                    getDataSetView(fileListPayload),
                    datasetId,
                ),
                isFetchingFiles: true,
            };

            let outcome;
            beforeEach(() => {
                outcome = reducer(oldState, action);
            });
            it('sets isFetchingFiles to false', () => {
                expect(outcome.isFetchingFiles).toBeFalsy();
            });
            it('returns the DatasetView with updated dataset files', () => {
                const fileRow = outcome.dataSetView.rows.find(
                    row => row.oldDataSetId === datasetId && row.columns,
                );
                expect(fileRow.files.length).toBeGreaterThanOrEqual(0);
            });
        });
        describe('FETCH_FILE_DETAILS_RESET reducer', () => {
            it('should remove the accordion rows', () => {
                const currentState = {
                    ...initialState,
                    currentDataSetIdWithFileRequest:
                        'appsets/marketrisk/stress/global-missingshocks/Oil_Price_Spike/date=2018-03-23/version=1',
                };
                const action = {
                    type: downloadActionTypes.FETCH_FILE_DETAILS_RESET,
                };

                expect(reducer(currentState, action).currentDataSetIdWithFileRequest).toBeFalsy();
            });
        });

        describe('FETCH_FILE_DETAILS_ERROR reducer', () => {
            const action = {
                type: downloadActionTypes.FETCH_FILE_DETAILS_ERROR,
                payload: { error },
            };
            const state = {
                isFetchingFiles: true,
            };
            it('sets isFetchingFiles to false', () => {
                const outcome = reducer(state, action);
                expect(outcome.isFetchingFiles).toEqual(false);
            });

            it('returns the error', () => {
                const outcome = reducer(state, action);
                expect(outcome.error).toEqual(error);
            });
        });
    });

    describe('FETCH BLOB group', () => {
        describe('FETCH_BLOB reducer', () => {
            it('sets isDownloadingFile to true and sets filesInProgress', () => {
                const action = {
                    type: downloadActionTypes.FETCH_BLOB,
                    payload: {
                        datasetId: '',
                        blobName: '',
                    },
                };
                expect(reducer(undefined, action)).toEqual({
                    ...initialState,
                    isDownloadingFile: true,
                    filesInProgress: [
                        {
                            datasetId: '',
                            blobName: '',
                        },
                    ],
                });
            });
        });

        describe('FETCH_BLOB_COMPLETE reducer', () => {
            const action = {
                type: downloadActionTypes.FETCH_BLOB_COMPLETE,
                payload: {
                    datasetId: datasetDetails.dataSetId,
                    blobName: 'testfile',
                    blob: '',
                },
            };

            const oldState = {
                ...initialState,
                isDownloadingFile: true,
            };

            const outcome = reducer(oldState, action);

            it('sets isDownloadingFile to false and calls file download ', () => {
                expect(outcome.isDownloadingFile).toBeFalsy();
                expect(fileDownload.mock.calls).toHaveLength(1);
            });
        });

        describe('FETCH_BLOB_ERROR reducer', () => {
            const action = {
                type: downloadActionTypes.FETCH_BLOB_ERROR,
                payload: { error },
            };
            const state = {
                isDownloadingFile: true,
            };
            it('sets isDownloadingFile to false', () => {
                const outcome = reducer(state, action);
                expect(outcome.isDownloadingFile).toEqual(false);
            });

            it('returns the error', () => {
                const outcome = reducer(state, action);
                expect(outcome.error).toEqual(error);
            });
        });

        describe('FETCH BLOB RESET', () => {
            describe('FETCH_BLOB_RESET reducer', () => {
                it('resets files In Progress', () => {
                    const file = {
                        dataSetId:
                            'appsets/marketrisk/stress/global-missingshocks/Oil_Price_Spike/date=2018-03-23/version=1',
                        blobName: 'Oil_Price_Spike-Global-MissingShocks-20180323.csv.gz',
                    };

                    const currentState = {
                        ...initialState,
                        filesInProgress: [file],
                    };

                    expect(
                        reducer(currentState, {
                            type: 'nothing as such',
                        }).filesInProgress,
                    ).toContain(file);
                    const action = {
                        type: downloadActionTypes.FETCH_BLOB_RESET,
                    };

                    expect(reducer(currentState, action).filesInProgress).toHaveLength(0);
                });
            });
        });
    });
});
