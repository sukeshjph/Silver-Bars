import React from 'react';
import { shallow, mount } from 'enzyme';
import moment from 'moment';
import toJson from 'enzyme-to-json';
import DialogActions from '@material-ui/core/DialogActions';
import Button from '@material-ui/core/Button';
import configureStore from 'redux-mock-store';
import MenuItem from '@material-ui/core/MenuItem';
import MenuList from '@material-ui/core/MenuList';
import ReactRouterEnzymeContext from 'react-router-enzyme-context';
import dataSetView, { sensitivityDsView } from '../../mocks/mockFileListResponse';
import { Download, mapStateToProps, mapDispatchToProps } from '../../../components/downloads';
import LoadingData from '../../../components/shared/loadingData';

import {
    DATASET_ROOT,
    SECONDARY_ROOTPATHS,
} from '../../../components/downloads/downloadsConstants';
import ErrorMessage from '../../../components/shared/errorMessage';

jest.mock('../../../helpers/authentication');

// Return a fixed timestamp when moment().format() is called
jest.mock('moment', () => () => ({ format: () => '2018–01–30' }));

const initialProps = {
    reports: {
        dataSetView,
        filesInProgress: [],
        isFetchingDataSetList: false,
        isFetchingFiles: false,
        isDownloadingFile: false,
        error: '',
    },
    user: {
        userDisplayName: 'Sukesh dash',
        entitlements: 'entitlements',
        failedAuthentication: false,
        isSigningIn: false,
        location: '',
        userName: '1395651',
    },
    actions: {
        fetchFileList: () => undefined,
        fetchBlobReset: () => undefined,
        fetchFileDetails: () => undefined,
        fetchBlobFile: () => undefined,
        fetchFileDetailsReset: () => undefined,
        signOut: () => undefined,
    },
};

describe('Download Main component', () => {
    const commonWrapper = shallow(<Download {...initialProps} />);

    it('should render without error', () => {
        expect(toJson(commonWrapper)).toMatchSnapshot();
    });

    it('Loading icon..', () => {
        const localProps = {
            ...initialProps,
            reports: {
                ...initialProps.reports,
                isFetchingDataSetList: true,
            },
        };
        commonWrapper.setProps({ ...localProps });
        expect(
            commonWrapper
                .find(LoadingData)
                .shallow()
                .childAt(0),
        ).toHaveLength(1);
    });

    it('Error!', () => {
        commonWrapper.setProps({
            ...initialProps,
            reports: {
                ...initialProps.reports,
                error: 'Some error',
            },
        });
        expect(commonWrapper.find(ErrorMessage)).toHaveLength(1);
    });

    it('Show Progress panel for slow download files', () => {
        const filesInProgress = [
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-13/version=1',
                blobName: 'file-11.csv.gz',
            },
        ];
        const localProps = {
            ...initialProps,
            reports: {
                ...initialProps.reports,
                filesInProgress,
            },
        };
        commonWrapper.setProps({ ...localProps });
        const mainStressPanel = commonWrapper.find('.stress-reports');
        const downloadProgress = mainStressPanel
            .childAt(mainStressPanel.children().length - 1)
            .shallow();
        expect(downloadProgress).toHaveLength(1);
        const progressProps = downloadProgress.props();
        expect(progressProps).toHaveProperty('files');
    });

    it.skip('Test initial state', () => {
        const initialState = {
            dataSetView,
            asOfDate: undefined,
            currentRootLink:
                SECONDARY_ROOTPATHS[0].value.indexOf(';') === -1
                    ? [DATASET_ROOT + SECONDARY_ROOTPATHS[0].value]
                    : SECONDARY_ROOTPATHS[0].value.split(';').map(p => DATASET_ROOT + p),
            currentActiveLink: SECONDARY_ROOTPATHS[0].value,
            toggleSidePanel: true,
            regexFilter: `.*${moment().format('YYYY-MM')}.*`,
        };
        const options = new ReactRouterEnzymeContext();
        const wrapper = mount(<Download {...initialProps} />, options.get());
        expect(wrapper.instance().state).toEqual(initialState);
    });

    describe('Testing Cob date filter', () => {
        const fetchFileList = jest.fn();
        const localProps = {
            ...initialProps,
            actions: {
                ...initialProps.actions,
                fetchFileList,
            },
        };
        const newWrapper = shallow(<Download {...localProps} />);
        const header = newWrapper.find('.stress__header');

        it('Test initial date', () => {
            expect(newWrapper.instance().state.asOfDate).toBeUndefined();
        });

        describe('Date changed and table filtered', () => {
            const DatePicker = header
                .find('.stress--date-range--container .stress__header__input')
                .at(0);

            it('With a valid Date', () => {
                const CobDate = moment('2018-03-16');
                DatePicker.props().onChange(CobDate);
                expect(newWrapper.instance().state.asOfDate).toBe(CobDate);
                const { regexFilter, currentRootLink } = newWrapper.instance().state;
                expect(regexFilter).toBe(
                    `.*${newWrapper.instance().state.asOfDate.format('YYYY-MM-DD')}.*`,
                );
                expect(fetchFileList).toHaveBeenCalledWith(currentRootLink, regexFilter);
            });

            it('When date is cleared', () => {
                DatePicker.props().onChange(null);
                expect(newWrapper.instance().state.asOfDate).toBeUndefined();
                const { regexFilter, currentRootLink } = newWrapper.instance().state;
                expect(regexFilter).toBe(`.*${moment().format('YYYY-MM')}.*`);
                expect(fetchFileList).toHaveBeenCalledWith(currentRootLink, regexFilter);
            });
        });
    });

    describe('React Lifecycle methods', () => {
        const DidMountspy = jest.spyOn(Download.prototype, 'componentDidMount');
        const recieveSpy = jest.spyOn(Download.prototype, 'componentWillReceiveProps');
        const fetchFileList = jest.fn();
        const fetchBlobReset = jest.fn();

        describe('File fetch', () => {
            it.skip('Fetching file list and reset progress panel', () => {
                const localProps = {
                    ...initialProps,
                    actions: {
                        ...initialProps.actions,
                        fetchFileList,
                        fetchBlobReset,
                    },
                };
                const options = new ReactRouterEnzymeContext();
                const mountedWrapper = mount(<Download {...localProps} />, options.get());
                const { currentRootLink, regexFilter } = mountedWrapper.instance().state;
                expect(DidMountspy).toHaveBeenCalled();
                expect(fetchFileList).toHaveBeenCalledWith(currentRootLink, regexFilter);
                expect(fetchBlobReset).toHaveBeenCalled();
            });
        });

        describe('Reloads when new file list received', () => {
            const newWrapper = shallow(<Download {...initialProps} />);

            beforeEach(() => {
                jest.clearAllMocks();
            });

            it('when default or stress path clicked again', () => {
                newWrapper.setProps({
                    ...initialProps,
                    reports: {
                        ...initialProps.reports,
                        dataSetView,
                    },
                });
                expect(recieveSpy).toHaveBeenCalled();
                expect(newWrapper.instance().state.dataSetView).toEqual(dataSetView);
            });

            it('when different path or sensitivity path clicked', () => {
                newWrapper.setProps({
                    ...initialProps,
                    reports: {
                        ...initialProps.reports,
                        dataSetView: sensitivityDsView,
                    },
                });
                expect(recieveSpy).toHaveBeenCalled();
                expect(newWrapper.instance().state.dataSetView).toEqual(sensitivityDsView);
            });

            it('empty Dataset', () => {
                const emptyDsView = {
                    columns: [],
                    rows: [],
                    viewname: '',
                    csvFileName: '',
                };
                newWrapper.setProps({
                    ...initialProps,
                    reports: {
                        ...initialProps.reports,
                        dataSetView: {},
                    },
                });
                expect(recieveSpy).toHaveBeenCalled();
                expect(newWrapper.instance().state.dataSetView).toEqual(emptyDsView);
            });
        });
    });

    it.skip('Re-fetches filelist when report root Paths change', () => {
        const newWrapper = shallow(<Download {...initialProps} />);
        const fetchFileList = jest.fn();
        const localProps = {
            ...initialProps,
            actions: {
                ...initialProps.actions,
                fetchFileList,
            },
        };

        newWrapper.setProps({ ...localProps });
        newWrapper
            .find('.view-content-panel')
            .childAt(0)
            .dive()
            .childAt(0)
            .dive()
            .find(MenuList)
            .find(MenuItem)
            .at(0)
            .simulate('click');

        expect(fetchFileList).toHaveBeenCalled();
    });

    describe('When clicked Folder icon for a dataset', () => {
        const fetchFileDetails = jest.fn();
        const newWrapper = shallow(<Download {...initialProps} />);
        const commonProps = {
            ...initialProps,
            actions: {
                ...initialProps.actions,
                fetchFileDetails,
            },
        };

        Download.prototype.rvT = {
            state: {
                orderBy: {},
                columnFilter: [],
            },
        };

        beforeEach(() => {
            fetchFileDetails.mockClear();
            newWrapper.setProps({ ...commonProps });
        });

        it('When no File download is underway', () => {
            newWrapper.instance().handleGetFilesClick(dataSetView.rows[0].dataSetId, true)();
            expect(fetchFileDetails).toHaveBeenCalledWith(
                encodeURIComponent(dataSetView.rows[0].dataSetId),
                {},
                [],
            );
        });

        it('When a filedownload is underway', () => {
            const localProps = {
                ...commonProps,
                reports: {
                    ...initialProps.reports,
                    isFetchingFiles: true,
                },
            };
            newWrapper.setProps({ ...localProps });
            newWrapper.instance().handleGetFilesClick(dataSetView.rows[0].dataSetId, true)();
            expect(fetchFileDetails).not.toHaveBeenCalled();
        });

        it('When file panel is closed', () => {
            newWrapper.instance().handleGetFilesClick(dataSetView.rows[0].dataSetId, false)();
            expect(fetchFileDetails).not.toHaveBeenCalled();
            const {
                dataSetView: { rows },
            } = newWrapper.instance().state;
            expect(
                rows.find(row => row.dataSetId === dataSetView.rows[0].dataSetId).files,
            ).toBeNull();
        });
    });

    it('Navigating away when file downloads are in progress', () => {
        const onConfirm = jest.fn();
        const onCancel = jest.fn();
        const navigationDialog = shallow(
            commonWrapper.instance().onNavigationPrompt(true)({ onConfirm, onCancel }),
        );
        navigationDialog
            .find(DialogActions)
            .find(Button)
            .at(0)
            .dive()
            .simulate('click');
        navigationDialog
            .find(DialogActions)
            .find(Button)
            .at(1)
            .dive()
            .simulate('click');
        expect(onConfirm).toHaveBeenCalled();
        expect(onCancel).toHaveBeenCalled();
    });

    // replace with find and click later
    it('Download a file', () => {
        const fetchBlobFile = jest.fn();
        const dataSetId = 'dsid';
        const fileName = 'testfilename';
        const event = {
            preventDefault() {},
            target: { value: 'appset' },
        };
        commonWrapper.setProps({
            ...initialProps,
            actions: {
                ...initialProps.actions,
                fetchBlobFile,
            },
        });
        commonWrapper.instance().handleBlobFileDownload(dataSetId, fileName)(event);
        expect(fetchBlobFile).toHaveBeenCalled();
    });

    describe('Test React-Redux Methods', () => {
        const mockStore = configureStore();
        let wrapper;
        let store;

        beforeEach(() => {
            store = mockStore({});
            wrapper = shallow(<Download {...initialProps} store={store} />);
        });

        it('mapStateToProps()', () => {
            const state = {
                STRESS: {
                    BATCHES: {
                        batches: [],
                        scenarios: [],
                        batchAudits: [],
                        scenarioVersions: [],
                        doesScenarioExist: false,
                        isSavingBatch: false,
                        isSavingScenario: false,
                        isDeletingScenario: false,
                        hasDeletedScenario: false,
                        isFetchingBatches: false,
                        isFetchingScenario: false,
                        isFetchingScenarios: false,
                        isFetchingScenarioDetails: false,
                    },
                    DOWNLOADS: {
                        dataSetView,
                        filesInProgress: [],
                        isFetchingDataSetList: false,
                        isFetchingFiles: false,
                        isDownloadingFile: false,
                        error: '',
                    },
                    USER: {
                        isSigningIn: false,
                        failedAuthentication: false,
                        userDisplayName: '1395651',
                        entitlements: 'RW',
                        location: 'SG',
                        userName: '1395651',
                    },
                },
            };

            mapStateToProps(state);
            expect(wrapper.instance().props.reports).toBeDefined();
            expect(wrapper.instance().props.user).toBeDefined();
        });

        it('mapDispatchToProps()', () => {
            const dispatch = jest.fn();
            mapDispatchToProps(dispatch).actions.signIn();
            expect(dispatch).toHaveBeenCalled();
        });
    });
});
