import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import DownloadProgress from '../../../components/downloads/downloadProgress';

jest.mock('shortid', () => ({
    generate: jest.fn(() => 1),
}));

describe('Download Progress test', () => {
    const commonProps = {
        files: [
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-13/version=1',
                blobName: 'file-11.csv.gz',
            },
        ],
        setRef: () => undefined,
    };
    const wrapper = shallow(<DownloadProgress {...commonProps} />);

    it('should render without error', () => {
        expect(toJson(wrapper)).toMatchSnapshot();
        expect(
            wrapper
                .find('.stress-reports-footer--list__listItem .stress-reports-footer__fileName')
                .contains(<span className="stress-reports-footer__fileName">file-11.csv.gz</span>),
        ).toBeTruthy();
    });
});
