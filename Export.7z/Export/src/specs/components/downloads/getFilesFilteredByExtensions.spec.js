import getFilesFilteredByExtensions from '../../../components/downloads/getFilesFilteredByExtensions';
import { ALLOWED_EXTENSIONS } from '../../../components/downloads/downloadsConstants';

describe('Testing file extension filter', () => {
    const sourceFileList = [
        { name: 'file-11.csv.gz', sizeInBytes: '45689' },
        { name: 'file-11.avro', sizeInBytes: '45689' },
        { name: 'file-11.zip', sizeInBytes: '45679' }
    ];

    const expectedFileList = [
        { name: 'file-11.csv.gz', sizeInBytes: '45689' },        
    ]         
  
    it('Should return correct filtered data', () => {
        const filteredFileList = getFilesFilteredByExtensions(sourceFileList,ALLOWED_EXTENSIONS,'name');
        expect(filteredFileList).toEqual(expectedFileList);
    });
});
