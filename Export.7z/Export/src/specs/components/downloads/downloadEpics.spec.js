import { ActionsObservable } from 'redux-observable';
import * as epic from '../../../components/downloads/downloadsEpics';
import {
    downloadActionTypes,
    DATASET_ROOT,
    SECONDARY_ROOTPATHS,
} from '../../../components/downloads/downloadsConstants';
import mockFileListResponse, {
    datasetDetails,
    activePivotFileList,
} from '../../mocks/mockDownloadAPIResponse';

// jest.mock('@scb/riskview-frame/src/services', () => ({
//     logging: {
//         logError: () => undefined,
//     },
// }));

jest.mock('../../../helpers/authentication');
jest.mock('../../../common/config');

describe('Test Mr Reports epics', () => {
    window.fetch = jest.fn();

    const getActionObservable = (type, payload) => ActionsObservable.of({ type, payload });

    const getAjaxResponseBody = mockResponse => ({
        status: '200',
        text: () => Promise.resolve(JSON.stringify(mockResponse)),
        blob: () => Promise.resolve(mockResponse),
    });

    describe('fetchFileList() With one rootpath', () => {
        const fetchFileListAction$ = getActionObservable(downloadActionTypes.FETCH_FILE_LIST, {
            root: SECONDARY_ROOTPATHS[0].value
                .split(';')
                .slice(0, 1)
                .map(p => DATASET_ROOT + p),
        });

        beforeAll(() => {
            window.fetch = jest.fn();
        });

        it('fetchFileList success', done => {
            window.fetch.mockImplementationOnce(() =>
                Promise.resolve(getAjaxResponseBody(mockFileListResponse)),
            );

            const expectedFetchFileListComplete = {
                type: downloadActionTypes.FETCH_FILE_LIST_COMPLETE,
                payload: [
                    {
                        rootPath: `${DATASET_ROOT}stress`,
                        dataSetList: mockFileListResponse,
                    },
                ],
            };

            epic.fetchFileList(fetchFileListAction$).subscribe(receivedData => {
                expect(receivedData).toEqual(expectedFetchFileListComplete);
                done();
            });
        });

        it('fetchFileList() error action', done => {
            const promiseError = new Error('Request didnt succeed');
            window.fetch.mockImplementationOnce(() => Promise.reject(promiseError));

            const expectedFetchFileListError = {
                type: downloadActionTypes.FETCH_FILE_LIST_ERROR,
                payload: { error: promiseError },
            };

            epic.fetchFileList(fetchFileListAction$).subscribe(receivedError => {
                expect(receivedError).toEqual(expectedFetchFileListError);
                done();
            });
        });
    });

    describe('fetchFileList() with multiple rootpaths', () => {
        const getFileListByRootpath = url => {
            if (url === 'undefined/list?root=appsets/marketrisk/active_pivot')
                return Promise.resolve(getAjaxResponseBody(activePivotFileList));
            return Promise.resolve(getAjaxResponseBody(mockFileListResponse));
        };

        const rootPaths = SECONDARY_ROOTPATHS[0].value.split(';').map(p => DATASET_ROOT + p);
        const fetchFileListAction$ = getActionObservable(downloadActionTypes.FETCH_FILE_LIST, {
            root: rootPaths,
        });

        beforeAll(() => {
            window.fetch = jest.fn();
        });

        beforeEach(() => {
            window.fetch.mockReset();
            window.fetch.mockRestore();
            window.fetch.mockReset();
        });

        it.skip('fetchFileList() error action', done => {
            const promiseError = new Error('Request didnt succeed');
            window.fetch.mockImplementationOnce(() => Promise.reject(promiseError));

            const expectedFetchFileListError = {
                type: downloadActionTypes.FETCH_FILE_LIST_ERROR,
                payload: { error: promiseError },
            };

            epic.fetchFileList(fetchFileListAction$).subscribe(receivedError => {
                expect(receivedError).toEqual(expectedFetchFileListError);
                done();
            });
        });

        it('fetchFileList success', done => {
            window.fetch
                .mockImplementationOnce(getFileListByRootpath)
                .mockImplementationOnce(getFileListByRootpath);

            const data = [mockFileListResponse, activePivotFileList];
            const expectedFetchFileListComplete = {
                type: downloadActionTypes.FETCH_FILE_LIST_COMPLETE,
                payload: rootPaths.reduce(
                    (accArr, url, index) => [
                        ...accArr,
                        {
                            rootPath: url,
                            dataSetList: data[index],
                        },
                    ],
                    [],
                ),
            };

            epic.fetchFileList(fetchFileListAction$).subscribe(receivedData => {
                expect(receivedData).toEqual(expectedFetchFileListComplete);
                done();
            });
        });
    });

    describe('fetchFileDetails()', () => {
        beforeAll(() => {
            window.fetch = jest.fn();
        });

        const fetchFileDetailsAction$ = getActionObservable(
            downloadActionTypes.FETCH_FILE_DETAILS,
            {
                datasetId:
                    'appsets/marketrisk/stress/global-missingshocks/Oil_Price_Spike/date=2018-03-23/version=1',
            },
        );

        it('fetchFileDetails() success', done => {
            window.fetch.mockImplementationOnce(() =>
                Promise.resolve(getAjaxResponseBody(datasetDetails)),
            );

            const expectedCompleteAction = {
                type: downloadActionTypes.FETCH_FILE_DETAILS_COMPLETE,
                payload: {
                    datasetId: datasetDetails.dataSetId,
                    files: datasetDetails.blobs,
                },
            };

            epic.fetchFileDetails(fetchFileDetailsAction$).subscribe(receivedAction => {
                expect(receivedAction).toEqual(expectedCompleteAction);
                done();
            });
        });

        it('fetchFileDetails() error action', done => {
            const promiseError = new Error('Request didnt succeed');
            window.fetch.mockImplementationOnce(() => Promise.reject(promiseError));

            const expectedActionError = {
                type: downloadActionTypes.FETCH_FILE_DETAILS_ERROR,
                payload: { error: promiseError },
            };

            epic.fetchFileDetails(fetchFileDetailsAction$).subscribe(receivedError => {
                expect(receivedError).toEqual(expectedActionError);
                done();
            });
        });
    });

    describe('fetchBlobFile()', () => {
        beforeAll(() => {
            window.fetch = jest.fn();
        });

        const fetchBlobFileAction$ = getActionObservable(downloadActionTypes.FETCH_BLOB, {
            datasetId: datasetDetails.dataSetId,
            blobName: datasetDetails.blobs[0].name,
        });

        it('fetchBlobFile() success', done => {
            window.fetch.mockImplementationOnce(() =>
                Promise.resolve(
                    getAjaxResponseBody({
                        data: 'some random binaryData',
                    }),
                ),
            );

            const expectedCompleteAction = {
                type: downloadActionTypes.FETCH_BLOB_COMPLETE,
                payload: {
                    datasetId: datasetDetails.dataSetId,
                    blobName: datasetDetails.blobs[0].name,
                    blob: {
                        data: 'some random binaryData',
                    },
                },
            };

            epic.fetchBlobFile(fetchBlobFileAction$).subscribe(receivedAction => {
                expect(receivedAction).toEqual(expectedCompleteAction);
                done();
            });
        });

        it('fetchBlobFile() error action', done => {
            const promiseError = new Error('Request didnt succeed');
            window.fetch.mockImplementationOnce(() => Promise.reject(promiseError));

            const expectedActionError = {
                type: downloadActionTypes.FETCH_BLOB_ERROR,
                payload: { error: promiseError },
            };

            epic.fetchBlobFile(fetchBlobFileAction$).subscribe(receivedError => {
                expect(receivedError).toEqual(expectedActionError);
                done();
            });
        });
    });
});
