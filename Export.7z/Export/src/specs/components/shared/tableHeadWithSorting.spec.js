import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import { TableHeadWithSorting } from '../../../components/shared/tableHeadWithSorting';
import scenarioColumnDefs from '../../../components/scenarioManager/scenarioColumnDefinitions';

const columnDefs = scenarioColumnDefs.map(columnDef => {
    if (columnDef.key === 'validFrom') {
        return {
            ...columnDef,
            sortable: false,
        };
    }
    return columnDef;
});

describe('Table Heading component', () => {
    const initialProps = {
        sortHandler: () => undefined,
        order: 'desc',
        orderBy: 'modifiedBy',
        columnDefs,
    };
    const createSortHandler = jest.spyOn(TableHeadWithSorting.prototype, 'createSortHandler');
    const wrapper = shallow(<TableHeadWithSorting { ...initialProps } />).at(0).shallow();
    
    it('should render without error', () => {
        expect(toJson(wrapper)).toMatchSnapshot();
    });

    it('removes sort label from column heading if column is not sortable', () => {
        const validFromNode = wrapper.find('tr th').filterWhere(th => th.key() === 'validFrom');
        expect(validFromNode.find(TableSortLabel)).toHaveLength(0);
    });

    it('defaults the sort column to the orderBy prop', () => {
        const defaultSortNode = wrapper.find('tr th').filterWhere(th => th.key() === initialProps.orderBy);
        expect(defaultSortNode.find(TableSortLabel).props().active).toBe(true);
    });

    it('defaults the sort order to the order prop', () => {
        const defaultSortNode = wrapper.find('tr th').filterWhere(th => th.key() === initialProps.orderBy);
        expect(defaultSortNode.find(TableSortLabel).props().direction).toBe(initialProps.order);
    });

    describe('clicking a column heading', () => {
        it('calls createSortHandler()', () => {
            const nodes = wrapper.find(TableSortLabel);
            nodes.forEach(tbSl => {
                tbSl.simulate('click');
            });
            expect(createSortHandler).toHaveBeenCalledTimes(nodes.length);
        });
    });

    afterEach(() => {
        // jest.restoreAllMocks();
    });
});
