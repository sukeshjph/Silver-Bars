import React from 'react';
import { shallow } from 'enzyme';
import ReportIcon from '@material-ui/icons/Report';
import ErrorMessage from '../../../components/shared/errorMessage';

describe('Error Message', () => {
    let wrapper;

    const setup = () => {
        wrapper = shallow(<ErrorMessage message="test message" />);
    };

    beforeEach(() => {
        setup();
    });

    it('displays an error message', () => {
        expect(wrapper.find('.stress__error').text()).toContain('test message');
    });

    it('uses an optional className', () => {
        wrapper = shallow(<ErrorMessage className="test-class-name" message='test message' />);
        expect(wrapper.hasClass('stress__error')).toBe(true);
        expect(wrapper.hasClass('test-class-name')).toBe(true);
    });

    it('displays an icon', () => {
        expect(wrapper.find(ReportIcon)).toHaveLength(1);
    });

    it('can be important', () => {
        wrapper = shallow(<ErrorMessage important message='test message' />);
        expect(wrapper.find('.stress__error--important')).toHaveLength(1);
    });

});