import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import ScenarioVersionsTable from '../../../components/scenarioManager/scenarioVersionsTable';
import mockScenarioVersions from '../../mocks/mockScenarioWithVersions';

jest.mock('shortid', () => ({
    generate: jest.fn(() => 1),
}));

describe('Scenario File Versions component', () => {
    const initialProps = {
        approvedScenarios: mockScenarioVersions.scenarioVersions,
        userCanEdit: true,
        isFetchingDiff: true,
        fetchDiffError: '',
        diff: {},
        setActiveFileVersion: jest.fn(),
        fetchDiff: jest.fn(),
        currentActiveFileVersion: 1,
    };
    let wrapper;
    
    beforeEach(() => {
        initialProps.setActiveFileVersion = jest.fn();
        wrapper = shallow(<ScenarioVersionsTable { ...initialProps }/>);
    });
     
    it('should render without error', () => {
        expect(toJson(wrapper)).toMatchSnapshot();
    });

    it('sets selected file version when radio changes', () => {
        const targetFile = initialProps.approvedScenarios[0];
        const spy = jest.spyOn(initialProps, 'setActiveFileVersion');
        wrapper.find('.stress--version-radio').at(0).simulate('change');
        expect(wrapper.state('currentlySelected')).toBe(targetFile.activeFileVersion);
        expect(spy).toHaveBeenCalledWith(targetFile.activeFileVersion, targetFile.category);
    });

    it('toggles the compare dialog', () => {
        wrapper.setState({
            comparing: [{}, {}],
        });
        wrapper.instance().compareHandler();
        expect(wrapper.state('inCompareMode')).toBe(true);
    });

    describe('adding a file to the comparison list', () => {
        const file1 = {
            category: 'Global',
        };
        const file2 = {
            category: 'Global',
        };
        const file3 = {
            category: 'Local',
        };
        const file4 = {
            category: 'Global',
        };
        it('adds the file to state.compare', () => {
            wrapper.instance().addToCompareList(file1);
            expect(wrapper.state('comparing')).toEqual([file1]);
        });
        it('disables the compare button unless two files are added', () => {
            wrapper.instance().addToCompareList(file1);
            expect(wrapper.state('disableCompareButton')).toBe(true);
            wrapper.instance().addToCompareList(file2);
            expect(wrapper.state('disableCompareButton')).toBe(false);
        });
        it('disables the compare button if there is an error', () => {
            wrapper.instance().addToCompareList(file1);
            wrapper.instance().addToCompareList(file3);
            expect(wrapper.state('disableCompareButton')).toBe(true);
        });
        it('displays an error if files are different types', () => {
            wrapper.instance().addToCompareList(file1);
            wrapper.instance().addToCompareList(file3);
            expect(wrapper.state('displayError')).toBe(true);
        });
        it('ensures files to compare are unique', () => {
            wrapper.instance().addToCompareList(file1);
            wrapper.instance().addToCompareList(file1);
            expect(wrapper.state('comparing')).toHaveLength(1);
        });
        it('prevents user adding more than two files', () => {
            wrapper.instance().addToCompareList(file1);
            wrapper.instance().addToCompareList(file2);
            wrapper.instance().addToCompareList(file4);
            expect(wrapper.state('comparing')).toEqual([file2, file4]);
        });
        it('enables the compare button if everything is ok', () => {
            wrapper.instance().addToCompareList(file1);
            wrapper.instance().addToCompareList(file2);
            expect(wrapper.state('disableCompareButton')).toBe(false);
        });
        it('triggers the handler when the icon is clicked', () => {
            const spy = jest.spyOn(wrapper.instance(), 'addToCompareList');
            const icon = wrapper.find('.stress-table--compare-button').at(0);
            icon.simulate('click');
            expect(spy).toHaveBeenCalled();
        });
    });

});
