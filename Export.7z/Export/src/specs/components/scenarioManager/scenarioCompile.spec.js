import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import {
    SCENARIO_COMPILATION_STATES,
    filePicker,
} from '../../../components/scenarioManager/scenarioConstants';
import ScenarioCompile from '../../../components/scenarioManager/scenarioCompile';
import TooltipButton from '../../../components/shared/tooltipButton';

describe('compile scenario file', () => {
    const initialProps = {
        data: {
            compilationResult: { result: '', message: '' },
            isCompilingScenario: false,
            isScenarioCompiled: false,
            enableCompilation: false,
        },
        model: {
            cancelCompilation: () => undefined,
            compileScenario: () => undefined,
        },
    };

    let wrapper;

    const setup = props => {
        wrapper = shallow(<ScenarioCompile {...props} />);
    };

    it('should render compile button', () => {
        setup(initialProps);
        expect(toJson(wrapper)).toMatchSnapshot();
    });

    describe('compile button status', () => {
        setup(initialProps);

        it('compile button disabled initially', () => {
            expect(wrapper.find(TooltipButton).props().disabled).toBeTruthy();
        });

        it('enabled when valid file is chosen', () => {
            const newProps = {
                ...initialProps,
                data: {
                    ...initialProps.data,
                    enableCompilation: true,
                },
            };
            wrapper.setProps(newProps);
            expect(wrapper.find(TooltipButton).props().disabled).toBeFalsy();
        });
    });

    it('when compiling a scenario', () => {
        setup({
            ...initialProps,
            data: {
                ...initialProps.data,
                isCompilingScenario: true,
            },
        });
        expect(
            wrapper
                .find(TooltipButton)
                .props()
                .className.includes(`${filePicker}__compile-cancelbtn`),
        ).toBeTruthy();
    });

    it('sends for compilation when clicked', () => {
        const compileScenario = jest.fn();
        setup({
            ...initialProps,
            data: { ...initialProps.data, enableCompilation: true },
            model: { ...initialProps.model, compileScenario },
        });
        const compileBtn = wrapper
            .find(TooltipButton)
            .findWhere(
                n =>
                    n.props().className &&
                    n.props().className.includes(`${filePicker}__compile-btn`),
            )
            .dive()
            .childAt(0);
        compileBtn.simulate('click');
        expect(compileScenario).toHaveBeenCalled();
    });

    describe('error or success image', () => {
        const getCompilerStatusImage = jest.spyOn(
            ScenarioCompile.prototype,
            'getCompilerStatusImage',
        );
        setup(initialProps);

        afterEach(() => {
            getCompilerStatusImage.mockClear();
        });

        it('when failed/passed', () => {
            wrapper.setProps({
                ...initialProps,
                data: {
                    ...initialProps.data,
                    isScenarioCompiled: true,
                    compilationResult: {
                        result: SCENARIO_COMPILATION_STATES.FAILED,
                        message: 'It has failed',
                    },
                },
            });

            expect(getCompilerStatusImage).toHaveBeenCalled();
        });

        it('when not compiled', () => {
            wrapper.setProps({
                ...initialProps,
                data: {
                    ...initialProps.data,
                    isScenarioCompiled: false,
                    compilationResult: {
                        result: '',
                        message: '',
                    },
                },
            });

            expect(getCompilerStatusImage).not.toHaveBeenCalled();
        });
    });
});
