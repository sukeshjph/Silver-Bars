import _ from 'lodash';
import { tableSorter } from '../../helpers/tableSorter';

describe('sorting data', () => {
    let state;

    beforeEach(() => {
        state = {
            order: 'desc',
            orderBy: 'name',
            audits: [
                { name: 'a', comment: 'b' },
                { name: 'b', comment: 'c' },
                { name: 'c', comment: 'a' },
            ],
        };
    });
    it('toggles between ascending / descending', () => {
        let results = tableSorter(state, 'name', 'audits');
        expect(results.order).toBe('asc');

        state.order = 'asc';
        results = tableSorter(state, 'name', 'audits');
        expect(results.order).toBe('desc');
    });
    it('sorts by column type', () => {
        const results = tableSorter(state, 'comment', 'audits');
        expect(results.data).toEqual(_.sortBy(state.audits, 'comment'));
    });
    it('reverses order of audits if sorting by desc', () => {
        state.order = 'asc';
        const results = tableSorter(state, 'name', 'audits');
        expect(results.data).toEqual(_.reverse(state.audits));
        expect(results.order).toBe('desc');
    });
    it('returns orderBy', () => {
        const results = tableSorter(state, 'name', 'audits');
        expect(results.orderBy).toEqual('name');
    });
});
