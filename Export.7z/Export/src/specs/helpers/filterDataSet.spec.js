import filterDataSet from '../../helpers/filterDataSet';

describe('Testing filter Dataset', () => {
    const sourceDataSetList = [
        {
            type: 'Scenario',
            id: '108162',
            ukId: '107996',
            comments: 'new file............',
            validFrom: '2018-04-06 09:49:56.620',
            validTo: '9999-12-31 00:00:00.511',
            modifiedBy: '1576103',
            addedBy: 'SMR_DEV_RO',
            name: 'Bond_Armageddon',
            description: 'Bond Armageddon 11.0',
            action: 'UPDATE',
            activeFileVersion: 2,
            category: 'Global',
        },
        {
            type: 'Scenario',
            id: '108230',
            ukId: '108006',
            comments: 'CNY desc updated',
            validFrom: '2018-04-16 07:25:59.357',
            validTo: '9999-12-31 00:00:00.392',
            modifiedBy: '1545727',
            addedBy: 'SMR_DEV_RO',
            name: 'CNY',
            description: 'CNY Rout 11.0 - update',
            action: 'UPDATE',
            activeFileVersion: 2,
            category: undefined,
        },
        {
            type: 'Scenario',
            id: '108216',
            ukId: '108200',
            comments: 'change to global',
            validFrom: '2018-04-16 03:38:31.261',
            validTo: '9999-12-31 00:00:00.392',
            modifiedBy: '1545727',
            addedBy: '1545727',
            name: 'Compare-16th Apr',
            description: 'Scenario comparison test',
            action: 'UPDATE',
            activeFileVersion: 8,
            category: 'Global',
        }
    ];

    let filterText = 'CNY';
    let expectedFileList = [
        {
            type: 'Scenario',
            id: '108230',
            ukId: '108006',
            comments: 'CNY desc updated',
            validFrom: '2018-04-16 07:25:59.357',
            validTo: '9999-12-31 00:00:00.392',
            modifiedBy: '1545727',
            addedBy: 'SMR_DEV_RO',
            name: 'CNY',
            description: 'CNY Rout 11.0 - update',
            action: 'UPDATE',
            activeFileVersion: 2,
            category: undefined,
        }
    ];

    it('returns items which contain the search string', () => {
        const filteredFileList = filterDataSet(filterText, sourceDataSetList);
        expect(filteredFileList).toEqual(expectedFileList);
    });

    it('trims whitespace from the search string', () => {
        filterText = `    ${filterText}   `;
        const filteredFileList = filterDataSet(filterText, sourceDataSetList);
        expect(filteredFileList).toEqual(expectedFileList);
    });

    it('filters by object property passed as third parameter', () => {
        const filteredFileList = filterDataSet('CNY', sourceDataSetList, 'name');
        expect(filteredFileList).toEqual([sourceDataSetList[1]]);
    });

    it('returns correct filtered item with null values', () => {
        filterText = '1545727';
        expectedFileList = [
            {
                type: 'Scenario',
                id: '108230',
                ukId: '108006',
                comments: 'CNY desc updated',
                validFrom: '2018-04-16 07:25:59.357',
                validTo: '9999-12-31 00:00:00.392',
                modifiedBy: '1545727',
                addedBy: 'SMR_DEV_RO',
                name: 'CNY',
                description: 'CNY Rout 11.0 - update',
                action: 'UPDATE',
                activeFileVersion: 2,
                category: undefined,
            },
            {
                type: 'Scenario',
                id: '108216',
                ukId: '108200',
                comments: 'change to global',
                validFrom: '2018-04-16 03:38:31.261',
                validTo: '9999-12-31 00:00:00.392',
                modifiedBy: '1545727',
                addedBy: '1545727',
                name: 'Compare-16th Apr',
                description: 'Scenario comparison test',
                action: 'UPDATE',
                activeFileVersion: 8,
                category: 'Global',
            }
        ];
        
        const filteredFileList = filterDataSet(filterText, sourceDataSetList);
        expect(filteredFileList).toEqual(expectedFileList);
    });
});
