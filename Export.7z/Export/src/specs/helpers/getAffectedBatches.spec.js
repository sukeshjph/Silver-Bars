import getAffectedBatches from '../../helpers/getAffectedBatches';


// The method takes a scenario and an array of batches
// to establish whether the scenario exists in any of batches.

describe('the "getAffectedBatches" helper', () => {
    it('returns an empty string if no scenario param is passed', () => {
        expect(getAffectedBatches([])).toBe('');
    });
    describe('scenario exists in batches array', () => {
        const scenario = { ukId: 1 };
        const batches = [
            { name: 'Monday', scenarios: [{ ukId: 1 }, { ukId: 6 }, { ukId: 7 }] },
            { name: 'Tuesday', scenarios: [{ ukId: 1 }, { ukId: 2 }, { ukId: 3 }] },
            { name: 'Wednesday', scenarios: [{ ukId: 1 }, { ukId: 4 }, { ukId: 5 }] },
            { name: 'Thursday', scenarios: [{ ukId: 2 }] },
            { name: 'Friday', scenarios: [{ ukId: 1 }, { ukId: 2 }, { ukId: 3 }] },
        ];
        it('returns a string listing the affected batches', () => {
            expect(getAffectedBatches(batches, scenario)).toBe(
                'Batches affected by this action: Monday, Tuesday, Wednesday, Friday'
            );
        });
        it('returns an array of the affected batches', () => {
            expect(getAffectedBatches(batches, scenario, true)).toEqual(
                ['Monday', 'Tuesday', 'Wednesday', 'Friday']
            );
        });
    });
    describe('scenario does not exist in batches array', () => {
        const scenario = { ukId: 8 };
        const batches = [
            { name: 'Monday', scenarios: [{ ukId: 1 }, { ukId: 6 }, { ukId: 7 }] },
            { name: 'Tuesday', scenarios: [{ ukId: 1 }, { ukId: 2 }, { ukId: 3 }] },
            { name: 'Wednesday', scenarios: [{ ukId: 1 }, { ukId: 4 }, { ukId: 5 }] },
        ];
        it('returns an empty string', () => {
            expect(getAffectedBatches(batches, scenario)).toBe('');
        });
    });
});