import { diffActionTypes } from '../../constants';
import reducer from '../../reducers/diffReducer';

const initialState = {
    diff: {},
    isFetchingDiff: false,
    fetchDiffError: '',
};

describe('Diff reducer', () => {
    it('returns the initial state', () => {
        expect(reducer(undefined, {})).toEqual(initialState);
    });

    describe('FETCH_DIFF reducer', () => {
        const action = {
            type: diffActionTypes.FETCH_DIFF,
        };
        it('sets loading flags to true', () => {
            expect(reducer(initialState, action).isFetchingDiff).toEqual(true);
        });
        it('resets the error message', () => {
            const state = {
                ...initialState,
                fetchDiffError: 'some error',
            };
            expect(reducer(state, action).fetchDiffError).toEqual('');
        });
    });

    describe('FETCH_DIFF_COMPLETE reducer', () => {
        const action = {
            type: diffActionTypes.FETCH_DIFF_COMPLETE,
            payload: {
                diff: {},
            },
        };
        const state = {
            ...initialState,
            isFetchingDiff: true,
        };
        it('sets loading flags to false', () => {
            expect(reducer(state, action).isFetchingDiff).toEqual(false);
        });
        it('adds the diff results to the state', () => {
            expect(reducer(state, action).diff.comparison).toEqual(action.payload.diff.comparison);
        });
        it('adds ukId to the diff', () => {
            expect(reducer(state, action).diff.ukId).toEqual(action.payload.ukId);
        });
    });

    describe('FETCH_DIFF_ERROR reducer', () => {
        const action = {
            type: diffActionTypes.FETCH_DIFF_ERROR,
            payload: { error: 'Some server error' },
        };
        const state = {
            isFetchingDiff: true,
        };
        it('sets loading flags to false', () => {
            expect(reducer(state, action).isFetchingDiff).toEqual(false);
        });
        it('returns the error', () => {
            expect(reducer(state, action).fetchDiffError).toEqual(action.payload.error);
        })
    });
});
