export const fileListPayload = [
    {
        rootPath: 'appsets/marketrisk/stress',
        dataSetList: [
            {
                dataSetId: 'appsets/marketrisk/stress/errors/global/date=2018-02-26/version=1',
                modificationTime: '2018-03-29T12:32:57Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/shockType=global/Bond_Armageddon/cobDate=2018-03-23/version=1',
                modificationTime: '2018-06-16T20:20:57Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global-missingshocks/Oil_Price_Spike/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T15:09:52Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/shockType=global/Middle_East_War/runDate=2018-03-23/cobDate=2018-03-23/version=1',
                modificationTime: '2018-06-16T20:20:03Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/shockType=global/Oil_Price_Slump/cobDate=2018-03-23/runDate=2018-03-23/version=1',
                modificationTime: '2018-06-16T20:20:28Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/shockType=global/Oil_Price_Spike/runDate=2018-03-23/cobDate=2018-03-23/version=1',
                modificationTime: '2018-06-16T20:18:59Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/shockType=global/shockName=Acrimonious_Brexit_Triggers_Global_Risk_Aversion/reportName=trades/cobDate=2018-03-23/version=1',
                modificationTime: '2018-06-16T20:31:12Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/shockType=global/shockName=Bond_Armageddon/reportName=trades/cobDate=2018-03-23/version=1',
                modificationTime: '2018-06-16T20:32:42Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/shockType=global/shockName=Middle_East_War/reportName=trades/cobDate=2018-03-23/version=1',
                modificationTime: '2018-06-16T20:31:40Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/shockType=global/shockName=Oil_Price_Slump/reportName=trades/cobDate=2018-03-23/version=1',
                modificationTime: '2018-06-16T20:32:13Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/summary/sensitivity/date=2018-03-16/version=1',
                modificationTime: '2018-05-15T13:32:31Z',
            },
        ],
    },
    {
        rootPath: 'appsets/marketrisk/active_pivot',
        dataSetList: [
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-10/version=1',
                modificationTime: '2018-05-11T00:42:54Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-14/version=1',
                modificationTime: '2018-05-15T00:37:12Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-16/version=1',
                modificationTime: '2018-05-17T00:39:41Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-17/version=1',
                modificationTime: '2018-05-18T00:40:24Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-22/version=1',
                modificationTime: '2018-05-23T00:39:52Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-23/version=1',
                modificationTime: '2018-05-24T00:40:19Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-07/version=1',
                modificationTime: '2018-06-08T00:09:32Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-08/version=1',
                modificationTime: '2018-06-09T00:11:11Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-11/version=1',
                modificationTime: '2018-06-12T00:23:15Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-12/version=1',
                modificationTime: '2018-06-13T00:11:22Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-13/version=1',
                modificationTime: '2018-06-14T00:13:10Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-08-14/version=1',
                modificationTime: '2018-08-14T21:02:45Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/sensitivities/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T12:16:16Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/sensitivities/date=2018-04-05/version=1',
                modificationTime: '2018-04-09T12:25:59Z',
            },
        ],
    },
];
