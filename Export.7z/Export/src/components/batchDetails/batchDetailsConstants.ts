// import { NAME } from '../../constants';

type criteria = {
    name: string;
    type: string;
    data: string[];
};

type IPCTNodeConstant = {
    className: string;
    columns: string[];
    criteria: criteria[];
    options: string[];
};

// State constants
export const SCENARIO_LIMIT: number = 40;
export const PATHS_LIMIT: number = 1;
export const BATCH_SORT_ORDER: string[] = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Paths',
    'smoketest',
];

// Batch action types
export const batchActionTypes = {
    FETCH_BATCH_AND_SCENARIOS: 'STRESS/FETCH_BATCH_AND_SCENARIOS',
    FETCH_BATCH_AND_SCENARIOS_COMPLETE: 'STRESS/FETCH_BATCH_AND_SCENARIOS_COMPLETE',
    FETCH_BATCH_AND_SCENARIOS_ERROR: 'STRESS/FETCH_BATCH_AND_SCENARIOS_ERROR',
    FETCH_PCT_NODES: 'STRESS/FETCH_PCT_NODES',
    FETCH_PCT_NODES_COMPLETE: 'STRESS/FETCH_PCT_NODES_COMPLETE',
    FETCH_PCT_NODES_ERROR: 'STRESS/FETCH_PCT_NODES_ERROR',
    SAVE_BATCH: 'STRESS/SAVE_BATCH',
    SAVE_BATCH_COMPLETE: 'STRESS/SAVE_BATCH_COMPLETE',
    SAVE_BATCH_ERROR: 'STRESS/SAVE_BATCH_ERROR',
    ADD_SCENARIO_TO_BATCH: 'STRESS/ADD_SCENARIO_TO_BATCH',
    REMOVE_SCENARIO_FROM_BATCH: 'STRESS/REMOVE_SCENARIO_FROM_BATCH',
} as const;

export const pctNodeRequestBody: IPCTNodeConstant = {
    className: 'SD_PCT_PORTFOLIO',
    columns: ['BUSINESS_HIERARCHYL0', 'BUSINESS_HIERARCHYL1'],
    criteria: [
        { name: 'IS_ACTIVE', type: 'STRING', data: ['Y'] },
        { name: 'SOURCE_SYSTEM', type: 'STRING', data: ['MUREX', 'SABRE'] },
    ],
    options: ['Blame', 'Master'],
};

export const ScenarioListTypes = { Available: 'Available', Added: 'Added' } as const;
