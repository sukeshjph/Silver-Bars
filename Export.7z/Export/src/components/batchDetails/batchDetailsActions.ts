import { createAction, createStandardAction } from 'typesafe-actions';
import { pick } from '../../helpers/utilities';
import { batchActionTypes } from './batchDetailsConstants';
import { IBatch, IScenario } from '../../interfaces/globals';
import { ErrorType } from './batchDetails.types';

// Fetch all batch and scenarios
export const fetchBatchAndScenarios = createAction(
    batchActionTypes.FETCH_BATCH_AND_SCENARIOS,
    action => {
        return (batchUkId: string, asOf: string) => action({ batchUkId, asOf });
    },
);

export const fetchBatchAndScenariosComplete = createAction(
    batchActionTypes.FETCH_BATCH_AND_SCENARIOS_COMPLETE,
    action => {
        return (batchScenarios: {
            batch: IBatch | {};
            batches: IBatch[];
            batchAudits?: any;
            scenarios: IScenario[];
            pendingScenarios: IScenario[];
            pctNodes: any;
        }) => action(batchScenarios);
    },
);

export const fetchBatchAndScenariosError = createStandardAction(
    batchActionTypes.FETCH_BATCH_AND_SCENARIOS_ERROR,
)<ErrorType>();

// Save Batch
export const saveBatch = createAction(
    batchActionTypes.SAVE_BATCH,
    action => (batch: Partial<IBatch>) =>
        action({
            batch: pick(batch, [
                'type',
                'id',
                'ukId',
                'comments',
                'name',
                'scenarios',
                'cobDate',
                'pctNode',
                'pctNodeId',
                'scheduleDto',
            ]),
        }),
);

export const saveBatchComplete = createStandardAction(batchActionTypes.SAVE_BATCH_COMPLETE)<{
    batch: IBatch;
}>();

export const saveBatchError = createStandardAction(batchActionTypes.SAVE_BATCH_ERROR)<ErrorType>();

// Fetch PCT Nodes
export const fetchPctNodes = createStandardAction(batchActionTypes.FETCH_PCT_NODES)();

export const fetchPctNodesComplete = createStandardAction(
    batchActionTypes.FETCH_PCT_NODES_COMPLETE,
).map((pctbody: { pctHeaders: any; pctData: any }) => ({
    payload: pctbody,
}));

export const fetchPctNodesError = createStandardAction(batchActionTypes.FETCH_PCT_NODES_ERROR)<
    ErrorType
>();
