/* eslint-disable react/destructuring-assignment  */
import React from 'react';
import PropTypes from 'prop-types';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import moment from 'moment';
import CalendarIcon from '@material-ui/icons/Event';
import UndoIcon from '@material-ui/icons/Undo';
import '../../styles/dateRangePicker.scss';

import { API_DATE_FORMAT } from '../../constants';

class BatchCoBDate extends React.PureComponent {
    static propTypes = {
        batchCoBDate: PropTypes.string,
        editable: PropTypes.bool.isRequired,
        hasCoBDateChanged: PropTypes.bool.isRequired,
        handleCoBDateChange: PropTypes.func.isRequired,
        handleUndoCoBDateChange: PropTypes.func.isRequired,
    };

    constructor(props) {
        super(props);
        this.state = {
            batchCoBDate: props.batchCoBDate,
        };
        this.handleCoBDateChange = this.handleCoBDateChange.bind(this);
        this.handleDefaultCoBDate = this.handleDefaultCoBDate.bind(this);
    }

    static getDerivedStateFromProps(nextProps, prevState) {
        if (nextProps.batchCoBDate !== prevState.batchCoBDate) {
            return {
                batchCoBDate: nextProps.batchCoBDate,
            };
        }

        return null;
    }

    handleCoBDateChange(batchCoBDate) {
        this.props.handleCoBDateChange(batchCoBDate.format(API_DATE_FORMAT));
    }

    handleDefaultCoBDate() {
        this.props.handleCoBDateChange(null);
    }

    render() {
        const { batchCoBDate } = this.state;
        return (
            <div className="stress-batch__dashboard__item">
                <div className="stress-batch__cob-date stress-batch__dashboard__row">
                    <h4 className="stress-batch__dashboard__item__title">Past COB:</h4>
                    <div className="stress__dashboard__field">
                        {this.props.editable && (
                            <React.Fragment>
                                <DatePicker
                                    selectsStart
                                    selected={
                                        batchCoBDate
                                            ? moment(this.state.batchCoBDate, API_DATE_FORMAT)
                                            : null
                                    }
                                    onChange={this.handleCoBDateChange}
                                    dateFormat="DD/MM/YYYY"
                                    className="stress__dashboard__input stress-batch__cob-date__calendar"
                                    placeholderText="Using default CoB date"
                                    maxDate={moment().subtract(1, 'days')}
                                    minDate={moment().subtract(1, 'year')}
                                    readOnly
                                />
                                <button
                                    disabled={!batchCoBDate}
                                    onClick={this.handleDefaultCoBDate}
                                    className="stress-batch__cob-date__clear stress__dashboard__button"
                                    type="button"
                                >
                                    <CalendarIcon />
                                    Clear
                                </button>
                                {this.props.hasCoBDateChanged && (
                                    <button
                                        onClick={this.props.handleUndoCoBDateChange}
                                        className="stress-batch__cob-date__undo stress__dashboard__button"
                                        type="button"
                                    >
                                        <UndoIcon /> Undo
                                    </button>
                                )}
                            </React.Fragment>
                        )}
                        {!this.props.editable && (
                            <input
                                type="text"
                                className="stress-batch__cob-date__text"
                                value={this.state.batchCoBDate || 'Default'}
                            />
                        )}
                    </div>
                </div>
                {this.props.children}
            </div>
        );
    }
}

BatchCoBDate.defaultProps = {
    batchCoBDate: null,
};

export default BatchCoBDate;
