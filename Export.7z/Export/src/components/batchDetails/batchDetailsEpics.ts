import { of, forkJoin } from 'rxjs';
import { mergeMap, catchError, map, filter } from 'rxjs/operators';
import { combineEpics, Epic } from 'redux-observable';
import { isActionOf } from 'typesafe-actions';
import { pctNodeRequestBody } from './batchDetailsConstants';
import { BatchDetailsRootActions } from './batchDetails.types';
import * as BatchDetailsActions from './batchDetailsActions';
import { getConfig } from '../../common/config';
import http from '../../helpers/http';

const fetchBatchAndScenarios: Epic<BatchDetailsRootActions> = action$ =>
    action$.pipe(
        filter(isActionOf(BatchDetailsActions.fetchBatchAndScenarios)),
        mergeMap(action => {
            const { batchUkId, asOf } = action.payload;
            return forkJoin(
                http.getData(
                    `${getConfig().SdxService}/batchmanagement/Batch/ukId/${batchUkId}${
                        asOf !== 'now' ? `?asOf=${asOf}` : ''
                    }`.trimRight(),
                ),
                http.getData(`${getConfig().SdxService}/batchmanagement/Batch`),
                http.getData(`${getConfig().SdxService}/batchmanagement/Scenario`),
                http.getData(`${getConfig().SdxService}/batchmanagement/Scenario?status=pending`),
            ).pipe(
                map((data: any) => ({
                    batch: data[0].length !== 0 ? data[0][0] : {},
                    batches: data[1],
                    scenarios: data[2],
                    pendingScenarios: data[3],
                    pctNodes: data[3],
                })),
                map(finaldata => BatchDetailsActions.fetchBatchAndScenariosComplete(finaldata)),
                catchError(error => of(BatchDetailsActions.fetchBatchAndScenariosError({ error }))),
            );
        }),
    );

const fetchPctNodes: Epic<BatchDetailsRootActions> = action$ =>
    action$.pipe(
        filter(isActionOf(BatchDetailsActions.fetchPctNodes)),
        mergeMap(() =>
            http.getDataFromMDS(`${getConfig().MdsService}/queryMaster`, pctNodeRequestBody).pipe(
                map(data =>
                    BatchDetailsActions.fetchPctNodesComplete({
                        pctHeaders: data.columnHeaders,
                        pctData: data.relationData,
                    }),
                ),
                catchError(error =>
                    of(
                        BatchDetailsActions.fetchPctNodesError({
                            error: `Unable to fetch PCT node tree: ${error}`,
                        }),
                    ),
                ),
            ),
        ),
    );

const saveBatch: Epic<BatchDetailsRootActions> = action$ =>
    action$.pipe(
        filter(isActionOf(BatchDetailsActions.saveBatch)),
        mergeMap(action =>
            http
                .postData(
                    `${getConfig().SdxService}/batchmanagement/Batch/update`,
                    action.payload.batch,
                )
                .pipe(
                    map(batch =>
                        BatchDetailsActions.saveBatchComplete({
                            batch,
                        }),
                    ),
                    catchError(error =>
                        of(
                            BatchDetailsActions.saveBatchError({
                                error,
                            }),
                        ),
                    ),
                ),
        ),
    );

export default combineEpics(fetchPctNodes, fetchBatchAndScenarios, saveBatch);
