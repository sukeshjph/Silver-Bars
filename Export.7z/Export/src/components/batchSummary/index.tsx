import React, { FunctionComponent } from 'react';
import { RootState } from 'typesafe-actions';
import { connect } from 'react-redux';
import { createSelector } from 'reselect';
import { bindActionCreators } from 'redux';
import * as BatchSummaryActions from './batchSummaryActions';
import { BatchSummaryProps } from './batchSummary.types';
import BatchList from './batchList';

import './batchSummary.scss';

const getAllBatches = createSelector(
    (state: RootState) => state.BATCHES,
    ({ batches: batchList, isFetchingBatches, error }) => ({
        batchList,
        isFetchingBatches,
        error,
    }),
);

const BatchSummary: FunctionComponent = React.memo(props => (
    <BatchList {...props as BatchSummaryProps} />
));

export default connect(
    (state: RootState) => ({
        model: getAllBatches(state),
    }),
    dispatch => ({ actions: bindActionCreators(BatchSummaryActions, dispatch) }),
)(BatchSummary);
