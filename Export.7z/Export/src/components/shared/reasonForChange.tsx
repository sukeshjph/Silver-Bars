/* eslint-disable react/destructuring-assignment  */
import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import UndoIcon from '@material-ui/icons/Undo';
import SaveIcon from '@material-ui/icons/Save';
import DoneIcon from '@material-ui/icons/Done';
import LoadingButton from './loadingButton';
import ErrorMessage from './errorMessage';
import getFormFieldClass from '../../helpers/getFormFieldClass';

class ReasonForChange extends React.PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            changeReason: this.props.model.comments || '',
            saveActionCompleted: false,
            isSaving: false,
            saveErrorMessage: '',
            touched: false,
        };
        this.handleReasonForChangeUpdate = this.handleReasonForChangeUpdate.bind(this);
        this.handleUndoClick = this.handleUndoClick.bind(this);
        this.reset = this.reset.bind(this);
    }

    componentWillReceiveProps({ model: { isSaving, comments, saveErrorMessage } }) {
        if (
            isSaving !== this.state.isSaving ||
            comments !== this.state.comments ||
            saveErrorMessage !== this.state.saveErrorMessage
        ) {
            this.setState(prevState => ({
                isSaving,
                changeReason: comments || prevState.changeReason,
                saveActionCompleted: this.hasSavedActionCompleted(isSaving, saveErrorMessage),
                saveErrorMessage,
            }));
        }
    }

    // Save action is only complete if save action completed with no error
    hasSavedActionCompleted = (nextIsSavingStatus, saveErrorMessage) =>
        this.state.isSaving === true && nextIsSavingStatus === false && !saveErrorMessage;

    handleReasonForChangeUpdate(e) {
        this.setState({
            touched: true,
            changeReason: e.target.value,
        });
    }

    handleSaveClick(changeReason) {
        const {
            actions: { handleSaveClick },
        } = this.props;
        handleSaveClick(changeReason);
    }

    handleUndoClick() {
        const {
            actions: { handleUndoClick },
        } = this.props;
        this.setState(
            {
                changeReason: '',
            },
            handleUndoClick,
        );
    }

    reset() {
        const {
            actions: { handleDoneClick },
        } = this.props;
        this.setState(
            {
                changeReason: '',
                saveActionCompleted: false,
                saveErrorMessage: '',
            },
            () => handleDoneClick(true),
        );
    }

    isFormValid() {
        const {
            model: { isValid },
        } = this.props;

        const { changeReason } = this.state;
        const validationRules = [
            changeReason.length >= 20,
            _.isUndefined(isValid) ? true : isValid,
        ];
        return _.every(validationRules);
    }

    render() {
        const {
            changeReason,
            saveActionCompleted,
            isSaving,
            saveErrorMessage,
            touched,
        } = this.state;
        const {
            model: { saveSuccessMessage },
        } = this.props;
        const isFormValid = this.isFormValid();

        return (
            <div className="reason-for-change">
                <div className="reason-for-change__actions">
                    <div className={getFormFieldClass(!(touched && changeReason.length < 20))}>
                        <label className="stress__form__label">
                            Please provide a reason for this change
                        </label>
                        <input
                            type="text"
                            className="stress__form__input"
                            value={changeReason}
                            onChange={e => this.handleReasonForChangeUpdate(e)}
                            disabled={saveActionCompleted}
                        />
                        <p className="stress__form__help-text">
                            20 characters minimum ({changeReason.length})
                        </p>
                    </div>
                    {!isFormValid && (
                        <div>
                            <button
                                disabled
                                className="reason-for-change__action-button stress__button"
                                type="button"
                            >
                                <SaveIcon /> Save
                            </button>
                            <button
                                onClick={this.handleUndoClick}
                                className="reason-for-change__action-button stress__button-secondary"
                                type="button"
                            >
                                <UndoIcon /> Undo changes
                            </button>
                        </div>
                    )}
                    {isSaving && (
                        <LoadingButton text="Saving" className="reason-for-change__action-button" />
                    )}
                    {!isSaving && saveActionCompleted && !saveErrorMessage && (
                        <button
                            disabled
                            className="reason-for-change__action-button stress__button"
                            type="button"
                        >
                            <DoneIcon /> Saved
                        </button>
                    )}
                    {!isSaving && isFormValid && !saveActionCompleted && (
                        <div>
                            <button
                                onClick={() => this.handleSaveClick(changeReason)}
                                className="reason-for-change__action-button stress__button"
                                type="button"
                            >
                                <SaveIcon /> Save
                            </button>
                            <button
                                onClick={this.handleUndoClick}
                                className="reason-for-change__action-button stress__button-secondary"
                                type="button"
                            >
                                <UndoIcon /> Undo changes
                            </button>
                        </div>
                    )}
                    {saveActionCompleted && !saveErrorMessage && (
                        <div>
                            <p>
                                {saveSuccessMessage || 'Changes saved successfully'}{' '}
                                <button
                                    className="stress__button-secondary"
                                    onClick={this.reset}
                                    type="button"
                                >
                                    Ok
                                </button>
                            </p>
                        </div>
                    )}
                    {saveErrorMessage && (
                        <ErrorMessage
                            important
                            message={saveErrorMessage || 'An error has occurred'}
                        />
                    )}
                </div>
            </div>
        );
    }
}

ReasonForChange.defaultProps = {
    model: {
        saveSuccessMessage: '',
        saveErrorMessage: '',
        isValid: true,
    },
};

ReasonForChange.propTypes = {
    actions: PropTypes.shape({
        handleSaveClick: PropTypes.func.isRequired,
        handleUndoClick: PropTypes.func.isRequired,
        handleDoneClick: PropTypes.func.isRequired,
    }).isRequired,
    model: PropTypes.shape({
        isSaving: PropTypes.bool.isRequired,
        comments: PropTypes.string,
        isValid: PropTypes.bool,
        saveSuccessMessage: PropTypes.string,
        saveErrorMessage: PropTypes.string,
    }),
};

export default ReasonForChange;
