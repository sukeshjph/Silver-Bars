import React from 'react';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Tooltip from '@material-ui/core/Tooltip';
import { IColumnDef } from '../../interfaces/globals';

const TableHeadWithSorting: React.FC<{
    sortHandler: (event: any, property: string) => void;
    order: 'asc' | 'desc';
    orderBy: string;
    columnDefs: IColumnDef[];
}> = React.memo(({ order, orderBy, columnDefs, sortHandler }) => {
    const createSortHandler = (property: string) => event => {
        sortHandler(event, property);
    };

    return (
        <thead>
            <tr>
                {columnDefs.map(column =>
                    column.sortable ? (
                        <th key={column.key} className={[column.className]}>
                            <Tooltip title="Sort" enterDelay={300}>
                                <TableSortLabel
                                    active={orderBy === column.key}
                                    direction={order}
                                    onClick={createSortHandler(column.key)}
                                >
                                    {column.label}
                                </TableSortLabel>
                            </Tooltip>
                        </th>
                    ) : (
                        <th key={column.key} className={column.className}>
                            {column.label}
                        </th>
                    ),
                )}
            </tr>
        </thead>
    );
});

export default TableHeadWithSorting;
