import React from 'react';
import CircularProgress from '@material-ui/core/CircularProgress';

const LoadingButton: React.FC<{ className?: string; text: string }> = React.memo(
    ({ className = '', text = 'Loading' }) => (
        <button disabled className={`stress__button--loading ${className}`} type="button">
            <CircularProgress size={15} /> {text}
        </button>
    ),
);

export default LoadingButton;
