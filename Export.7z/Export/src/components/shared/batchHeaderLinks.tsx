import React, { FunctionComponent } from 'react';
import MainMenu from './mainMenu';
import { navLinksType } from '../../interfaces/globals';

interface BatchLinksProps {
    navHeaderLinks?: navLinksType[];
    navHeaderTitle: string;
}

const BatchHeaderLinks: FunctionComponent<BatchLinksProps> = React.memo(
    ({ navHeaderTitle = '' }) => (
        <header className="stress__header">
            <div className="stress__header__title stress-header-quicklinks">
                <h2 className="stress__header__title__main-text--with-sub">{navHeaderTitle}</h2>               
            </div>
            <MainMenu />
        </header>
    ),
);

export default BatchHeaderLinks;
