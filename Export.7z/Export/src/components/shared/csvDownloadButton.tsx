import React from 'react';
import PropTypes from 'prop-types';
import Tooltip from '@material-ui/core/Tooltip';
import CloudDownloadIcon from '@material-ui/icons/CloudDownload';
import { CSVLink } from 'react-csv';
import { now } from '../../helpers/dateTime';
import generateCsvData from '../../helpers/generateCsvData';

class CsvDownloadButton extends React.PureComponent {

    static defaultProps = {
        className: '',
        id: '',
        disabled: false,
    };

    static propTypes = {
        id: PropTypes.string,
        className: PropTypes.string,
        disabled: PropTypes.bool,
        tooltip: PropTypes.string.isRequired,
        filename: PropTypes.string.isRequired,
        headers: PropTypes.arrayOf(PropTypes.shape).isRequired,
        csvData: PropTypes.arrayOf(PropTypes.shape).isRequired,
    };

    render() {
        const { className, id, disabled, tooltip, filename, headers, csvData } = this.props;
        if (disabled) {
            return (
                <button
                    disabled
                    id={ id }
                    className={ className }
                    type="button"
                >
                    <CloudDownloadIcon />
                </button>
            );
        }
        return (
            <Tooltip title={ tooltip }>
                <CSVLink
                    filename={ `${filename}_${now()}.csv` }
                    data={ generateCsvData(csvData, headers) }
                    headers={ headers }>
                    <button
                        id={ id }
                        className={ className }
                        type="button"
                    >
                        <CloudDownloadIcon />
                    </button>
                </CSVLink>
            </Tooltip>
        );
    }
};

export default CsvDownloadButton;   