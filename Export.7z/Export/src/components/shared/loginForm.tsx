import React from 'react';
import _ from 'lodash';
import LoadingButton from './loadingButton';
import getFormFieldClass from '../../helpers/getFormFieldClass';
import { IAuthReducer } from '../../interfaces/globals';
import { get } from '../../helpers/utilities';

import ErrorMessage from './errorMessage';
import { authenticationCredentials } from '../../helpers/authentication';

type LoginFormState = {
    userId: string;
    password: string;
    hasFailedValidation: boolean;
    userIdTouched: boolean;
    passwordTouched: boolean;
};

type LoginFormProps = Omit<IAuthReducer, 'userDisplayName' | 'entitlements'> & {
    signIn: (userId: string, password: string) => void;
};

class LoginForm extends React.PureComponent<LoginFormProps, LoginFormState> {
    static initialState: LoginFormState = {
        userId: '',
        password: '',
        hasFailedValidation: false,
        userIdTouched: false,
        passwordTouched: false,
    };

    constructor(props: LoginFormProps) {
        super(props);
        this.state = LoginForm.initialState;
        this.handleSignIn = this.handleSignIn.bind(this);
    }

    changeHandler = (field: keyof LoginFormState) => e => {
        this.setState({
            [field]: e.target.value,
            [`${field}Touched`]: true,
        } as Pick<LoginFormState, keyof LoginFormState>);
    };

    checkForAuthErrors() {
        let authError: boolean | string = false;
        const { failedAuthentication } = this.props;
        if (get(authenticationCredentials(), 'entitlements', '') === 'UNAUTHORISED') {
            authError = 'You are not authorised to use Stress Testing';
        } else if (failedAuthentication) {
            authError = 'Bank ID or password not recognised';
        }
        return authError;
    }

    handleSignIn() {
        const { signIn } = this.props;
        const { userId, password } = this.state;
        signIn(userId, password);
    }

    render() {
        const { userId, password, passwordTouched, userIdTouched } = this.state;
        const passwordError = passwordTouched && !password;
        const authError = this.checkForAuthErrors();
        const userIdError = userIdTouched && !userId;
        const hasFailedValidation = !_.every([password, userId]);
        const { isSigningIn } = this.props;
        return (
            <div className="stress-ui-container">
                <form className="stress__form stress__login">
                    <h2 className="stress__login__title">Market Risk Stress Testing</h2>
                    <div className={getFormFieldClass(!userIdError)}>
                        <label className="stress__form__label" htmlFor="stress__login__user">
                            Bank ID
                        </label>
                        <input
                            id="stress__login__user"
                            className="stress__form__input"
                            type="text"
                            value={userId}
                            onChange={this.changeHandler('userId')}
                            required
                        />
                        {userIdError && (
                            <p className="stress__form__help-text stress__login__user__error">
                                Bank ID is required
                            </p>
                        )}
                    </div>
                    <div className={getFormFieldClass(!passwordError)}>
                        <label className="stress__form__label" htmlFor="stress__login__password">
                            Password
                        </label>
                        <input
                            id="stress__login__password"
                            className="stress__form__input"
                            type="password"
                            value={password}
                            onChange={this.changeHandler('password')}
                            required
                        />
                        {passwordError && (
                            <p className="stress__form__help-text stress__login__password__error">
                                Password is required
                            </p>
                        )}
                    </div>
                    {authError && (
                        <ErrorMessage
                            important
                            className="stress__login__error"
                            message={authError}
                        />
                    )}
                    {!isSigningIn && (
                        <button
                            disabled={hasFailedValidation}
                            onClick={this.handleSignIn}
                            type="submit"
                            className="stress__login__button"
                        >
                            Log in
                        </button>
                    )}
                    {isSigningIn && (
                        <LoadingButton className="stress__login__button" text="Logging in" />
                    )}
                </form>
            </div>
        );
    }
}

export default LoginForm;
