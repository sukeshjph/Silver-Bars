import React, { FunctionComponent } from 'react';
import MainMenu from './mainMenu';

type StressHeaderProps = {
    children: React.ReactNode;
};

const StressHeader: FunctionComponent<StressHeaderProps> = React.memo(({ children = null }) => (
    <header className="stress__header">
        {children}
        <MainMenu />
    </header>
));

export default StressHeader;
