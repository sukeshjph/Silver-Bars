import React, { FunctionComponent } from 'react';
import classNames from 'classnames';
import { Tooltip } from 'react-tippy';
import ListItem from '@material-ui/core/ListItem';
import 'react-tippy/dist/tippy.css';
import { IBatch, IScenario } from '../../interfaces/globals';

const BatchListItem: FunctionComponent<{
    batch: IBatch;
    cssNs: string;
    islastItem: boolean;
    batchHeader(batch: IBatch): void;
    batchContent(batch: IBatch): void;
}> = React.memo(({ batch, cssNs = 'stress', islastItem = false, batchHeader, batchContent }) => {
    const getScenariosHTML = (scenarios: IScenario[]) => (
        <div className={`${cssNs}__scenario-tooltip`}>
            {scenarios.length === 0
                ? 'No Scenarios found'
                : scenarios.map((scenario: IScenario) => (
                    <span
                        className={`${cssNs}__scenario-tooltip__scenario-name`}
                        key={scenario.ukId}
                    >
                        {scenario.name}
                    </span>
                ))}
        </div>
    );

    const scenariosPopup = (scenarios: IScenario[]) => {
        const shockDivLength = scenarios.length > 10 ? '90px' : '85px';
        return (
            <div className={`${cssNs}__batch-details-col`}>
                <Tooltip
                    arrow="false"
                    html={getScenariosHTML(scenarios)}
                    theme="light"
                    delay="400"
                    inertia="true"
                    position="right"
                    interactive="true"
                    hideDelay="1000"
                    style={{ width: `${shockDivLength}` }}
                >
                    <span>
                        {scenarios.length === 0 ? '0 Scenarios' : `${scenarios.length} Scenario(s)`}
                    </span>
                </Tooltip>
            </div>
        );
    };

    const listItemClass = classNames(
        `${cssNs}-batch__list-item`,
        `${islastItem ? `${cssNs}-last-list-item` : ''}`,
    );
    return (
        <ListItem alignitems="flex-start" className={listItemClass} key={batch.ukId}>
            <div className={`${cssNs}__batch-details`}>
                <div className={`${cssNs}__batch-details-row`}>{batchHeader(batch)}</div>
                <div className={`${cssNs}__batch-details-row`}>
                    {scenariosPopup(batch.scenarios)}
                    {batchContent(batch)}
                </div>
            </div>
        </ListItem>
    );
});

export default BatchListItem;
