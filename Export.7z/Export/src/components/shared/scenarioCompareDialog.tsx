/* eslint-disable react/no-array-index-key,react/destructuring-assignment  */
import React from 'react';
import classnames from 'classnames';
import sortBy from 'lodash.sortby';
import _ from 'lodash';
import Tooltip from '@material-ui/core/Tooltip';
import Button from '@material-ui/core/Button';
import IconButton from '@material-ui/core/IconButton';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import CloseIcon from '@material-ui/icons/Close';
import CloudDownloadIcon from '@material-ui/icons/CloudDownload';
import Slide from '@material-ui/core/Slide';
import { now } from '../../helpers/dateTime';
import ErrorMessage from './errorMessage';
import { csvToBlobUrl } from '../../helpers/csvToBlobUrl';
import TableHeadWithSorting from './tableHeadWithSorting';
import { IScenario } from '../../interfaces/globals';

// Differences should be joined with " (vs) " for readability
export const convertDiffChangesToStrings = comparison =>
    comparison.map(row =>
        row.map((cell: { join: (arg0: string) => void }) =>
            Array.isArray(cell) ? cell.join(' (vs) ') : cell,
        ),
    );

const dialogTransition = props => <Slide direction="up" {...props} />;

interface ScenarioCompareDialogState {
    showChangesOfType: string;
    dialogTitle: React.Element;
    diff: [] | any;
    order: 'desc' | 'asc';
    orderBy: string;
}

interface ScenarioCompareDialogProps {
    fetchDiff: (
        scenarioUkId: string,
        scenarioActiveFileVersion: number,
        fileVersionToCompare: number | string,
    ) => void;
    closeHandler: () => void;
    fileVersionToCompare: number | string;
    scenario: IScenario;
    diff: any;
    isFetchingDiff: boolean;
    fetchDiffError: string;
}

type ScenarioPropsState = ScenarioCompareDialogState & ScenarioCompareDialogProps;

class ScenarioCompareDialog extends React.PureComponent<ScenarioPropsState> {
    static getDialogTitle = ({ scenario, fileVersionToCompare }) => (
        <span className="stress--file-compare--title--text">
            {scenario.activeFileVersion === 0 && (
                <span>No previous version exists for comparison</span>
            )}
            {scenario.activeFileVersion > 0 && (
                <span>
                    Showing differences applied to
                    {fileVersionToCompare === 'PENDING' ? (
                        <span> the proposed version </span>
                    ) : (
                        <strong> version {fileVersionToCompare} </strong>
                    )}
                    of <strong>{scenario.name}</strong> (compared to
                    <strong> version {scenario.activeFileVersion}</strong>)
                </span>
            )}
        </span>
    );

    static defaultProps = {
        fetchDiffError: '',
        fileVersionToCompare: 'PENDING',
    };

    static rowClass = cell =>
        classnames({
            'stress-table--row': true,
            'add-row': cell === '+++',
            'remove-row': cell === '---',
            'modify-row': cell === '@@@',
            'unchanged-row': cell === '',
        });

    static changeTypes = {
        all: 'all',
        added: 'added',
        modified: 'modified',
        removed: 'removed',
        unchanged: 'unchanged',
    };

    constructor(props) {
        super(props);
        this.sortHandler = this.sortHandler.bind(this);
    }

    state: ScenarioCompareDialogState = {
        showChangesOfType: ScenarioCompareDialog.changeTypes.all,
        dialogTitle: ScenarioCompareDialog.getDialogTitle(this.props),
        diff: [],
        order: 'desc',
        orderBy: '',
    };

    componentDidMount() {
        const { fetchDiff, scenario, fileVersionToCompare } = this.props;
        if (scenario.activeFileVersion > 0) {
            fetchDiff(scenario.ukId, scenario.activeFileVersion, fileVersionToCompare);
        }
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.diff) {
            this.setState({
                diff: nextProps.diff,
            });
        }
    }

    buttonClass = type =>
        classnames({
            'stress--file-compare--key--button': true,
            [`stress--file-compare--key--button-${ScenarioCompareDialog.changeTypes[type]}`]: true,
            'stress--file-compare--key--button__active':
                ScenarioCompareDialog.changeTypes[type] === this.state.showChangesOfType,
        });

    createRowVisibilityHandler(type) {
        return () => {
            this.setState({
                showChangesOfType: ScenarioCompareDialog.changeTypes[type],
            });
        };
    }

    sortRows(rows) {
        const { order } = this.state;
        const orderBy = parseInt(this.state.orderBy.split('-')[1], 10) + 1;
        if (orderBy) {
            const sortedRows = sortBy(rows, row => row[orderBy]);
            return order === 'desc' ? sortedRows.reverse() : sortedRows;
        }
        return rows;
    }

    sortHandler(event, newOrderBy) {
        const { order, orderBy } = this.state;
        this.setState({
            order: orderBy === newOrderBy && order === 'asc' ? 'desc' : 'asc',
            orderBy: newOrderBy,
        });
    }

    renderDiff(diff) {
        const { showChangesOfType } = this.state;
        const tableClass = classnames({
            'stress-table': true,
            [`stress--file-compare__show-${showChangesOfType}`]: true,
        });
        const renderRow = (cells, i) => {
            const className = ScenarioCompareDialog.rowClass(cells[0]);
            return (
                <tr key={`compare-row-${i}`} className={className}>
                    {_.map(cells.slice(1), (cell, j) => {
                        const key = `compare-cell-${j}`;
                        return Array.isArray(cell) ? (
                            <td key={key}>
                                <span className="add">{cell[1]}</span>
                                <span className="remove">{cell[0]}</span>
                            </td>
                        ) : (
                            <td key={key}>{cell} </td>
                        );
                    })}
                </tr>
            );
        };
        const columnDefs = diff.comparison[0].slice(1).map((cell, i) => ({
            sortable: true,
            label: cell,
            key: `cell-${i}`,
        }));

        return (
            <table className={tableClass}>
                <TableHeadWithSorting
                    sortHandler={this.sortHandler}
                    order={this.state.order}
                    orderBy={this.state.orderBy}
                    columnDefs={columnDefs}
                />
                <tbody>
                    {this.sortRows(diff.comparison.slice(1)).map((row, i) => renderRow(row, i))}
                </tbody>
            </table>
        );
    }

    render() {
        const { closeHandler, scenario, isFetchingDiff, fetchDiffError } = this.props;
        const { diff } = this.state;
        return (
            <Dialog fullScreen open className="stress__dialog" transition={dialogTransition}>
                <AppBar
                    className={`${
                        fetchDiffError ? 'stress--file-compare--title--noFixed' : ''
                    } stress--file-compare--title`}
                >
                    <Toolbar>
                        <IconButton
                            className="stress--file-compare--close"
                            color="inherit"
                            onClick={closeHandler}
                        >
                            <CloseIcon />
                        </IconButton>
                        {this.state.dialogTitle}
                        {diff.comparison && (
                            <Tooltip title="Download changes as CSV">
                                <a
                                    className="stress__header__action-button stress__header__button"
                                    download={`Scenario_Compare_${now()}.csv`}
                                    href={csvToBlobUrl(
                                        convertDiffChangesToStrings(diff.comparison),
                                    )}
                                >
                                    <CloudDownloadIcon />
                                </a>
                            </Tooltip>
                        )}
                    </Toolbar>
                </AppBar>
                <DialogContent className="stress--file-compare">
                    {scenario.activeFileVersion === 0 && (
                        <ErrorMessage message="This is version 1 of the file. There is nothing to compare it to." />
                    )}
                    {isFetchingDiff && <div className="stress-loading" />}
                    {fetchDiffError && <ErrorMessage message={fetchDiffError} />}
                    {diff.comparison && diff.ukId === scenario.ukId && (
                        <div className="stress--file-compare">
                            <div className="stress--file-compare--actions">
                                <ul className="stress--file-compare--keys">
                                    <li className="stress--file-compare--key">
                                        <Button
                                            className={this.buttonClass('added')}
                                            onClick={this.createRowVisibilityHandler('added')}
                                        >
                                            <span className="stress--file-compare--key--item add" />
                                            <span className="stress-button--text">
                                                Added ({diff.added})
                                            </span>
                                        </Button>
                                    </li>
                                    <li className="stress--file-compare--key">
                                        <Button
                                            className={this.buttonClass('removed')}
                                            onClick={this.createRowVisibilityHandler('removed')}
                                        >
                                            <span className="stress--file-compare--key--item remove" />
                                            <span className="stress-button--text">
                                                Removed ({diff.removed})
                                            </span>
                                        </Button>
                                    </li>
                                    <li className="stress--file-compare--key">
                                        <Button
                                            className={this.buttonClass('modified')}
                                            onClick={this.createRowVisibilityHandler('modified')}
                                        >
                                            <span className="stress--file-compare--key--item modify" />
                                            <span className="stress-button--text">
                                                Modified ({diff.edited})
                                            </span>
                                        </Button>
                                    </li>
                                    <li className="stress--file-compare--key">
                                        <Button
                                            className={this.buttonClass('all')}
                                            onClick={this.createRowVisibilityHandler('all')}
                                        >
                                            All changes ({diff.added + diff.removed + diff.edited})
                                        </Button>
                                    </li>
                                    <li className="stress--file-compare--key">
                                        <Button
                                            className={this.buttonClass('unchanged')}
                                            onClick={this.createRowVisibilityHandler('unchanged')}
                                        >
                                            All rows (
                                            {diff.added +
                                                diff.removed +
                                                diff.edited +
                                                diff.unchanged}
                                            )
                                        </Button>
                                    </li>
                                </ul>
                            </div>
                            {this.renderDiff(diff)}
                        </div>
                    )}
                </DialogContent>
                <DialogActions>
                    <Button
                        className="stress--file-compare--close"
                        color="primary"
                        onClick={closeHandler}
                    >
                        Close
                    </Button>
                </DialogActions>
            </Dialog>
        );
    }
}

export default ScenarioCompareDialog;
