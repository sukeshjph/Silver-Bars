/* eslint-disable react/destructuring-assignment,react/button-has-type */
import React from 'react';
import { bindActionCreators } from 'redux';
import { RootState } from 'typesafe-actions';
import { connect } from 'react-redux';
import AddBoxIcon from '@material-ui/icons/AddBox';
import DeleteIcon from '@material-ui/icons/Delete';
import CreateIcon from '@material-ui/icons/Create';
import RestoreIcon from '@material-ui/icons/Restore';
import CloudDownloadIcon from '@material-ui/icons/CloudDownload';
import { get } from '../../helpers/utilities';

import './scenarios.scss';

import * as Actions from '../../actions';
import * as BatchActions from '../batchManager/batchManagerActions';
import * as ScenarioActions from './scenarioActions';

import ScenarioAddEditDialog from './scenarioAddEditDialog';
import ScenarioDeleteDialog from './scenarioDeleteDialog';
import ScenarioVersionsDialog from './scenarioVersionsDialog';
import ScenarioDownloadsDialog from './scenarioDownloadsDialog';
import ScenariosTable from './scenariosTable';
import DataSetFilter from '../shared/dataSetFilter';
import MainMenu from '../shared/mainMenu';
import ErrorMessage from '../shared/errorMessage';
import TooltipButton from '../shared/tooltipButton';
import filterDataSet from '../../helpers/filterDataSet';
import { readWrite, isSuperUser } from '../../helpers/authentication';
import LoadingData from '../shared/loadingData';
import { IScenarioManagerProps, IScenarioManagerState } from './scenarioMngr.types';
import { IScenario } from '../../interfaces/globals';

type ScenarioManagerPropsState = IScenarioManagerProps & IScenarioManagerState;

export class ScenarioManager extends React.Component<ScenarioManagerPropsState> {
    constructor(props) {
        super(props);
        this.dialogHandler = this.dialogHandler.bind(this);
        this.editScenarioHandler = this.editScenarioHandler.bind(this);
        this.editFileVersionHandler = this.editFileVersionHandler.bind(this);
        this.confirmDeleteHandler = this.confirmDeleteHandler.bind(this);
        this.openDeleteModalHandler = this.openDeleteModalHandler.bind(this);
        this.setSelectedScenario = this.setSelectedScenario.bind(this);
        this.handleFilterTextChange = this.handleFilterTextChange.bind(this);
        this.applyCurrentFilters = this.applyCurrentFilters.bind(this);
        this.downloadScenarioHandler = this.downloadScenarioHandler.bind(this);
        this.getScenarioActions = this.getScenarioActions.bind(this);
        this.closeAddEditDialog = this.closeAddEditDialog.bind(this);
        this.doneDeletingHandler = this.doneDeletingHandler.bind(this);
        this.closeVersionDialog = this.closeVersionDialog.bind(this);
    }

    state: IScenarioManagerState = {
        scenarioBeingDeleted: '',
        openEditModal: false,
        openFileVersionModal: false,
        openFileDownload: false,
        openCreateModal: false,
        openDeleteModal: false,
        deleteMessage: '',
        selectedScenarioUkId: '',
        inCompareMode: false,
        filterText: '',
        scenarios: this.props.scenarioModel.scenarios,
    };

    componentDidMount() {
        this.props.actions.fetchScenarios();
        this.props.actions.fetchBatches();
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.scenarioModel.scenarios) {
            this.setState({
                scenarios: this.applyCurrentFilters(nextProps.scenarioModel.scenarios),
                userCanEdit: readWrite(),
                userIsSuperUser: isSuperUser(),
            });
        }
    }

    setSelectedScenario(ukId: string) {
        this.setState({
            selectedScenarioUkId: ukId,
        });
    }

    getScenarioActions() {
        const { userCanEdit, userIsSuperUser, selectedScenarioUkId, scenarios } = this.state;
        const selectedScenario = scenarios.find(scn => scn.ukId === selectedScenarioUkId);
        const disabled = !selectedScenarioUkId;
        const noDownloads =
            get(selectedScenario, 'activeFileVersion', null) === null &&
            get(selectedScenario, 'pending', false) === false;
        const noFileVersions = get(selectedScenario, 'activeFileVersion', null) === null;
        const pendingApproval = get(selectedScenario, 'pending', false) === true;
        const isDeleteButtonDisabled = [!selectedScenarioUkId, pendingApproval].some(val => val);
        return (
            <div className="scenario-actions">
                {userIsSuperUser && (
                    <TooltipButton
                        className="stress__header__action-button stress--scenario-actions--add"
                        clickHandler={() => this.dialogHandler('openCreateModal')}
                        tooltip="New"
                    >
                        <AddBoxIcon />
                    </TooltipButton>
                )}
                {userIsSuperUser && (
                    <TooltipButton
                        disabled={isDeleteButtonDisabled}
                        className="stress__header__action-button stress--scenario-actions--delete"
                        clickHandler={() => this.openDeleteModalHandler(selectedScenarioUkId)}
                        tooltip="Delete"
                    >
                        <DeleteIcon />
                    </TooltipButton>
                )}
                {(userIsSuperUser || userCanEdit) && (
                    <TooltipButton
                        disabled={disabled || pendingApproval}
                        className="stress__header__action-button stress--scenario-actions--edit"
                        clickHandler={() => this.editScenarioHandler(selectedScenarioUkId)}
                        tooltip="Edit"
                    >
                        <CreateIcon />
                    </TooltipButton>
                )}
                <TooltipButton
                    disabled={noDownloads}
                    className={`stress__header__action-button stress--scenario-actions--download ${
                        disabled ? 'stress-button__disabled' : ''
                    }`}
                    clickHandler={() => this.downloadScenarioHandler(selectedScenarioUkId)}
                    tooltip="Download"
                >
                    <CloudDownloadIcon />
                </TooltipButton>
                <TooltipButton
                    disabled={noFileVersions}
                    className="stress__header__action-button stress--scenario-actions--versions"
                    clickHandler={() => this.editFileVersionHandler(selectedScenarioUkId)}
                    tooltip="File versions"
                >
                    <RestoreIcon />
                </TooltipButton>
            </div>
        );
    }

    cancelCompilationHandler = () => {
        this.props.actions.compileScenarioFileCancel();
    };

    downloadScenarioActiveVersion = (curScenario: IScenario) => () => {
        const { ukId, activeFileVersion, validFrom, name } = curScenario;
        this.props.actions.downloadScenarioFile({
            ukId,
            name,
            validFrom,
            version: activeFileVersion,
            pending: false,
        });
    };

    editScenarioHandler(ukId: string) {
        this.setState(prevState => ({
            openEditModal: !prevState.openEditModal,
            scenarioBeingEdited: this.props.scenarioModel.scenarios.find(scn => scn.ukId === ukId),
        }));
    }

    editFileVersionHandler(ukId: string) {
        this.setState((prevState: IScenarioManagerState) => ({
            openFileVersionModal: !prevState.openFileVersionModal,
            scenarioBeingEdited: this.props.scenarioModel.scenarios.find(scn => scn.ukId === ukId),
        }));
    }

    dialogHandler(dialog) {
        this.setState(prevState => ({
            [dialog]: !prevState[dialog],
        }));
    }

    doneDeletingHandler() {
        this.setState(
            {
                openDeleteModal: false,
                scenarioBeingDeleted: '',
            },
            () => this.props.actions.fetchScenarios(),
        );
    }

    closeAddEditDialog(shouldRefreshScenarios) {
        this.setState({
            openEditModal: false,
            openCreateModal: false,
        });
        if (shouldRefreshScenarios) {
            this.props.actions.fetchScenarios();
            this.props.actions.compileScenarioFileCancel();
        }
    }

    closeVersionDialog() {
        this.setState(
            {
                openFileVersionModal: false,
            },
            this.props.actions.fetchScenarios,
        );
    }

    openDeleteModalHandler(scenarioBeingDeleted) {
        this.setState({
            scenarioBeingDeleted,
            openDeleteModal: true,
        });
    }

    handleFilterTextChange(filterText, scenarios) {
        this.setState({
            filterText,
            scenarios,
        });
    }

    applyCurrentFilters(scenarios) {
        const { filterText } = this.state;
        if (filterText) {
            return filterDataSet(filterText, scenarios);
        }
        return scenarios;
    }

    confirmDeleteHandler(reason: string) {
        this.props.actions.deleteScenario(this.state.scenarioBeingDeleted, reason);
    }

    downloadScenarioHandler(ukId: string) {
        this.setState({
            openFileDownload: true,
            scenarioBeingDownloaded: this.props.scenarioModel.scenarios.find(
                scn => scn.ukId === ukId,
            ),
        });
    }

    render() {
        const { scenarioModel, batchModel, diffModel, actions } = this.props;
        const {
            scenarioBeingDeleted,
            openEditModal,
            openFileVersionModal,
            openFileDownload,
            openCreateModal,
            openDeleteModal,
            scenarioBeingEdited,
            scenarioBeingDownloaded,
            selectedScenarioUkId,
            inCompareMode,
            scenarios,
            filterText,
            userCanEdit,
        } = this.state;
        return (
            <section id="scenario-manager" className="stress-ui-container">
                <header className="stress__header">
                    <div className="stress__header__title">
                        <h2 className="stress__header__title__main-text">Scenarios</h2>
                    </div>
                    <DataSetFilter
                        actions={{
                            handleChange: this.handleFilterTextChange,
                        }}
                        model={{
                            value: filterText,
                            data: scenarioModel.scenarios,
                        }}
                    />
                    {this.getScenarioActions()}
                    <MainMenu />
                </header>

                <LoadingData
                    showLoading={batchModel.isFetchingBatches || scenarioModel.isFetchingScenarios}
                    render={() => <div className="stress-loading" />}
                />

                {scenarioModel.scenarioError && scenarioModel.scenarios.length === 0 && (
                    <ErrorMessage message="Sorry, an unexpected error has occurred." />
                )}

                <ScenariosTable
                    scenarios={scenarios}
                    setSelectedScenario={this.setSelectedScenario}
                    selectedScenarioUkId={selectedScenarioUkId}
                    inCompareMode={inCompareMode}
                    downloadScenarioActiveVersion={this.downloadScenarioActiveVersion}
                />

                {openCreateModal && (
                    <ScenarioAddEditDialog
                        data={{
                            isSavingScenario: scenarioModel.isSavingScenario,
                            hasSavedScenario: scenarioModel.hasSavedScenario,
                            doesScenarioExist: scenarioModel.doesScenarioExist,
                            isCompilingScenario: scenarioModel.isCompilingScenario,
                            isScenarioCompiled: scenarioModel.isScenarioCompiled,
                            compilationResult: scenarioModel.compilationResult,
                            isFetchingScenario: scenarioModel.isFetchingScenario,
                            scenarioError: scenarioModel.scenarioError,
                        }}
                        confirmHandler={this.props.actions.createScenario}
                        cancelHandler={this.closeAddEditDialog}
                        cancelCompilationHandler={this.cancelCompilationHandler}
                        doneHandler={this.closeAddEditDialog}
                        actions={{
                            checkScenarioExists: actions.checkScenarioExists,
                            compileScenarioFile: actions.compileScenarioFile,
                            compileScenarioFileReset: actions.compileScenarioFileReset,
                        }}
                    />
                )}

                {openEditModal && (
                    <ScenarioAddEditDialog
                        data={{
                            selectedScenario: scenarioBeingEdited,
                            isSavingScenario: scenarioModel.isSavingScenario,
                            hasSavedScenario: scenarioModel.hasSavedScenario,
                            doesScenarioExist: scenarioModel.doesScenarioExist,
                            isFetchingScenario: scenarioModel.isFetchingScenario,
                            isCompilingScenario: scenarioModel.isCompilingScenario,
                            isScenarioCompiled: scenarioModel.isScenarioCompiled,
                            compilationResult: scenarioModel.compilationResult,
                            scenarioError: scenarioModel.scenarioError,
                        }}
                        confirmHandler={this.props.actions.updateScenario}
                        cancelHandler={this.closeAddEditDialog}
                        cancelCompilationHandler={this.cancelCompilationHandler}
                        doneHandler={this.closeAddEditDialog}
                        actions={{
                            checkScenarioExists: actions.checkScenarioExists,
                            compileScenarioFile: actions.compileScenarioFile,
                            compileScenarioFileReset: actions.compileScenarioFileReset,
                        }}
                    />
                )}

                {openFileVersionModal && (
                    <ScenarioVersionsDialog
                        model={{
                            scenario: scenarioBeingEdited,
                            hasChangePending: scenarioBeingEdited.pending,
                            approvedScenarios: scenarioModel.approvedScenarios,
                            isFetchingScenarioDetails: scenarioModel.isFetchingScenarioDetails,
                            isSavingScenario: scenarioModel.isSavingScenario,
                            hasSavedScenario: scenarioModel.hasSavedScenario,
                            isFetchingDiff: diffModel.isFetchingDiff,
                            fetchDiffError: diffModel.fetchDiffError,
                            diff: diffModel.diff,
                            userCanEdit,
                        }}
                        actions={{
                            fetchScenarioDetails: actions.fetchScenarioDetails,
                            fetchDiff: actions.fetchDiff,
                            updateScenario: actions.updateScenario,
                            doneHandler: this.closeVersionDialog,
                            cancelHandler: () => this.dialogHandler('openFileVersionModal'),
                        }}
                    />
                )}

                {openFileDownload && (
                    <ScenarioDownloadsDialog
                        model={{
                            scenario: scenarioBeingDownloaded,
                            approvedScenarios: scenarioModel.approvedScenarios,
                            pendingScenarios: scenarioModel.pendingScenarios,
                        }}
                        actions={{
                            fetchScenarioDetails: actions.fetchScenarioDetails,
                            downloadScenarioFile: actions.downloadScenarioFile,
                            cancelHandler: () => this.dialogHandler('openFileDownload'),
                        }}
                    />
                )}

                {openDeleteModal && (
                    <ScenarioDeleteDialog
                        data={{
                            scenarioBeingDeleted,
                            scenarios: scenarioModel.scenarios,
                            batches: batchModel.batches,
                            isDeletingScenario: scenarioModel.isDeletingScenario,
                            scenarioError: scenarioModel.scenarioError,
                        }}
                        cancelHandler={() => this.dialogHandler('openDeleteModal')}
                        confirmHandler={this.confirmDeleteHandler}
                        doneHandler={this.doneDeletingHandler}
                    />
                )}
            </section>
        );
    }
}

const mapStateToProps = (state: RootState) => ({
    scenarioModel: state.SCENARIOS,
    batchModel: state.BATCHES,
    diffModel: state.DIFF,
});
const mapDispatchToProps = dispatch => ({
    actions: bindActionCreators(
        Object.assign({}, Actions, ScenarioActions, BatchActions),
        dispatch,
    ),
});

export const ScenarioManagerConnected = connect(
    mapStateToProps,
    mapDispatchToProps,
)(ScenarioManager);
