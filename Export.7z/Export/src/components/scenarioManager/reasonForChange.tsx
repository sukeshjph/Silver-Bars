/* eslint-disable react/destructuring-assignment,react/button-has-type */
import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import UndoIcon from '@material-ui/icons/Undo';
import SaveIcon from '@material-ui/icons/Save';
import DoneIcon from '@material-ui/icons/Done';
import { SCENARIO_COMPILATION_STATES } from './scenarioConstants';

import LoadingButton from '../shared/loadingButton';
import ErrorMessage from '../shared/errorMessage';
import getFormFieldClass from '../../helpers/getFormFieldClass';

class ReasonForChange extends React.PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            changeReason: this.props.model.comments || '',
            saveActionCompleted: false,
            isSaving: false,
            saveErrorMessage: '',
            touched: false,
        };
        this.handleReasonForChangeUpdate = this.handleReasonForChangeUpdate.bind(this);
        this.handleUndoClick = this.handleUndoClick.bind(this);
        this.reset = this.reset.bind(this);
    }

    componentWillReceiveProps({ model: { isSaving, comments, saveErrorMessage } }) {
        if (
            isSaving !== this.state.isSaving ||
            comments !== this.state.comments ||
            saveErrorMessage !== this.state.saveErrorMessage
        ) {
            this.setState(prevState => ({
                isSaving,
                changeReason: comments || prevState.changeReason,
                saveActionCompleted: this.hasSavedActionCompleted(isSaving, saveErrorMessage),
                saveErrorMessage,
            }));
        }
    }

    getCompilationMessage = isScenarioCompiled => (
        <div
            className={`${
                !isScenarioCompiled
                    ? 'reason-for-change__Compile-message'
                    : 'reason-for-change__Compile-message reason-for-change__Compile-message--hidden'
            }`}
        >
            <p>Proceeding with Save assumes that scenario file compiles successfully</p>
        </div>
    );

    getSaveSuccess = () => {
        const {
            model: { saveSuccessMessage },
        } = this.props;
        const { saveActionCompleted, saveErrorMessage } = this.state;

        return (
            saveActionCompleted &&
            !saveErrorMessage && (
                <div>
                    <p>
                        {saveSuccessMessage || 'Changes saved successfully'}{' '}
                        <button className="stress__button-secondary" onClick={this.reset}>
                            Ok
                        </button>
                    </p>
                </div>
            )
        );
    };

    getReasonButtons = isFormValid => {
        const { changeReason, saveActionCompleted, isSaving, saveErrorMessage } = this.state;
        const {
            model: { isScenarioCompiled },
        } = this.props;

        if (!isSaving) {
            if (saveActionCompleted && !saveErrorMessage) {
                return (
                    <button disabled className="reason-for-change__action-button stress__button">
                        <DoneIcon /> Saved
                    </button>
                );
            }

            if (isFormValid && !saveActionCompleted) {
                return (
                    <div>
                        <div>
                            <button
                                onClick={() => this.handleSaveClick(changeReason)}
                                className="reason-for-change__action-button stress__button"
                            >
                                <SaveIcon /> Save
                            </button>
                            <button
                                onClick={this.handleUndoClick}
                                className="reason-for-change__action-button stress__button-secondary"
                            >
                                <UndoIcon /> Undo changes
                            </button>
                        </div>
                        {this.getCompilationMessage(isScenarioCompiled)}
                    </div>
                );
            }

            return null;
        }

        return <LoadingButton text="Saving" className="reason-for-change__action-button" />;
    };

    // Save action is only complete if save action completed with no error
    hasSavedActionCompleted = (nextIsSavingStatus, saveErrorMessage) =>
        this.state.isSaving === true && nextIsSavingStatus === false && !saveErrorMessage;

    handleReasonForChangeUpdate(e) {
        this.setState({
            touched: true,
            changeReason: e.target.value,
        });
    }

    handleSaveClick(changeReason) {
        this.props.actions.handleSaveClick(changeReason);
    }

    handleUndoClick() {
        this.setState(
            {
                changeReason: '',
            },
            this.props.actions.handleUndoClick,
        );
    }

    reset() {
        this.setState(
            {
                changeReason: '',
                saveActionCompleted: false,
                saveErrorMessage: '',
            },
            () => this.props.actions.handleDoneClick(true),
        );
    }

    isFormValid() {
        const {
            model: {
                isScenarioCompiled,
                compilationResult: { result = '' },
                isCompilingScenario,
            },
        } = this.props;

        const hasScenarioCompileFailed =
            isScenarioCompiled && result !== SCENARIO_COMPILATION_STATES.COMPILED;

        const validationRules = [
            this.state.changeReason.length >= 20,
            !isCompilingScenario,
            !hasScenarioCompileFailed,
            _.isUndefined(this.props.model.isValid) ? true : this.props.model.isValid,
        ];
        return _.every(validationRules);
    }

    render() {
        const { changeReason, saveActionCompleted, saveErrorMessage } = this.state;
        const {
            model: { isCompilingScenario },
        } = this.props;
        const isFormValid = this.isFormValid();

        return (
            <div className="reason-for-change">
                <div className="reason-for-change__actions">
                    <div
                        className={getFormFieldClass(
                            !(this.state.touched && changeReason.length < 20),
                        )}
                    >
                        <label className="stress__form__label">
                            Please provide a reason for this change
                        </label>
                        <input
                            type="text"
                            className="stress__form__input"
                            value={changeReason}
                            onChange={e => this.handleReasonForChangeUpdate(e)}
                            disabled={saveActionCompleted || isCompilingScenario}
                        />
                        <p className="stress__form__help-text">
                            20 characters minimum ({changeReason.length})
                        </p>
                    </div>
                    {!isFormValid && (
                        <div>
                            <button
                                disabled
                                className="reason-for-change__action-button stress__button"
                            >
                                <SaveIcon /> Save
                            </button>
                            <button
                                onClick={this.handleUndoClick}
                                className="reason-for-change__action-button stress__button-secondary"
                            >
                                <UndoIcon /> Undo changes
                            </button>
                        </div>
                    )}
                    {this.getReasonButtons(isFormValid)}
                    {this.getSaveSuccess()}
                    <ErrorMessage
                        important
                        message={saveErrorMessage || 'An error has occurred'}
                        showError={saveErrorMessage}
                    />
                </div>
            </div>
        );
    }
}

ReasonForChange.defaultProps = {
    model: {
        saveSuccessMessage: '',
        saveErrorMessage: '',
        isValid: true,
    },
};

ReasonForChange.propTypes = {
    actions: PropTypes.shape({
        handleSaveClick: PropTypes.func.isRequired,
        handleUndoClick: PropTypes.func.isRequired,
        handleDoneClick: PropTypes.func.isRequired,
    }).isRequired,
    model: PropTypes.shape({
        isSaving: PropTypes.bool.isRequired,
        comments: PropTypes.string,
        isValid: PropTypes.bool,
        saveSuccessMessage: PropTypes.string,
        saveErrorMessage: PropTypes.string,
        isScenarioCompiled: PropTypes.bool.isRequired,
        compilationResult: PropTypes.shape({
            result: PropTypes.string.isRequired,
            message: PropTypes.string.isRequired,
        }),
        isCompilingScenario: PropTypes.bool.isRequired,
    }),
};

export default ReasonForChange;
