/* eslint-disable react/destructuring-assignment,react/button-has-type */
import * as Papa from 'papaparse';
import React from 'react';
import PropTypes from 'prop-types';
import bytes from 'bytes';
import AttachFileIcon from '@material-ui/icons/AttachFile';
import scenarioColumnHeadingsValidator from './scenarioColumnHeadingsValidator';
import { MAX_FILE_SIZE } from '../../constants';
import { filePicker, SCENARIO_COMPILATION_TYPES } from './scenarioConstants';
import getFormFieldClass from '../../helpers/getFormFieldClass';

class FilePicker extends React.Component {
    static defaultProps = {
        disabled: false,
        fileName: '',
        theFile: '',
        children: null,
    };

    static propTypes = {
        handleFileChange: PropTypes.func.isRequired,
        isRequired: PropTypes.bool.isRequired,
        disabled: PropTypes.bool,
        compilationError: PropTypes.string.isRequired,
        fileType: PropTypes.string.isRequired,
        fileName: PropTypes.string, // Required for handling validation on cortex_path file
        theFile: PropTypes.string,
        children: PropTypes.node,
    };

    static initialState = {
        theFile: { name: '' },
        fileTypeError: false,
        fileSizeError: false,
        columnHeadingsAreValid: false,
        localisedHeadingsError: false,
        commonHeadingsError: false,
        touched: false,
    };

    constructor(props) {
        super(props);
        this.handleFileUploadClick = this.handleFileUploadClick.bind(this);
        this.handleFileChange = this.handleFileChange.bind(this);
    }

    state = FilePicker.initialState;

    componentWillReceiveProps(nextProps) {
        // If user switches between global and localised category
        // types the file headings need validated again
        if (nextProps.fileType !== this.props.fileType) {
            this.parseTheFile(this.state.theFile, SCENARIO_COMPILATION_TYPES.CATEGORY);
        }

        // To handle form undo functionality
        if (nextProps.theFile === '' && this.state.theFile.name !== '') {
            this.setState(FilePicker.initialState);
        }
    }

    
    getHelperHtml = (toShow, message, className = 'stress__form__help-text') =>
        toShow && <p className={className}>{message}</p>;

    getHelperMessages = (isRequired, compilationError) => {
        const {
            fileTypeError,
            fileSizeError,
            localisedHeadingsError,
            commonHeadingsError,
            unrecognisedHeadings,
        } = this.state;

        return (
            <React.Fragment>
                {this.getHelperHtml(fileTypeError, 'Only CSV files are supported')}
                {this.getHelperHtml(
                    fileSizeError,
                    `The selected file exceeds the ${bytes(MAX_FILE_SIZE)} limit`,
                )}
                {this.getHelperHtml(
                    compilationError !== '',
                    compilationError,
                    'stress__form__help-text stress__form__error-text',
                )}
                {this.getHelperHtml(
                    localisedHeadingsError,
                    'The file is missing the required column headings for a localised scenario file',
                )}
                {this.getHelperHtml(
                    commonHeadingsError,
                    `The file has unsupported column headings: ${unrecognisedHeadings}`,
                )}
                {this.getHelperHtml(
                    isRequired &&
                        !this.state.touched &&
                        !fileTypeError &&
                        !fileSizeError &&
                        !localisedHeadingsError &&
                        !commonHeadingsError,
                    'Required',
                )}
                {this.getHelperHtml(
                    !fileTypeError &&
                        !fileSizeError &&
                        !localisedHeadingsError &&
                        !commonHeadingsError,
                    'An uploaded file will be queued for approval. Once approved, it will become the active version.',
                )}
            </React.Fragment>
        );
    };

    handleFileUploadClick(e) {
        e.preventDefault();
        this.fileInput.value = null;
        this.fileInput.click();
        this.setState({ touched: true });
    }

    handleFileChange({ target: { files } }) {
        const theFile = files[0];
        const fileName = theFile.name;
        const fileTypeError = fileName.substring(fileName.length - 4) !== '.csv';
        const fileSizeError = theFile.size > MAX_FILE_SIZE;

        // Invalid if incorrect fileType
        if (fileTypeError) {
            this.setState(
                {
                    theFile,
                    fileTypeError,
                },
                () => this.props.handleFileChange(null, false),
            );
            return;
        }

        // Invalid if file size is greater than 5mb
        if (fileSizeError) {
            this.setState(
                {
                    theFile,
                    fileSizeError,
                },
                () => this.props.handleFileChange(null, false),
            );
            return;
        }

        // If there's a file and it's CSV, parse it
        this.parseTheFile(theFile, SCENARIO_COMPILATION_TYPES.FILEUPLOAD);
    }

    parseTheFile(theFile, changeType) {
        if (!theFile.name) {
            return;
        }
        Papa.parse(theFile, {
            delimiter: ',',
            complete: results => {
                const csv = Papa.unparse(results.data, {
                    quoteChar: '"',
                    delimiter: ',',
                    header: true,
                    newline: '\r\n',
                });
                this.validateHeadings(csv, theFile, changeType);
            },
        });
    }

    validateHeadings(csv, theFile, changeType) {
        const {
            isValid: columnHeadingsAreValid,
            localisedHeadingsError,
            commonHeadingsError,
            unrecognisedHeadings,
        } = scenarioColumnHeadingsValidator(csv, this.props.fileType, this.props.fileName);

        this.setState(
            {
                theFile,
                fileSizeError: false,
                fileTypeError: false,
                columnHeadingsAreValid,
                localisedHeadingsError,
                commonHeadingsError,
                unrecognisedHeadings,
            },
            () => {
                if (this.state.columnHeadingsAreValid) {
                    this.props.handleFileChange(
                        csv,
                        this.isFileInputFieldValid(),
                        theFile,
                        changeType,
                    );
                } else {
                    this.props.handleFileChange(null, false, theFile);
                }
            },
        );
    }

    isFileInputFieldValid() {
        // If a scenario is being edited, a file is not required
        if (!this.props.isRequired && !this.state.touched) {
            return true;
        }
        // If a scenario is being created, a file is compulsory
        if (this.props.isRequired && !this.state.theFile) {
            return false;
        }
        const {
            fileTypeError,
            fileSizeError,
            localisedHeadingsError,
            commonHeadingsError,
        } = this.state;
        return !fileTypeError && !fileSizeError && !localisedHeadingsError && !commonHeadingsError;
    }

    render() {
        const { disabled, isRequired, compilationError } = this.props;
        const { theFile } = this.state;
        return (
            <div className={`${filePicker} ${getFormFieldClass(this.isFileInputFieldValid())}`}>
                <label className="stress__form__label" htmlFor="file-name">
                    Select scenario file
                </label>
                <button
                    disabled={disabled}
                    className="stress__button"
                    onClick={this.handleFileUploadClick}
                >
                    <AttachFileIcon />
                </button>
                <input
                    id="file-name"
                    className="stress__file-picker__name stress__form__input"
                    type="text"
                    value={theFile.name}
                    disabled
                    onChange={this.handleFileChange}
                />
                {this.props.children}
                {this.getHelperMessages(isRequired, compilationError)}
                <input
                    className="stress__file-picker__file"
                    style={{ display: 'none' }}
                    ref={input => {
                        this.fileInput = input;
                    }}
                    disabled={this.props.disabled}
                    type="file"
                    accept=".csv"
                    onChange={this.handleFileChange}
                />
            </div>
        );
    }
}

export default FilePicker;
