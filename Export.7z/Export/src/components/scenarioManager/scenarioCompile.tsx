import React from 'react';
import PropTypes from 'prop-types';
import CircularProgress from '@material-ui/core/CircularProgress';
import CompileFileIcon from 'mdi-material-ui/FileSend';
import CompileDoneFileIcon from 'mdi-material-ui/Check';
import CompileFailedFileIcon from 'mdi-material-ui/AlertCircle';
import CancelFileIcon from 'mdi-material-ui/CloseCircleOutline';
import { SCENARIO_COMPILATION_STATES, filePicker } from './scenarioConstants';
import TooltipButton from '../shared/tooltipButton';

class ScenarioCompile extends React.PureComponent {
    static propTypes = {
        data: PropTypes.shape({
            compilationResult: PropTypes.shape({
                result: PropTypes.string.isRequired,
                message: PropTypes.string.isRequired,
            }),
            isCompilingScenario: PropTypes.bool.isRequired,
            isScenarioCompiled: PropTypes.bool.isRequired,
            enableCompilation: PropTypes.bool.isRequired,
        }),
        model: PropTypes.shape({
            cancelCompilation: PropTypes.func.isRequired,
            compileScenario: PropTypes.func.isRequired,
        }).isRequired,
    };

    static defaultProps = {
        data: {
            compilationResult: { result: '', message: '' },
        },
    };

    getCompilerStatusImage(result) {
        return result === SCENARIO_COMPILATION_STATES.COMPILED ? (
            <CompileDoneFileIcon />
        ) : (
            <CompileFailedFileIcon />
        );
    }

    render() {
        const {
            model: { compileScenario, cancelCompilation },
            data: {
                isCompilingScenario,
                isScenarioCompiled,
                compilationResult: { result },
                enableCompilation,
            },
        } = this.props;

        if (isCompilingScenario)
            return (
                <div>
                    <CircularProgress className={`${filePicker}__progress`} />
                    <TooltipButton
                        className={`${filePicker}__tooltip ${filePicker}__compile-cancelbtn`}
                        tooltip="Cancel"
                        clickHandler={cancelCompilation}
                    >
                        <CancelFileIcon />
                    </TooltipButton>
                </div>
            );

        const showErrorIcon = isScenarioCompiled && result !== SCENARIO_COMPILATION_STATES.COMPILED;
        return (
            <TooltipButton
                className={`${
                    showErrorIcon
                        ? `${filePicker}__tooltip--error ${filePicker}__compile-btn`
                        : `${filePicker}__tooltip ${filePicker}__compile-btn`
                }`}
                tooltip="Compile Scenario"
                disabled={!enableCompilation}
                clickHandler={compileScenario}
            >
                {isScenarioCompiled ? this.getCompilerStatusImage(result) : <CompileFileIcon />}
            </TooltipButton>
        );
    }
}

export default ScenarioCompile;
