import _ from 'lodash';
import { localisedHeadings, commonHeadings } from './scenarioConstants';

const checkForUnrecognisedHeadings = (fileHeadings, acceptableHeadings) =>
    _.compact(_.map(fileHeadings, heading => {
        if (!_.includes(acceptableHeadings, heading)) {
            return heading;
        }
        return false;
    }));


const scenarioColumnHeadingsValidator = (csv, fileType, fileName) => {

    // Column headings can't be validated if file hasn't been selected or category hasn't been selected
    // Therefore return isValid = true to prevent user seeing errors unnecessarily
    if (!csv || (fileType !== 'Localised' && fileType !== 'Global')) {
        return { isValid: true };
    }

    // Don't validate the Cortex Path scenario file
    if (fileName === 'Cortex_Path') {
        return { isValid: true };
    }

    const fileHeadings = csv.split(/\r|\n/)[0].split(',');
    let localisedHeadingsError = false;
    let commonHeadingsError = false;
    let unrecognisedHeadings = [];

    // Localised files
    if (fileType === 'Localised') {
        // ALL of the items in localisedHeadings are compulsory
        localisedHeadingsError = !_.every(localisedHeadings, heading => _.includes(fileHeadings, heading));

        // Only headings from localisedHeadings and commonHeadings are valid
        unrecognisedHeadings = checkForUnrecognisedHeadings(fileHeadings, [...localisedHeadings, ...commonHeadings]);
        commonHeadingsError = unrecognisedHeadings.length > 0;
    }

    // Global files
    if (fileType === 'Global') {
        // Only strings from commonHeadings are valid
        unrecognisedHeadings = checkForUnrecognisedHeadings(fileHeadings, commonHeadings);
        commonHeadingsError = unrecognisedHeadings.length > 0;
    }

    return {
        isValid: !localisedHeadingsError && !commonHeadingsError,   // isValid = true if there are no errors
        localisedHeadingsError,
        commonHeadingsError,
        unrecognisedHeadings: unrecognisedHeadings.join(', '),
    };
};

export default scenarioColumnHeadingsValidator;