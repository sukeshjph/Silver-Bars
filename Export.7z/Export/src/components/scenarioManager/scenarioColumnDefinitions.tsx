import { formatDateTime } from '../../helpers/dateTime';

export default [
    {
        key: 'name',
        label: 'Scenario name' ,
        className: 'td-break-word',
        sortable: true,
    },
    {
        key: 'description',
        label: 'Description',
        className: 'td-break-word',
        sortable: true,
    },
    {
        key: 'category',
        label: 'Category',
        sortable: true,
    },
    {
        key: 'activeFileVersion',
        label: 'Active file version',
        sortable: true,
    },
    {
        key: 'tags',
        label: 'Tags',
        formatter: tags => tags ? tags.join(', ') : '',
        sortable: true,
    },
    {
        key: 'affectedBatches',
        label: 'Batch link',
        sortable: true,
    },
    {
        key: 'validFrom',
        label: 'Updated',
        className: 'td-no-wrap',
        formatter: (date) => formatDateTime(date),
        sortable: true,
    },
    {
        key: 'modifiedBy',
        label: 'Updated by',
        sortable: true,
    },
];