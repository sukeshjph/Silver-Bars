import { of, forkJoin } from 'rxjs';
import { mergeMap, switchMap, catchError, map, takeUntil, filter } from 'rxjs/operators';
import { combineEpics, Epic } from 'redux-observable';
import { isActionOf } from 'typesafe-actions';
import moment from 'moment';
import { scenarioActionTypes } from './scenarioConstants';
import { ScenarioActionsType } from './scenarioMngr.types';
import * as ScenarioActions from './scenarioActions';
import { getConfig } from '../../common/config';
import http from '../../helpers/http';

const fetchScenariosHandler = () =>
    forkJoin(
        http.getData(`${getConfig().SdxService}/batchmanagement/Scenario`),
        http.getData(`${getConfig().SdxService}/batchmanagement/Scenario?status=pending`),
        http.getData(`${getConfig().SdxService}/batchmanagement/Batch`),
    ).pipe(
        map(data => ScenarioActions.fetchScenariosComplete(data)),
        catchError(error => of(ScenarioActions.fetchScenariosError({ error: error.message }))),
    );

const fetchScenarios: Epic<ScenarioActionsType> = action$ =>
    action$.pipe(
        filter(isActionOf(ScenarioActions.fetchScenarios)),
        mergeMap(fetchScenariosHandler),
    );

const createScenario: Epic<ScenarioActionsType> = action$ =>
    action$.pipe(
        filter(isActionOf(ScenarioActions.createScenario)),
        mergeMap(action =>
            http
                .postData(
                    `${getConfig().SdxService}/batchmanagement/Scenario/create`,
                    action.payload.scenario,
                )
                .pipe(
                    map(() => ScenarioActions.createScenarioComplete()),
                    catchError(error =>
                        of(ScenarioActions.createScenarioError({ error: error.message })),
                    ),
                ),
        ),
    );

const fetchScenarioDetails: Epic<ScenarioActionsType> = action$ =>
    action$.pipe(
        filter(isActionOf(ScenarioActions.fetchScenarioDetails)),
        mergeMap(action =>
            forkJoin(
                http.getData(
                    `${getConfig().SdxService}/batchmanagement/Scenario?ukId=${
                        action.payload.ukId
                    }&status=approved`,
                ),
                http.getData(
                    `${getConfig().SdxService}/batchmanagement/Scenario?ukId=${
                        action.payload.ukId
                    }&status=pending`,
                ),
            ).pipe(
                map(data => ({
                    type: scenarioActionTypes.FETCH_SCENARIO_COMPLETE,
                    payload: {
                        approved: data[0],
                        pending: data[1],
                    },
                })),
                catchError(error =>
                    of({
                        type: scenarioActionTypes.FETCH_SCENARIO_ERROR,
                        payload: { error: error.message },
                    }),
                ),
            ),
        ),
    );

const fetchScenarioFile = scenario => {
    const { ukId, name, pending } = scenario;
    const version = scenario.version || scenario.activeFileVersion;
    const downloadUrl = `${
        getConfig().SdxService
    }/batchmanagement/Scenario/data/fileStream?ukId=${ukId}&activeFileVersion=${version}${
        pending
            ? `&status=pending&asOf=${encodeURI(moment.utc().format('YYYY-MM-DD HH:mm:ss.SSS'))}`
            : `&status=approved&asOf=${encodeURI(moment.utc().format('YYYY-MM-DD HH:mm:ss.SSS'))}`
    }`;

    return http.getFile(downloadUrl).pipe(
        map(blob => ({
            fileName: `${name}-v${version}_${ukId}.csv`,
            blob,
        })),
        catchError(error =>
            of({
                type: scenarioActionTypes.DOWNLOAD_SCENARIO_FILE_ERROR,
                payload: { error: error.message },
            }),
        ),
    );
};

const downloadScenarioFile: Epic<ScenarioActionsType> = action$ =>
    action$.pipe(
        filter(isActionOf(ScenarioActions.downloadScenarioFile)),
        mergeMap(action => fetchScenarioFile(action.payload)),
        map(blobObject => ({
            type: scenarioActionTypes.DOWNLOAD_SCENARIO_FILE_COMPLETE,
            payload: blobObject,
        })),
    );

const updateScenario: Epic<ScenarioActionsType> = action$ =>
    action$.pipe(
        filter(isActionOf(ScenarioActions.updateScenario)),
        mergeMap(action =>
            http
                .postData(
                    `${getConfig().SdxService}/batchmanagement/Scenario/update`,
                    action.payload.scenario,
                )
                .pipe(
                    map(() => ({
                        type: scenarioActionTypes.UPDATE_SCENARIO_COMPLETE,
                    })),
                    catchError(error =>
                        of({
                            type: scenarioActionTypes.UPDATE_SCENARIO_ERROR,
                            payload: { scenarioError: error.message },
                        }),
                    ),
                ),
        ),
    );

const deleteScenario: Epic<ScenarioActionsType> = action$ =>
    action$.pipe(
        filter(isActionOf(ScenarioActions.deleteScenario)),
        mergeMap(action =>
            http
                .deleteData(`${getConfig().SdxService}/batchmanagement/Scenario/delete`, {
                    type: 'Scenario',
                    ...action.payload,
                })
                .pipe(
                    map(() => ({
                        type: scenarioActionTypes.DELETE_SCENARIO_COMPLETE,
                    })),
                    catchError(error =>
                        of({
                            type: scenarioActionTypes.DELETE_SCENARIO_ERROR,
                            payload: { scenarioError: error.message },
                        }),
                    ),
                ),
        ),
    );

const checkScenarioExists: Epic<ScenarioActionsType> = action$ =>
    action$.pipe(
        filter(isActionOf(ScenarioActions.checkScenarioExists)),
        switchMap(action =>
            http
                .getData(
                    `${getConfig().SdxService}/batchmanagement/Scenario?name=${
                        action.payload.scenarioName
                    }`,
                )
                .pipe(
                    map(scenarios => ({
                        type: scenarioActionTypes.SEARCH_SCENARIO_COMPLETE,
                        payload: !!scenarios.length,
                    })),
                    catchError(error =>
                        of({
                            type: scenarioActionTypes.SEARCH_SCENARIO_ERROR,
                            payload: { error: error.message },
                        }),
                    ),
                ),
        ),
    );

const compileScenario: Epic<ScenarioActionsType> = action$ =>
    action$.pipe(
        filter(isActionOf(ScenarioActions.compileScenarioFile)),
        switchMap(action =>
            http.postFormData(`${getConfig().ShockCompilerService}`, action.payload.FileData).pipe(
                map(data => ScenarioActions.compileScenarioFileComplete({ data })),
                takeUntil(action$.ofType(ScenarioActions.compileScenarioFileCancel)),
                catchError(error =>
                    of(ScenarioActions.compileScenarioFileError({ scenarioError: error.message })),
                ),
            ),
        ),
    );

export default combineEpics(
    fetchScenarios,
    deleteScenario,
    updateScenario,
    createScenario,
    checkScenarioExists,
    compileScenario,
    fetchScenarioDetails,
    downloadScenarioFile,
);
