/* eslint-disable react/destructuring-assignment,react/button-has-type */
import React from 'react';
import PropTypes from 'prop-types';
import CloudDownloadIcon from '@material-ui/icons/CloudDownload';
import classnames from 'classnames';
import _ from 'lodash';
import scenarioDownloadsColumnDefinitions from './scenarioDownloadsColumnDefinitions';
import defaultStressTableCell from '../shared/defaultStressTableCell';


const ScenarioDownloadsTable = ({ approvedScenarios, pendingScenarios, downloadScenarioFileVersion, scenario }) => {
    const downloads = [
        ...pendingScenarios,
        ..._.orderBy(approvedScenarios, ['activeFileVersion'], ['desc']),
    ];
    const rowClass = (version) => classnames({
        'stress-table--row': true,
        'stress-table--row_selected': version.activeFileVersion === scenario.activeFileVersion && !version.pending,
    });
    return (
        <table className='stress-table stress__downloads-table'>
            <thead>
                <tr>
                    {
                        scenarioDownloadsColumnDefinitions.map(column => (
                            <th key={ column.key }
                                className={`${column.key === 'name' ? 'stress-version-table__header--first' : '' }`}>{ column.label }</th>
                        ))
                    }
                </tr>
            </thead>
            <tbody>
                {
                    downloads.map( version => (
                        <tr
                            tabIndex={-1}
                            key={version.id}
                            className={ rowClass(version) }
                        >
                            {
                                scenarioDownloadsColumnDefinitions.map(column =>
                                    column.key === 'name' ?
                                        <td
                                            className={ column.className }
                                            key={ column.key }
                                        >
                                            <button
                                                className="stress__button-secondary stress__downloads__button"
                                                onClick={ downloadScenarioFileVersion(scenario.ukId, version) }
                                            >
                                                <CloudDownloadIcon className="stress__downloads__icon" /> { version.pending ? 'Pending approval' : `version ${version.activeFileVersion}` }
                                            </button>
                                        </td>
                                        :
                                        defaultStressTableCell(column, version)
                                )
                            }
                        </tr>
                    ))
                }
            </tbody>
        </table>
    )
};


ScenarioDownloadsTable.propTypes = {
    approvedScenarios: PropTypes.arrayOf(PropTypes.object).isRequired,
    pendingScenarios: PropTypes.arrayOf(PropTypes.object).isRequired,
    downloadScenarioFileVersion: PropTypes.func.isRequired,
    scenario: PropTypes.shape({
        ukId: PropTypes.string.isRequired,            
    }).isRequired,
};

export default ScenarioDownloadsTable;