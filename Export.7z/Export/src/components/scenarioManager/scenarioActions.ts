import { createAction, createStandardAction } from 'typesafe-actions';
import { scenarioActionTypes } from './scenarioConstants';
import { ErrorType, IScenario } from '../../interfaces/globals';

export const fetchScenarios = createStandardAction(scenarioActionTypes.FETCH_SCENARIOS)<
    undefined
>();

export const fetchScenariosComplete = createAction(
    scenarioActionTypes.FETCH_SCENARIOS_COMPLETE,
    action => (data: any) =>
        action({
            scenarios: data[0],
            pendingScenarios: data[1],
            batches: data[2], // necessary to populate "Batch Link" column
        }),
);

export const fetchScenariosError = createStandardAction(scenarioActionTypes.FETCH_SCENARIOS_ERROR)<
    ErrorType
>();

export const fetchScenarioDetails = createAction(
    scenarioActionTypes.FETCH_SCENARIO,
    action => (ukId: string) =>
        action({
            ukId,
        }),
);

export const checkScenarioExists = createAction(
    scenarioActionTypes.SEARCH_SCENARIO,
    action => (scenarioName: string) =>
        action({
            scenarioName,
        }),
);

export const createScenario = createAction(
    scenarioActionTypes.CREATE_SCENARIO,
    action => (scenario: IScenario) =>
        action({
            scenario: {
                ...scenario,
                tags: scenario.tags ? scenario.tags.join(', ') : '',
            },
        }),
);

export const createScenarioComplete = createStandardAction(
    scenarioActionTypes.CREATE_SCENARIO_COMPLETE,
)<undefined>();
export const createScenarioError = createStandardAction(scenarioActionTypes.CREATE_SCENARIO_ERROR)<
    ErrorType
>();

export const updateScenario = createAction(
    scenarioActionTypes.UPDATE_SCENARIO,
    action => (scenario: IScenario) =>
        action({
            scenario: {
                ...scenario,
                tags: scenario.tags ? scenario.tags.join(', ') : '',
            },
        }),
);

export const downloadScenarioFile = createAction(
    scenarioActionTypes.DOWNLOAD_SCENARIO_FILE,
    action => (
        file: Pick<IScenario, 'ukId' | 'name' | 'validFrom' | 'activeFileVersion' | 'pending'>,
    ) => action(file),
);

export const deleteScenario = createAction(
    scenarioActionTypes.DELETE_SCENARIO,
    action => (ukId: string, comments: string) =>
        action({
            ukId,
            comments,
        }),
);

export const compileScenarioFile = createAction(
    scenarioActionTypes.COMPILE_SCENARIO,
    action => (FileData: any) =>
        action({
            FileData,
        }),
);
export const compileScenarioFileComplete = createStandardAction(
    scenarioActionTypes.COMPILE_SCENARIO_COMPLETE,
)();

export const compileScenarioFileCancel = createStandardAction(
    scenarioActionTypes.COMPILE_SCENARIO_CANCEL,
)<undefined>();
export const compileScenarioFileReset = createStandardAction(
    scenarioActionTypes.COMPILE_SCENARIO_RESET,
)<undefined>();

export const compileScenarioFileError = createStandardAction(
    scenarioActionTypes.COMPILE_SCENARIO_ERROR,
)<{ scenarioError: string }>();
