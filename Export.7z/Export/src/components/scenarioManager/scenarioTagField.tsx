/* eslint-disable react/destructuring-assignment,react/button-has-type */
import React from 'react';
import PropTypes from 'prop-types';
import shortid from 'shortid';
import { SCENARIO_TAGS } from './scenarioConstants';

class ScenarioTagField extends React.PureComponent {
    static propTypes = {
        tags: PropTypes.arrayOf(PropTypes.string).isRequired,
        handleTagChange: PropTypes.func.isRequired,
        disabled: PropTypes.bool.isRequired,
    };

    constructor(props) {
        super(props);
        this.initialState = {
            tags: props.tags,
        };
        this.state = this.initialState;
        this.handleTagChange = this.handleTagChange.bind(this);
    }

    componentWillReceiveProps(nextProps) {
        // To handle form undo functionality
        if (nextProps.tags !== this.state.tags) {
            this.setState(this.initialState);
        }
    }

    handleTagChange({ target }) {
        const { tags } = this.state;
        this.setState(
            {
                tags: target.checked
                    ? [...tags, target.value]
                    : tags.filter(tag => target.value !== tag),
            },
            () => {
                this.props.handleTagChange(this.state.tags);
            },
        );
    }

    render() {
        return (
            <div className="stress__scenario__tags">
                <div className="stress__form__field">
                    <p className="stress__form__label">Tags</p>
                    <div className="stress__form__inline">
                        {SCENARIO_TAGS.map(tag => (
                            <label
                                className="stress__form__checkbox-label"
                                key={shortid.generate()}
                            >
                                {tag}
                                <input
                                    className="stress__form__input stress__scenario__tag"
                                    type="checkbox"
                                    checked={this.state.tags.includes(tag)}
                                    onChange={this.handleTagChange}
                                    value={tag}
                                    disabled={this.props.disabled}
                                />
                            </label>
                        ))}
                    </div>
                </div>
            </div>
        );
    }
}

export default ScenarioTagField;
