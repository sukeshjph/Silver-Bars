import { formatDateTime } from '../../helpers/dateTime';

export default [
    {
        label: 'File Versions',
        key: 'name',
        className: 'td-break-word',
    },
    {
        label: 'Category',
        key: 'category',
    },
    {
        label: 'Updated',
        key: 'validFrom',
        className: 'td-no-wrap',
        formatter: (date) => formatDateTime(date),
        csvFormatter: (date) => `'${date}'`,
    },
];