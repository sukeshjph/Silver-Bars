import React from 'react';
import _ from 'lodash';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import FilePicker from './filePicker';
import ScenarioCompile from './scenarioCompile';
import ScenarioTagField from './scenarioTagField';
import ScenarioNameField from './scenarioNameField';
import ReasonForChange from './reasonForChange';
import getFormFieldClass from '../../helpers/getFormFieldClass';
import { uniq } from '../../helpers/utilities';
import { SCENARIO_COMPILATION_STATES, SCENARIO_COMPILATION_TYPES } from './scenarioConstants';

interface ScenarioAddEditDialogPropsType {
    confirmHandler: () => void;
    cancelHandler: () => void;
    doneHandler: () => void;
    cancelCompilationHandler: () => void;
    data: {
        selectedScenario: any;
        isSavingScenario?: boolean;
        isCompilingScenario?: boolean;
        isScenarioCompiled?: boolean;
        scenarioError?: string;
        compilationResult?: {
            result: string;
            message: string;
        };
    };
    actions: {
        compileScenarioFile: () => void;
        compileScenarioFileReset: () => void;
    };
    toShow: boolean;
}

interface AddeDitDialogState {
    selectedScenario: any;
    isEditing: boolean;
    touched: any[];
    saveSuccessMessage: string;
    saveErrorMessage: string;
    theFile: any;
    enableCompilation: boolean;
    nameIsValid: boolean;
    categoryIsValid: boolean;
    descriptionIsValid: boolean;
    fileIsValid: boolean;
}

class ScenarioAddEditDialog extends React.PureComponent<
    ScenarioAddEditDialogPropsType,
    AddeDitDialogState
> {
    static defaultProps = {
        data: {
            selectedScenario: {},
        },
        toShow: true,
    };

    constructor(props) {
        super(props);
        this.confirmHandler = this.confirmHandler.bind(this);
        this.undoHandler = this.undoHandler.bind(this);
        this.handleFileChange = this.handleFileChange.bind(this);
        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.handleNameChange = this.handleNameChange.bind(this);
        this.handleTagChange = this.handleTagChange.bind(this);

        const isEditing = !!props.data.selectedScenario;

        this.initialState = {
            selectedScenario: props.data.selectedScenario || {
                name: '',
                description: '',
                category: '',
                tags: [],
                type: 'Scenario',
                data: '',
            },
            isEditing,
            touched: [],
            saveSuccessMessage: '',
            saveErrorMessage: '',
            theFile: null,
            enableCompilation: false,
            nameIsValid: isEditing, // If editing, the name provided in props will be valid
            categoryIsValid: isEditing, // If editing, the category provided in props will be valid
            descriptionIsValid: isEditing, // If editing, the description provided in props will be valid
            fileIsValid: isEditing, // If editing, the file provided in props will be valid
        };
        this.state = this.initialState;
    }

    componentWillReceiveProps(nextProps) {
        this.setState(prevState => ({
            saveErrorMessage: nextProps.data.scenarioError,
            saveActionCompleted:
                prevState.isSavingScenario === true && nextProps.data.isSavingScenario === false,
        }));
    }

    getFieldClassName = fieldName => {
        const showErrorState =
            _.includes(this.state.touched, fieldName) &&
            this.state[`${fieldName}IsValid`] === false;

        return `stress__add-edit__${fieldName} ${getFormFieldClass(!showErrorState)}`;
    };

    getCompilationError = ({ result, message }) => {
        if (result !== SCENARIO_COMPILATION_STATES.COMPILED) {
            return message;
        }
        return '';
    };

    getCompilerButtonStatus = (changeType, prevCompilerState, isScenarioCompiled) => {
        if (changeType !== SCENARIO_COMPILATION_TYPES.CATEGORY) return true;
        return isScenarioCompiled ? prevCompilerState : true;
    };

    handleFieldChange = prop => ({ target: { value } }) => {
        this.setState(prevState => ({
            selectedScenario: {
                ...prevState.selectedScenario,
                [prop]: value,
            },
            [`${prop}IsValid`]: !!value,
            touched: uniq([...prevState.touched, prop]),
        }));
    };

    

    removeActiveFileVersion = scenario => {
        const { activeFileVersion, ...otherScenarioProps } = scenario;
        return otherScenarioProps;
    };

    handleTagChange = tags => {
        this.setState(prevState => ({
            selectedScenario: {
                ...prevState.selectedScenario,
                tags,
            },
        }));
    };

    handleCompileScenario = () => {
        const {
            actions: { compileScenarioFile },
        } = this.props;

        const { theFile } = this.state;

        const data = new FormData();
        data.append('type', 'Scenario');
        data.append('file', theFile);

        this.setState({ enableCompilation: false }, () => {
            compileScenarioFile(data);
        });
    };

    initialState: AddeDitDialogState;

    handleNameChange(name, nameIsValid) {
        this.setState(prevState => ({
            selectedScenario: {
                ...prevState.selectedScenario,
                name,
            },
            nameIsValid,
        }));
    }

    handleFileChange(csv, fileIsValid, theFile, changeType = '') {
        const {
            actions: { compileScenarioFileReset },
        } = this.props;

        if (fileIsValid) {
            const { theFile: theOldSelectedFile } = this.state;
            this.setState(
                (prevState, prevProps) => ({
                    selectedScenario: {
                        ...this.removeActiveFileVersion(prevState.selectedScenario),
                        data: csv,
                    },
                    fileIsValid,
                    theFile,
                    enableCompilation: this.getCompilerButtonStatus(
                        changeType,
                        prevState.enableCompilation,
                        prevProps.data.isScenarioCompiled,
                    ),
                    touched: uniq([...prevState.touched, 'data']),
                    saveSuccessMessage:
                        'Changes saved and queued for approval. Check Approval Inbox.',
                }),
                () => {
                    if (changeType !== SCENARIO_COMPILATION_TYPES.CATEGORY && theOldSelectedFile) {
                        compileScenarioFileReset();
                    }
                },
            );
        } else {
            this.setState({ fileIsValid, enableCompilation: false }, () => {
                compileScenarioFileReset();
            });
        }
    }

    undoHandler() {
        const {
            actions: { compileScenarioFileReset },
        } = this.props;
        this.setState(this.initialState, () => {
            compileScenarioFileReset();
        });
    }

    confirmHandler(changeReason) {
        const { selectedScenario } = this.state;
        const { confirmHandler } = this.props;
        confirmHandler({
            ...selectedScenario,
            comments: changeReason,
        });
    }

    checkFormIsValid() {
        const { nameIsValid, categoryIsValid, descriptionIsValid, fileIsValid } = this.state;
        return _.every([nameIsValid, categoryIsValid, descriptionIsValid, fileIsValid]);
    }

    render() {
        const {
            data: {
                scenarioError,
                isCompilingScenario,
                isScenarioCompiled,
                compilationResult,
                isSavingScenario: isScenarioSaving,
                hasSavedScenario,
            },
            cancelCompilationHandler,
            cancelHandler,
            doneHandler,
            toShow,
        } = this.props;

        const {
            selectedScenario: { category, name, data: scenarioData, description, tags },
            isSavingScenario,
            saveActionCompleted,
            isEditing,
            saveSuccessMessage,
            saveErrorMessage,
            enableCompilation,
        } = this.state;

        if (!toShow) return null;

        const formDisabled =
            !!(isSavingScenario || saveActionCompleted || isCompilingScenario) && !scenarioError;

        const filePickerProps = {
            isRequired: !isEditing,
            fileType: category,
            disabled: formDisabled,
            fileName: name,
            theFile: scenarioData,
            handleFileChange: this.handleFileChange,
            compilationError: this.getCompilationError(compilationResult),
        };
        return (
            <Dialog
                maxWidth="sm"
                open
                id="stress--scenario-dialog"
                className="stress__dialog"
                onClose={cancelHandler}
            >
                <DialogTitle id="stress--scenario-dialog--title">
                    {isEditing ? 'Update scenario' : 'Create scenario'}
                </DialogTitle>
                <DialogContent>
                    <form className="stress__form">
                        <FilePicker {...filePickerProps}>
                            <ScenarioCompile
                                model={{
                                    cancelCompilation: cancelCompilationHandler,
                                    compileScenario: this.handleCompileScenario,
                                }}
                                data={{
                                    isCompilingScenario,
                                    isScenarioCompiled,
                                    compilationResult,
                                    enableCompilation,
                                }}
                            />
                        </FilePicker>
                        <ScenarioNameField
                            scenarioName={name}
                            disabled={formDisabled}
                            handleNameChange={this.handleNameChange}
                        />

                        <div className={this.getFieldClassName('description')}>
                            <label htmlFor="scenario-description" className="stress__form__label">
                                Description
                            </label>
                            <input
                                id="scenario-description"
                                placeholder="Enter description"
                                className="stress__form__input"
                                onChange={this.handleFieldChange('description')}
                                value={description}
                                disabled={formDisabled}
                                type="text"
                            />
                            <p className="stress__form__help-text">Required</p>
                        </div>

                        <div className={this.getFieldClassName('category')}>
                            <label htmlFor="scenario-category" className="stress__form__label">
                                Category
                            </label>
                            <select
                                value={category}
                                className="stress__form__select"
                                onChange={this.handleFieldChange('category')}
                                id="scenario-category"
                                disabled={formDisabled || isEditing}
                            >
                                <option value="">Select category</option>
                                <option value="Global">Global</option>
                                <option value="Localised">Localised</option>
                            </select>
                            {!isEditing && <p className="stress__form__help-text">Required</p>}
                        </div>

                        <ScenarioTagField
                            disabled={formDisabled}
                            handleTagChange={this.handleTagChange}
                            tags={tags}
                        />

                        <ReasonForChange
                            actions={{
                                handleSaveClick: this.confirmHandler,
                                handleUndoClick: this.undoHandler,
                                handleDoneClick: doneHandler,
                            }}
                            model={{
                                isSaving: isScenarioSaving,
                                hasSaved: hasSavedScenario,
                                comments: '',
                                isValid: this.checkFormIsValid(),
                                saveErrorMessage,
                                saveSuccessMessage,
                                isScenarioCompiled,
                                isCompilingScenario,
                                compilationResult,
                            }}
                        />
                    </form>
                </DialogContent>
                <DialogActions>
                    <button
                        className="stress__button-secondary stress__add-edit-dialog__cancel"
                        onClick={cancelHandler}
                        type="button"
                    >
                        Close
                    </button>
                </DialogActions>
            </Dialog>
        );
    }
}

export default ScenarioAddEditDialog;
