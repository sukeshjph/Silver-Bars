import _ from 'lodash';
import sortBy from 'lodash.sortby';
import fileDownload from 'js-file-download';
import { scenarioActionTypes } from './scenarioConstants';
import { MAX_DATE } from '../../constants';
import reorderScenarios from '../../helpers/reorderScenarios';
import reorderBatches from '../../helpers/reorderBatches';

const initialState = {
    scenarios: [],
    approvedScenarios: [],
    pendingScenarios: [],
    doesScenarioExist: false,
    isFetchingScenario: false,
    isFetchingScenarios: false,
    isFetchingScenarioDetails: false,
    isSavingScenario: false,
    isDeletingScenario: false,
    isCompilingScenario: false,
    isScenarioCompiled: false,
    compilationResult: { result: '', message: '' },
    hasDeletedScenario: false,
    scenarioError: '',
};

export default (state = initialState, action) => {
    switch (action.type) {
        case scenarioActionTypes.FETCH_SCENARIOS:
            return {
                ...state,
                isFetchingScenarios: true,
                error: null,
            };
        case scenarioActionTypes.FETCH_SCENARIOS_COMPLETE: {
            const { scenarios, pendingScenarios, batches } = action.payload;
            return {
                ...state,
                isFetchingScenarios: false,
                scenarios: reorderScenarios(scenarios, pendingScenarios, reorderBatches(batches)),
                pendingScenarios,
            };
        }
        case scenarioActionTypes.FETCH_SCENARIOS_ERROR: {
            return {
                ...state,
                isFetchingScenarios: false,
                error: action.payload.error,
            };
        }
        case scenarioActionTypes.CREATE_SCENARIO:
        case scenarioActionTypes.UPDATE_SCENARIO:
            return {
                ...state,
                isSavingScenario: true,
                scenarioError: '',
            };
        case scenarioActionTypes.CREATE_SCENARIO_COMPLETE:
        case scenarioActionTypes.UPDATE_SCENARIO_COMPLETE:
            return {
                ...state,
                isSavingScenario: false,
            };
        case scenarioActionTypes.CREATE_SCENARIO_ERROR:
        case scenarioActionTypes.UPDATE_SCENARIO_ERROR:
            return {
                ...state,
                isSavingScenario: false,
                scenarioError: action.payload.scenarioError,
            };

        case scenarioActionTypes.COMPILE_SCENARIO:
            return {
                ...state,
                isCompilingScenario: true,
                isScenarioCompiled: false,
                compilationResult: { result: '', message: '' },
                scenarioError: '',
            };

        case scenarioActionTypes.COMPILE_SCENARIO_COMPLETE:
            return {
                ...state,
                isCompilingScenario: false,
                isScenarioCompiled: true,
                compilationResult: action.payload.data,
                scenarioError: '',
            };

        case scenarioActionTypes.COMPILE_SCENARIO_CANCEL:
            return {
                ...state,
                isCompilingScenario: false,
                isScenarioCompiled: false,
                compilationResult: { result: '', message: '' },
                scenarioError: '',
            };
        case scenarioActionTypes.COMPILE_SCENARIO_RESET:
            return {
                ...state,
                isCompilingScenario: false,
                isScenarioCompiled: false,
                compilationResult: { result: '', message: '' },
                scenarioError: '',
            };
        case scenarioActionTypes.COMPILE_SCENARIO_ERROR:
            return {
                ...state,
                isCompilingScenario: false,
                compilationResult: { result: '', message: '' },
                scenarioError: action.payload.scenarioError,
            };
        case scenarioActionTypes.DELETE_SCENARIO:
            return {
                ...state,
                isDeletingScenario: true,
            };
        case scenarioActionTypes.DELETE_SCENARIO_COMPLETE:
            return {
                ...state,
                isDeletingScenario: false,
            };
        case scenarioActionTypes.DELETE_SCENARIO_ERROR:
            return {
                ...state,
                isDeletingScenario: false,
                scenarioError: action.payload.scenarioError,
            };
        case scenarioActionTypes.FETCH_SCENARIO:
            return {
                ...state,
                isFetchingScenarioDetails: true,
                approvedScenarios: [],
                pendingScenarios: [],
            };
        case scenarioActionTypes.FETCH_SCENARIO_COMPLETE: {
            /* Need some fairly nasty manipulation in here.
             We need to de-dupe activeFileVersions but ensure
             the most recent of any fileVersion is the one used.
             Then sort by descending validFrom. Ye-owchy.
             I suspect there is a more efficient approach than this.
             */
            const pending = _.find(action.payload.pending, scenario =>
                _.includes(scenario.validTo, MAX_DATE),
            );
            return {
                ...state,
                isFetchingScenarioDetails: false,
                approvedScenarios: _.reverse(
                    sortBy(
                        _.uniqBy(action.payload.approved, 'activeFileVersion'),
                        'activeFileVersion',
                    ),
                ),
                pendingScenarios: pending ? [{ ...pending, pending: true }] : [],
            };
        }
        case scenarioActionTypes.FETCH_SCENARIO_ERROR: {
            return {
                ...state,
                isFetchingScenarioDetails: false,
                error: action.payload.error,
            };
        }
        case scenarioActionTypes.SEARCH_SCENARIO: {
            return {
                ...state,
                isFetchingScenario: true,
            };
        }
        case scenarioActionTypes.SEARCH_SCENARIO_COMPLETE: {
            return {
                ...state,
                isFetchingScenario: false,
                doesScenarioExist: action.payload,
            };
        }
        case scenarioActionTypes.SEARCH_SCENARIO_ERROR: {
            return {
                ...state,
                isFetchingScenario: false,
                error: action.payload.error,
            };
        }

        case scenarioActionTypes.DOWNLOAD_SCENARIO_FILE: {
            return {
                ...state,
                isDownloadingFile: true,
            };
        }

        case scenarioActionTypes.DOWNLOAD_SCENARIO_FILE_COMPLETE: {
            const { blob, fileName } = action.payload;
            fileDownload(blob, fileName);
            return {
                ...state,
                isDownloadingFile: false,
            };
        }

        case scenarioActionTypes.DOWNLOAD_SCENARIO_FILE_ERROR: {
            return {
                ...state,
                isDownloadingFile: false,
                error: action.payload.error,
            };
        }
        default:
            return state;
    }
};
