/* eslint-disable react/destructuring-assignment,react/button-has-type */
import React from 'react';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import ReasonForChange from '../shared/reasonForChange';
import getAffectedBatches from '../../helpers/getAffectedBatches';
import {
    IScenarioMainModel,
    IScenarioManagerState,
    IBatchesMainModel,
} from './scenarioMngr.types';

type deleteDataPropsType = Pick<
    IScenarioMainModel,
    'isDeletingScenario' | 'scenarioError' | 'scenarios'
> &
    Pick<IScenarioManagerState, 'scenarioBeingDeleted'> &
    Pick<IBatchesMainModel, 'batches'>;

class ScenarioDeleteDialog extends React.PureComponent<
    {
        data: deleteDataPropsType;
        cancelHandler(): void;
        confirmHandler: (reason: string) => void;
        doneHandler(shouldRefreshScenarios: boolean): void;
    },
    {}
> {
    render() {
        const { confirmHandler, cancelHandler, doneHandler, data } = this.props;
        const scenario = data.scenarios.find(scn => scn.ukId === data.scenarioBeingDeleted);
        return (
            <Dialog
                maxWidth="md"
                aria-labelledby="delete-scenario-dialog-title"
                open
                id="delete-scenario-dialog"
                className="stress__dialog"
                onClose={cancelHandler}
            >
                <DialogTitle id="delete-scenario-dialog-title">
                    {scenario ? `Delete ${scenario.name}?` : 'Deleted'}
                </DialogTitle>
                <DialogContent>
                    {scenario && (
                        <p className="stress__delete-scenario-dialog__affected">
                            {getAffectedBatches(data.batches, scenario)}
                        </p>
                    )}
                    <ReasonForChange
                        actions={{
                            handleSaveClick: confirmHandler,
                            handleDoneClick: doneHandler,
                            handleUndoClick: cancelHandler,
                        }}
                        model={{
                            isSaving: data.isDeletingScenario,
                            saveErrorMessage: data.scenarioError,
                            saveSuccessMessage:
                                'Deletion has been queued for Approval. Check Approval Inbox.',
                        }}
                    />
                </DialogContent>
                <DialogActions>
                    <button
                        className="stress__button-secondary stress__delete-dialog__cancel"
                        onClick={cancelHandler}
                    >
                        Close
                    </button>
                </DialogActions>
            </Dialog>
        );
    }
}

export default ScenarioDeleteDialog;
