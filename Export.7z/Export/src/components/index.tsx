import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Route, Switch, withRouter, Link } from 'react-router-dom';
import Home from '@material-ui/icons/Home';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import Tooltip from '@material-ui/core/Tooltip';
import DashboardIcon from 'mdi-material-ui/ViewDashboard';
import InboxIcon from 'mdi-material-ui/Inbox';
import BatchesIcon from 'mdi-material-ui/FolderMultiple';
import ScenariosIcon from 'mdi-material-ui/FileMultiple';
import ScenarioAuditIcon from 'mdi-material-ui/FileSearch';
import BatchAuditIcon from 'mdi-material-ui/FolderSearch';
import MrReportsIcon from 'mdi-material-ui/FileChart';

import * as Actions from '../actions';
import LoginForm from './shared/loginForm';
import {
    Downloads,
    BatchDetails,
    BatchSummary,
    ScenarioManager,
    ScenarioAudit,
    BatchAudit,
    Inbox,
    BatchSchedule,
} from './asyncRoutes';
import { hasAccess } from '../helpers/authentication';

import '../styles/application.scss';

export class StressTesting extends PureComponent {
    state = {
        moduleIcons: {
            '/dashboard': <DashboardIcon />,
            '/batches':<BatchesIcon/>,
            '/scenarios': <ScenariosIcon />,
            '/inbox': <InboxIcon />,
            '/batch-audit': <BatchAuditIcon />,
            '/scenario-audit': <ScenarioAuditIcon />,
            '/downloads': <MrReportsIcon />,
        },
        moduleToolTips: {
            '/dashboard': 'Dashboard',
            '/batches': 'Batches',
            '/scenarios': 'Scenarios',
            '/inbox': 'Approvals Inbox',
            '/batch-audit': 'Batch Audit',
            '/scenario-audit': 'Scenario Audit',
            '/downloads': 'MR Reports',
        },
    };

    componentDidMount() {
        const {
            actions: { reloadSession },
        } = this.props;
        reloadSession();
    }

    getNavKeySelectionClass = (navKey, pathname) => {
        if (pathname === '/' && navKey === '/dashboard')
            return 'stress-left-nav__list-item--selected';
        if (pathname === navKey) return 'stress-left-nav__list-item--selected';
        return '';
    };

    render() {
        const {
            user,
            actions,
            location: { pathname },
        } = this.props;
        const { moduleIcons, moduleToolTips } = this.state;

        return (
            <div id="stress-ui-content">
                {hasAccess() ? (
                    <React.Fragment>
                        <div className="stress-ui-side-menu">
                            <div className="logo-area">
                                <div className="stress-log-link">
                                    <Home />
                                </div>
                            </div>
                            <List component="nav" className="stress-left-nav">
                                {Object.keys(moduleIcons).map(navKey => (
                                    <Tooltip
                                        title={moduleToolTips[navKey]}
                                        placement="right"
                                        classes={{ tooltip: 'stress-left-nav__tooltip' }}
                                        enterDelay={200}
                                        leaveDelay={200}
                                    >
                                        <Link to={navKey}>
                                            <ListItem
                                                button
                                                className={`stress-left-nav__list-item ${this.getNavKeySelectionClass(
                                                    navKey,
                                                    pathname,
                                                )}`}
                                            >
                                                <ListItemIcon className="stress-left-nav__icon">
                                                    {moduleIcons[navKey]}
                                                </ListItemIcon>
                                            </ListItem>
                                        </Link>
                                    </Tooltip>
                                ))}
                            </List>
                        </div>
                        <div id="stress-ui-components">
                            <Switch>
                                <Route exact path="/" component={BatchSchedule} />
                                <Route exact path="/downloads" component={Downloads} />
                                <Route exact path="/batches/:batchId" component={BatchDetails} />
                                <Route exact path="/batch-audit" component={BatchAudit} />
                                <Route exact path="/batches" component={BatchSummary} />
                                <Route exact path="/scenarios" component={ScenarioManager} />
                                <Route exact path="/scenario-audit" component={ScenarioAudit} />
                                <Route exact path="/inbox" component={Inbox} />
                                <Route exact path="/dashboard" component={BatchSchedule} />
                            </Switch>
                        </div>
                    </React.Fragment>
                ) : (
                    <LoginForm
                        signIn={actions.signIn}
                        failedAuthentication={user.failedAuthentication}
                        isSigningIn={user.isSigningIn}
                    />
                )}
            </div>
        );
    }
}

StressTesting.propTypes = {
    actions: PropTypes.shape({
        reloadSession: PropTypes.func.isRequired,
        signIn: PropTypes.func.isRequired,
    }).isRequired,
    user: PropTypes.shape({
        failedAuthentication: PropTypes.bool.isRequired,
        isSigningIn: PropTypes.bool.isRequired,
    }).isRequired,
    location: PropTypes.shape({
        pathname: PropTypes.string.isRequired,
    }).isRequired,
};

const mapStateToProps = state => ({ model: state.BATCHES, user: state.USER });

const mapDispatchToProps = dispatch => ({ actions: bindActionCreators(Actions, dispatch) });

export const StressTestingContainer = withRouter(
    connect(
        mapStateToProps,
        mapDispatchToProps,
    )(StressTesting),
);
