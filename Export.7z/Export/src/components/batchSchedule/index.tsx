import React from 'react';
import { bindActionCreators } from 'redux';
import { connect, Dispatch } from 'react-redux';
import { RootState } from 'typesafe-actions';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import moment from 'moment';
import Spinner from 'react-spinkit';
import shortid from 'shortid';
import 'react-placeholder/lib/reactPlaceholder.css';
import * as BatchScheduleActions from './batchScheduleActions';
import BatchHeader from '../shared/batchHeaderLinks';
import BatchCalendar from './batchCalendar';
import * as BatchScheduleSelectors from './batchScheduleSelector';
import WithBatchListHoc from './withBatchListHoc';
import BatchListByDay from './batchList';
import BatchDay from './batchDay';
import { dateFormat, batchDaysToshow, dayType, Weekdays } from './batchScheduleConstants';
import { accent } from '../../styles/_variables.scss';
import { pick } from '../../helpers/utilities';
import LoadingData from '../shared/loadingData';
import {
    IBatchScheduleProps,
    IBatchScheduleState,
    BatchScheduleActionsType,
} from './batchSchedule.types';
import './batchSchedule.scss';

const BatchList = WithBatchListHoc(BatchListByDay);

export class BatchSchedule extends React.PureComponent<IBatchScheduleProps, IBatchScheduleState> {
    state: IBatchScheduleState = {
        yesterday: moment().subtract(1, 'days'),
        selectedDate: moment(),
        batchDays: BatchSchedule.getBatchDaysList(moment(), batchDaysToshow),
        firstPageLoad: true,
    };

    componentDidMount() {
        const {
            actions: { fetchBatchesByDate },
        } = this.props;
        const { selectedDate } = this.state;
        // fetchBatchStatus(['Subscription-ACK', 'BatchProgress']);
        fetchBatchesByDate(
            selectedDate.format(dateFormat),
            moment(selectedDate)
                .clone()
                .add(batchDaysToshow, 'days')
                .format(dateFormat),
        );
    }

    componentDidUpdate(prevProps: IBatchScheduleProps) {
        const {
            batchesByDate,
            isFetchingBatchesByDate,
            allbatchesStatus: { subscriptionId },
            actions: { requestBatchProgressForBatches, fetchPastBatchProgressStatus },
        } = this.props;

        if (!isFetchingBatchesByDate) {
            const { batchesByDate: prevBatchesByDate } = prevProps;

            if (batchesByDate !== prevBatchesByDate) {
                if (Object.keys(batchesByDate).length !== 0) {
                    const { yesterday } = this.state;
                    const todaysBatches = this.getBatchListByDay(moment(), batchesByDate);
                    const yesterdayBatches = this.getBatchListByDay(yesterday, batchesByDate);

                    if (todaysBatches.length === 0 && yesterdayBatches.length === 0) return;

                    if (todaysBatches.length !== 0) {
                        requestBatchProgressForBatches(
                            todaysBatches.map(batch => pick(batch, ['ukId', 'id'])),
                            subscriptionId,
                        );
                    }

                    if (yesterdayBatches.length !== 0) {
                        fetchPastBatchProgressStatus(
                            yesterday.format(dateFormat),
                            yesterdayBatches.map(batch => pick(batch, ['ukId', 'id'])),
                        );
                    }
                }
            }
        }
    }

    static getBatchDaysList = (selectedDate, daysToShow: number) =>
        [...Array(daysToShow + 1)]
            .map((_, index) => {
                const givenDate = moment(selectedDate)
                    .clone()
                    .add(index, 'day');

                return {
                    date: givenDate,
                    weekDay: BatchSchedule.getWeekdayType(givenDate),
                    id: shortid.generate(),
                };
            })
            .filter(batchDay => ![0, 6].includes(moment(batchDay.date).day()));

    static getWeekdayType = (inDate: any) => {
        if (moment(inDate).date() - moment().date() === 0) {
            return 'Today';
        }

        if (moment(inDate).date() - moment().date() === 1) {
            return 'Tomorrow';
        }

        return Weekdays[moment(inDate).weekday()];
    };

    getBatchListByDay = (givenDate, batchesByDate) =>
        batchesByDate[moment(givenDate).format(dateFormat)] || [];

    getBatchDayType = batchDate => {
        if (moment().date() - moment(batchDate).date() === 1) {
            return dayType.YESTERDAY;
        }

        if (moment().date() - moment(batchDate).date() >= 1) {
            return dayType.PAST;
        }

        if (moment(batchDate).date() - moment().date() === 0) {
            return dayType.TODAY;
        }

        if (moment(batchDate).date() - moment().date() === 1) {
            return dayType.TOMORROW;
        }

        if (moment(batchDate).date() - moment().date() >= 1) {
            return dayType.FUTURE;
        }

        return dayType.OTHERS;
    };

    handleChange = selectedDate => {
        const {
            isFetchingBatchesByDate,
            actions: { fetchBatchesByDate },
        } = this.props;

        if (!isFetchingBatchesByDate) {
            this.setState(
                {
                    selectedDate,
                    batchDays: BatchSchedule.getBatchDaysList(selectedDate, batchDaysToshow),
                    firstPageLoad: false,
                },
                () => {
                    fetchBatchesByDate(
                        selectedDate.format(dateFormat),
                        moment(selectedDate)
                            .clone()
                            .add(batchDaysToshow, 'days')
                            .format(dateFormat),
                    );
                },
            );
            return true;
        }

        return false;
    };

    renderBatchDays = () => {
        const { batchDays, firstPageLoad } = this.state;
        const {
            batchesByDate,
            isFetchingBatchesByDate,
            isFetchingPastBatchesProgress,
            allbatchesStatus,
            pastBatchesProgress,
        } = this.props;

        return batchDays.map(day => (
            <BatchDay batchDay={day} key={day.id} firstPageLoad={firstPageLoad}>
                <LoadingData
                    showLoading={isFetchingBatchesByDate}
                    render={() => (
                        <div className="batch-schedule__batch-details-loading">
                            <Spinner name="ball-beat" color={accent} />
                        </div>
                    )}
                    delay="1500ms"
                />
                {!isFetchingBatchesByDate && (
                    <BatchList
                        batchList={this.getBatchListByDay(day.date, batchesByDate)}
                        isFetchingPastBatchesProgress={isFetchingPastBatchesProgress}
                        allbatchesStatus={allbatchesStatus}
                        pastBatchesProgress={pastBatchesProgress}
                        batchDate={day.date}
                        asOfDayType={this.getBatchDayType(day.date)}
                    />
                )}
            </BatchDay>
        ));
    };

    render() {
        const { selectedDate } = this.state;
        const { isFetchingBatchesByDate } = this.props;
        return (
            <section id="stress-batch-schedule" className="stress-ui-container batch-schedule">
                <BatchHeader navHeaderTitle="Stress Testing Dashboard" />
                <Paper>
                    <Grid container spacing={16}>
                        <Grid item md={4} lg={4}>
                            <BatchCalendar
                                data={{
                                    selectedDate,
                                    isFetchingBatchesByDate,
                                }}
                                methods={{
                                    handleChange: this.handleChange,
                                }}
                            />
                        </Grid>
                        <Grid
                            item
                            md={8}
                            lg={8}
                            className={`${
                                isFetchingBatchesByDate ? 'batch-schedule-batch-list__loading' : ''
                            }`}
                        >
                            {this.renderBatchDays()}
                        </Grid>
                    </Grid>
                </Paper>
            </section>
        );
    }
}

export const BatchScheduleConnected = connect(
    (state: RootState) => ({
        batchesByDate: BatchScheduleSelectors.getBatchesByDate(state),
        isFetchingBatchesByDate: BatchScheduleSelectors.getIsFetchingBatchesByDate(state),
        isFetchingPastBatchesProgress: BatchScheduleSelectors.getIsFetchingPastBatchesProgress(
            state,
        ),
        allbatchesStatus: BatchScheduleSelectors.getAllbatchesStatus(state),
        pastBatchesProgress: BatchScheduleSelectors.getPastBatchesProgress(state),
    }),
    (dispatch: Dispatch<BatchScheduleActionsType>) => ({
        actions: bindActionCreators(BatchScheduleActions, dispatch),
    }),
)(BatchSchedule);
