import { createAction, createStandardAction } from 'typesafe-actions';
import { batchScheduleActionTypes } from './batchScheduleConstants';
import { IBatch } from '../../interfaces/globals';
import { ErrorType } from './batchSchedule.types';

// batch schedule Actions
export const fetchBatchesByDate = createAction(
    batchScheduleActionTypes.FETCH_BATCHES_BY_DATE,
    action => (fromDate: string, toDate: string) => action({ fromDate, toDate }),
);

export const fetchBatchesByDateComplete = createAction(
    batchScheduleActionTypes.FETCH_BATCHES_BY_DATE_COMPLETE,
    action => (batchesByDate, allBatches) => action({ batchesByDate, allBatches }),
);

export const fetchBatchesByDateError = createStandardAction(
    batchScheduleActionTypes.FETCH_BATCHES_BY_DATE_ERROR,
)<ErrorType>();

export const fetchBatchStatus = createAction(
    batchScheduleActionTypes.FETCH_BATCH_STATUS,
    action => events => action({ events }),
);

export const fetchBatchStatusComplete = createAction(
    batchScheduleActionTypes.FETCH_BATCH_STATUS_COMPLETE,
    action => (event: { eventType: any; eventData: any }) => action(event),
);

export const fetchBatchStatusError = createStandardAction(
    batchScheduleActionTypes.FETCH_BATCH_STATUS_ERROR,
)<ErrorType>();

export const requestBatchProgressForBatches = createAction(
    batchScheduleActionTypes.REQUEST_BATCH_PROGRESS_FOR_BATCHES,
    action => (batches: IBatch[], subscriptionId: string) => action({ batches, subscriptionId }),
);

export const requestBatchProgressForBatchesComplete = createAction(
    batchScheduleActionTypes.REQUEST_BATCH_PROGRESS_FOR_BATCHES_COMPLETE,
    action => curBatchesStatus => action(curBatchesStatus),
);

export const requestBatchProgressForBatchesError = createStandardAction(
    batchScheduleActionTypes.REQUEST_BATCH_PROGRESS_FOR_BATCHES_ERROR,
)<ErrorType>();

export const fetchPastBatchProgressStatus = createStandardAction(
    batchScheduleActionTypes.FETCH_PAST_BATCH_PROGRESS_STATUS,
).map((pastDate: any, batches: IBatch[]) => ({
    payload: { pastDate, batches },
}));

export const fetchPastBatchProgressStatusComplete = createAction(
    batchScheduleActionTypes.FETCH_PAST_BATCH_PROGRESS_STATUS_COMPLETE,
    action => batchesWithStatus => action({ batchesWithStatus }),
);

export const fetchPastBatchProgressStatusError = createStandardAction(
    batchScheduleActionTypes.FETCH_PAST_BATCH_PROGRESS_STATUS_ERROR,
)<ErrorType>();
