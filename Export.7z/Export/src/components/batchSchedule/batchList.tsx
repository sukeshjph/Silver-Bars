/* eslint-disable  jsx-a11y/anchor-is-valid */
import React from 'react';
import { Link } from 'react-router-dom';
import moment from 'moment';
import ReactPlaceholder from 'react-placeholder';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import 'react-tippy/dist/tippy.css';
import Spinner from 'react-spinkit';
import BatchProgressDoneIcon from 'mdi-material-ui/Check';
import BatchProgressFailedIcon from 'mdi-material-ui/AlertCircle';
import BatchListItem from '../shared/batchListItem';
import { red, accent } from '../../styles/_variables.scss';
import { dayType } from './batchScheduleConstants';
import { IBatch, IScenario } from '../../interfaces/globals';
import { IBatchesStatus } from './batchSchedule.types';
import { getConfig } from '../../common/config';

const batchProgressImages = {
    STARTED: <Spinner name="ball-beat" color={accent} />,
    ERROR: <BatchProgressFailedIcon style={{ color: red }} />,
    FINISHED: <BatchProgressDoneIcon style={{ color: accent }} />,
};

type BatchListProps = {
    batchList: any;
    isFetchingPastBatchesProgress: boolean;
    dayName: any;
    currentBatchesStatus: IBatchesStatus[];
    pastBatchesStatusList: IBatchesStatus[];
    batchDate: any;
    asOfDayType: string;
};

const defaultProps = {
    isFetchingPastBatchesProgress: null,
    pastBatchesStatusList: [],
    currentBatchesStatus: [],
};

class BatchList extends React.PureComponent<BatchListProps & typeof defaultProps, any> {
    static defaultProps = defaultProps;

    getScenariosHTML = (scenarios: IScenario[]) => (
        <div className="batch-schedule__scenario-tooltip">
            {scenarios.map(scenario => (
                <span
                    className="batch-schedule__scenario-tooltip__scenario-name"
                    key={scenario.ukId}
                >
                    {scenario.name}
                </span>
            ))}
        </div>
    );

    getProgressStatusImage = (BatchStatus = null) => {
        if (BatchStatus === null) {
            return null;
        }
        return batchProgressImages[BatchStatus.progressStatus] || null;
    };

    getBatchRunStatus = (currentBatch: IBatch) => {
        const { dayName } = this.props;

        if (dayName === dayType.OTHERS) {
            return null;
        }

        if (dayName === dayType.TODAY) {
            const { currentBatchesStatus } = this.props;
            return this.getProgressStatusImage(
                currentBatchesStatus.find(
                    batch => batch.batchUkId === parseInt(currentBatch.ukId, 10),
                ),
            );
        }

        const { isFetchingPastBatchesProgress, pastBatchesStatusList } = this.props;

        if (pastBatchesStatusList.length === 0 && !isFetchingPastBatchesProgress) {
            return null;
        }

        return (
            <ReactPlaceholder
                key="placeholder"
                type="text"
                showLoadingAnimation
                ready={!isFetchingPastBatchesProgress}
                style={{ width: 60, opacity: 0.6 }}
                color="#b5b0b0"
                rows={1}
            >
                {this.getProgressStatusImage(
                    pastBatchesStatusList.find(
                        pastBatch => pastBatch.batchUkId === parseInt(currentBatch.ukId, 10),
                    ),
                )}
            </ReactPlaceholder>
        );
    };

    getBatchHeader = batchDate => batch => {
        const { asOfDayType } = this.props;
        let asOfParam = '';

        if (asOfDayType === dayType.YESTERDAY || asOfDayType === dayType.PAST) {
            asOfParam = `?asOf=${moment(batchDate).format('YYYY-MM-DD')} ${getConfig().asOfTime}`;
        }

        if (asOfDayType === dayType.TOMORROW || asOfDayType === dayType.FUTURE) {
            asOfParam = '?asOf=now';
        }

        if (asOfDayType === dayType.TODAY) {
            asOfParam = `?asOf=${moment(batchDate).format('YYYY-MM-DD')}`;
        }

        return (
            <React.Fragment>
                <Link
                    to={{
                        pathname: `/batches/${batch.ukId}`,
                        search: asOfParam,
                    }}
                    className="batch-schedule__batch__details-name"
                    title="View Batch Details"
                >
                    {batch.name}
                </Link>
                <div>{this.getBatchRunStatus(batch)}</div>
            </React.Fragment>
        );
    };

    getBatchContent = (batch: IBatch) => (
        <React.Fragment>
            <span className="batch-schedule__batch-details-col">
                {batch.cobDate ? `Past COB:${moment(batch.cobDate).format('DD MMMM YYYY')}` : ''}
            </span>
            <span className="batch-schedule__batch-details-col">{batch.pctNode || ''}</span>
            <span className="batch-schedule__batch-details-col" />
        </React.Fragment>
    );

    renderBatchList = (batchList, batchDate) => {
        const batchListLength = batchList.length;
        return (
            <List className="batch-schedule-batch__list">
                {batchListLength === 0 && (
                    <ListItem className="batch-schedule-batch__list-item" alignitems="flex-start">
                        0 schedules found
                    </ListItem>
                )}
                {batchListLength !== 0 &&
                    batchList.map(batch => (
                        <BatchListItem
                            batch={batch}
                            cssNs="batch-schedule"
                            islastItem={false}
                            batchHeader={this.getBatchHeader(batchDate)}
                            batchContent={this.getBatchContent}
                        />
                    ))}
            </List>
        );
    };

    render() {
        const { batchList, batchDate } = this.props;
        return this.renderBatchList(batchList, batchDate);
    }
}

export default BatchList;
