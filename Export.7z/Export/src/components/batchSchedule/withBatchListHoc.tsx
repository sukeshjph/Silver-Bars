import React, { FunctionComponent } from 'react';
import moment from 'moment';
import { dayType } from './batchScheduleConstants';
import { IBatchesStatus } from './batchSchedule.types';

type allBatchesStatusType = {
    subscriptionId: string;
    currentBatchesStatus: IBatchesStatus[];
    error: string;
};
type withHOCListProps = {
    isFetchingPastBatchesProgress: boolean;
    allbatchesStatus: allBatchesStatusType;
    pastBatchesProgress: IBatchesStatus[];
    batchDate: any;
};

const withBatchListHOC = ListComponent => {
    const enhancedListComponent: FunctionComponent<withHOCListProps> = ({
        isFetchingPastBatchesProgress,
        pastBatchesProgress: { pastDate, batches: pastBatchesStatusList },
        allbatchesStatus: { currentBatchesStatus },
        batchDate,
        ...others
    }) => {
        // Check whether date is yesterday
        if (moment(batchDate).date() - moment(pastDate).date() === 0) {
            return (
                <ListComponent
                    {...{
                        ...others,
                        isFetchingPastBatchesProgress,
                        pastBatchesStatusList,
                        dayName: dayType.YESTERDAY,
                        batchDate,
                    }}
                />
            );
        }
        // Check whether it's today
        if (moment(batchDate).date() - moment().date() === 0) {
            return (
                <ListComponent {...{ ...others, currentBatchesStatus, dayName: dayType.TODAY, batchDate }} />
            );
        }

        return <ListComponent {...{ ...others, dayName: dayType.OTHERS, batchDate }} />;
    };

    return enhancedListComponent;
};

export default withBatchListHOC;
