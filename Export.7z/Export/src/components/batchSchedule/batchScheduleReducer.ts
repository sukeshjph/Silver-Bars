import moment from 'moment';
import { createReducer, StateType } from 'typesafe-actions';
import { get } from '../../helpers/utilities';
import { BatchScheduleState, BatchScheduleActionsType } from './batchSchedule.types';
import * as ScheduleActions from './batchScheduleActions';

const initialState = {
    batchesByDate: {},
    allBatches: {},
    isFetchingBatchesByDate: false,
    errorBatchesByDate: '',
    isSubscibingTostatusEvents: false,
    isFetchingPastBatchesProgress: false,
    isFetchingTodayBatchesProgress: false,
    pastBatchesProgress: { pastDate: null, batches: [] },
    pastBatchesProgressError: '',
    allbatchesStatus: {
        subscriptionId: '',
        currentBatchesStatus: [],
        error: '',
    },
} as BatchScheduleState;

const updateStatusInCurrentBatches = (currentBatchesStatus, eventBatch) => {
    if (currentBatchesStatus.length === 0) {
        return [...currentBatchesStatus, eventBatch];
    }

    const existingBatchIndex = currentBatchesStatus.findIndex(
        ({ batchUkId }) => batchUkId === eventBatch.batchUkId,
    );
    return existingBatchIndex === -1
        ? [...currentBatchesStatus, eventBatch]
        : Object.assign([...currentBatchesStatus], { [existingBatchIndex]: eventBatch });
};

const getUpdatedCurrentBatchesStatus = (TodaysBatchesStatus, newTodaysBatchesStatusObj) => {
    if (Object.keys(newTodaysBatchesStatusObj).length === 0) {
        return TodaysBatchesStatus;
    }
    if (TodaysBatchesStatus.length === 0) {
        return [...TodaysBatchesStatus, ...Object.values(newTodaysBatchesStatusObj)];
    }
    return TodaysBatchesStatus.map(batch => {
        if (Object.keys(newTodaysBatchesStatusObj).includes(batch.batchUkId)) {
            return { ...newTodaysBatchesStatusObj[batch.batchUkId] };
        }

        return batch;
    });
};

const removeWeekendBatches = batchesByDate => {
    return Object.keys(batchesByDate).reduce((finalBatchesByDate, BatchDayKey) => {
        if (![0, 6].includes(moment(BatchDayKey).day())) {
            return {
                ...finalBatchesByDate,
                [BatchDayKey]: batchesByDate[BatchDayKey],
            };
        }
        return finalBatchesByDate;
    }, {});
};
// immutability is not required as it's readonly
export const assignBatchesByDate = (allBatches, batchesByDate) =>
    Object.keys(batchesByDate).reduce(
        (finalObj, curBatchDateKey) => ({
            ...finalObj,
            [curBatchDateKey]: batchesByDate[curBatchDateKey].map(
                batchUkIdKey => allBatches[batchUkIdKey],
            ),
        }),
        {},
    );

const fetchBatchesByDateReducers = createReducer<BatchScheduleState, BatchScheduleActionsType>(
    initialState as BatchScheduleState,
)
    .handleAction(ScheduleActions.fetchBatchesByDate, state => ({
        ...state,
        isFetchingBatchesByDate: true,
        errorBatchesByDate: '',
    }))
    .handleAction(ScheduleActions.fetchBatchesByDateComplete, (state, action) => ({
        ...state,
        isFetchingBatchesByDate: false,
        allBatches: action.payload.allBatches,
        batchesByDate: assignBatchesByDate(
            action.payload.allBatches,
            removeWeekendBatches(action.payload.batchesByDate),
        ),
        errorBatchesByDate: '',
    }))
    .handleAction(ScheduleActions.fetchBatchesByDateError, (state, action) => ({
        ...state,
        isFetchingBatchesByDate: false,
        errorBatchesByDate: action.payload.error,
    }));

const fetchBatchStatusReducers = createReducer<BatchScheduleState, BatchScheduleActionsType>(
    initialState as BatchScheduleState,
)
    .handleAction(ScheduleActions.fetchBatchStatus, state => ({
        ...state,
        isSubscibingTostatusEvents: true,
    }))
    .handleAction(ScheduleActions.fetchBatchStatusComplete, (state, action) => {
        const { eventType, eventData } = action.payload;
        return {
            ...state,
            isSubscibingTostatusEvents: false,
            allbatchesStatus: {
                ...state.allbatchesStatus,
                ...(eventType === 'Subscription-ACK'
                    ? { subscriptionId: get(eventData, 'subscriptionId', '') }
                    : {}),
                ...(eventType === 'BatchProgress'
                    ? {
                        currentBatchesStatus: updateStatusInCurrentBatches(
                            state.allbatchesStatus.currentBatchesStatus,
                            eventData,
                        ),
                    }
                    : {}),
            },
        };
    })
    .handleAction(ScheduleActions.fetchBatchStatusError, (state, action) => ({
        ...state,
        isSubscibingTostatusEvents: false,
        allbatchesStatus: {
            ...state.allbatchesStatus,
            error: action.payload.error,
        },
    }));

const requestBatchProgressForBatchesReducers = createReducer<
    BatchScheduleState,
    BatchScheduleActionsType
>(initialState as BatchScheduleState)
    .handleAction(ScheduleActions.requestBatchProgressForBatches, state => ({
        ...state,
        isFetchingTodayBatchesProgress: true,
    }))
    .handleAction(ScheduleActions.requestBatchProgressForBatchesComplete, (state, action) => {
        const { allbatchesStatus } = state;
        return {
            ...state,
            isFetchingTodayBatchesProgress: false,
            allbatchesStatus: {
                ...allbatchesStatus,
                currentBatchesStatus: getUpdatedCurrentBatchesStatus(
                    allbatchesStatus.currentBatchesStatus,
                    action.payload,
                ),
            },
        };
    })
    .handleAction(ScheduleActions.requestBatchProgressForBatchesError, (state, action) => ({
        ...state,
        isFetchingTodayBatchesProgress: false,
        allbatchesStatus: {
            ...state.allbatchesStatus,
            error: action.payload.error,
        },
    }));

const fetchPastBatchProgressStatusReducers = createReducer<
    BatchScheduleState,
    BatchScheduleActionsType
>(initialState as BatchScheduleState)
    .handleAction(ScheduleActions.fetchPastBatchProgressStatus, (state, action) => ({
        ...state,
        isFetchingPastBatchesProgress: true,
        pastBatchesProgress: {
            ...state.pastBatchesProgress,
            pastDate: action.payload.pastDate,
        },
    }))
    .handleAction(ScheduleActions.fetchPastBatchProgressStatusComplete, (state, action) => ({
        ...state,
        isFetchingPastBatchesProgress: false,
        pastBatchesProgress: {
            ...state.pastBatchesProgress,
            batches: action.payload.batchesWithStatus,
        },
    }))
    .handleAction(ScheduleActions.fetchPastBatchProgressStatusError, (state, action) => ({
        ...state,
        isFetchingPastBatchesProgress: false,
        pastBatchesProgressError: action.payload.error,
    }));

const ScheduleReducer = createReducer<BatchScheduleState, BatchScheduleActionsType>(
    initialState as BatchScheduleState,
    {
        ...fetchBatchesByDateReducers.handlers,
        ...fetchBatchStatusReducers.handlers,
        ...requestBatchProgressForBatchesReducers.handlers,
        ...fetchPastBatchProgressStatusReducers.handlers,
    },
);

export type ScheduleReducerType = StateType<typeof ScheduleReducer>;

export default ScheduleReducer;
