import { formatDateTime, formatDate } from '../../helpers/dateTime';
import BatchListItemCell from './batchListItemCell';
import { IColumnDef } from '../../interfaces/globals';

export default [
    {
        label: 'Batch Name',
        key: 'name',
    },
    {
        label: 'Added',
        key: 'addedScenarios',
        formatter: list => BatchListItemCell(list),
        className: 'td-break-word',
    },
    {
        label: 'Removed',
        key: 'removedScenarios',
        formatter: list => BatchListItemCell(list),
        className: 'td-break-word',
    },
    {
        label: 'Active Scenarios',
        key: 'activeScenarios',
        formatter: list => BatchListItemCell(list),
        className: 'td-break-word',
    },
    {
        label: 'CoB Date',
        key: 'cobDate',
        formatter: date => formatDate(date),
    },
    {
        label: 'Reason for change',
        key: 'comments',
    },
    {
        label: 'Updated',
        key: 'validFrom',
        className: 'td-no-wrap',
        formatter: date => formatDateTime(date),
        csvFormatter: date => `'${date}'`,
        sortable: true,
    },
    {
        label: 'Updated By',
        key: 'modifiedBy',
        sortable: true,
    },
] as IColumnDef[];
