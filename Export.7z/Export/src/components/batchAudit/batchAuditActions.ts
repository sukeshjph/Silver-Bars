import { createAction, createStandardAction } from 'typesafe-actions';
import { batchAuditActionTypes } from './batchAuditConstants';
import { API_DATE_TIME_FORMAT } from '../../constants';
import { IBatch } from '../../interfaces/globals';
import { ErrorType } from './batchAudit.types';

// batch Audit Actions
export const fetchBatchAudits = createAction(
    batchAuditActionTypes.FETCH_BATCH_AUDITS,
    action => (validFromDate: any, validToDate: any) =>
        action({
            validFromDate: validFromDate
                ? validFromDate.startOf('day').format(API_DATE_TIME_FORMAT)
                : null,
            validToDate: validToDate ? validToDate.endOf('day').format(API_DATE_TIME_FORMAT) : null,
        }),
);

export const fetchBatchAuditsComplete = createAction(
    batchAuditActionTypes.FETCH_BATCH_AUDITS_COMPLETE,
    action => (batchAudits: IBatch[]) => action({ batchAudits }),
);

export const fetchBatchAuditsError = createStandardAction(
    batchAuditActionTypes.FETCH_BATCH_AUDITS_ERROR,
)<ErrorType>();
