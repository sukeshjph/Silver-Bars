import { ActionType } from 'typesafe-actions';
import * as BatchAuditActions from './batchAuditActions';
import { IBatch } from '../../interfaces/globals';

// Action Types
export type ErrorType = {
    error: string;
};

export type BatchAuditActionsType = ActionType<typeof BatchAuditActions>;

// State Types
export interface IBatchAuditStateReducer {
    batchAudits: IBatch[];
    isFetchingBatchAudits: boolean;
    batchAuditsError: string;
}

// Component Types
export interface IBatchAuditCompProps {
    actions: {
        fetchBatchAudits(validFromDate: any, validToDate: any): void;
    };
    model: {
        batchAudits: IBatch[];
        isFetchingBatchAudits: boolean;
        batchAuditsError: string;
        isFetchingBatches: boolean;
        batchesError: string;
    };
}

export interface IBatchAuditCompState {
    order: 'desc' | 'asc';
    orderBy: string;
    batchAudits: IBatch[];
    filterText: string;
    filterBatchUkId: string;
}

