/* eslint-disable jsx-a11y/label-has-for,jsx-a11y/click-events-have-key-events,jsx-a11y/no-noninteractive-element-interactions */
import React, { PureComponent } from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { CSVLink } from 'react-csv';
import shortid from 'shortid';
import { RootState } from 'typesafe-actions';
import Tooltip from '@material-ui/core/Tooltip';
import Paper from '@material-ui/core/Paper';
import CloudDownloadIcon from '@material-ui/icons/CloudDownload';
import { createSelector } from 'reselect';
import { now } from '../../helpers/dateTime';
import generateCsvData from '../../helpers/generateCsvData';
import DataSetFilter from '../shared/dataSetFilter';
import { tableSorter } from '../../helpers/tableSorter';
import TableHeadWithSorting from '../shared/tableHeadWithSorting'; //eslint-disable-line
import * as BatchAuditActions from './batchAuditActions';
import batchAuditColumnDefs from './batchAuditColumnDefinitions';
import MainMenu from '../shared/mainMenu';
import ErrorMessage from '../shared/errorMessage';
import DefaultStressTableCell from '../shared/defaultStressTableCell';
import filterDataSet from '../../helpers/filterDataSet';
import DateRangePicker from '../shared/dateRangePicker';
import LoadingData from '../shared/loadingData';
import { IBatchAuditCompProps, IBatchAuditCompState } from './batchAudit.types';

const getBatchAuditState = createSelector(
    (state: RootState) => state.BATCH_AUDITS,
    batchAudit => ({
        model: batchAudit,
    }),
);

export class BatchAudit extends PureComponent<IBatchAuditCompProps, IBatchAuditCompState> {
    constructor(props) {
        super(props);
        this.tableSorter = tableSorter.bind(this);
        this.filterDataSet = filterDataSet;
        this.sortHandler = this.sortHandler.bind(this);
        this.handleFilterTextChange = this.handleFilterTextChange.bind(this);
    }

    state: Readonly<IBatchAuditCompState> = {
        order: 'desc',
        orderBy: 'updated',
        batchAudits: [],
        filterText: '',
        filterBatchUkId: '',
    };

    componentWillReceiveProps(nextProps) {
        const { batchAudits: batchAuditProps } = nextProps.model;
        const { filterText } = this.state;
        const {
            model: { batchAudits },
        } = this.props;

        if (batchAuditProps !== batchAudits) {
            this.setState({ batchAudits: this.filterDataSet(filterText, batchAuditProps) });
        }
    }

    tableSorter: typeof tableSorter;

    filterDataSet: typeof filterDataSet;

    /**
     * Change handler for the column headings
     * @param event
     * @param orderBy
     */
    sortHandler(event, orderBy) {
        const localState = { ...this.state };
        const sortResults = this.tableSorter(localState, orderBy, 'batchAudits');
        this.setState({
            batchAudits: sortResults.data,
            order: sortResults.order,
            orderBy: sortResults.orderBy,
        } as IBatchAuditCompState);
    }

    /**
     * Change handler for DataSetFilter component. Add search string to state
     * in case it needs to be reapplied automatically later.
     * @param filterText Search string entered by user
     * @param batchAudits Audits containing filterText
     */
    handleFilterTextChange(filterText, batchAudits) {
        this.setState({
            filterText,
            batchAudits,
        });
    }

    render() {
        const { model, actions } = this.props;
        const { order, orderBy, batchAudits, filterText } = this.state;
        return (
            <section id="stress-batch-audit" className="stress-ui-container">
                <header className="stress__header">
                    <div className="stress__header__title">
                        <h2 className="stress__header__title__main-text">Batch Audit</h2>
                    </div>
                    <DataSetFilter
                        actions={{
                            handleChange: this.handleFilterTextChange,
                        }}
                        model={{
                            value: filterText,
                            data: model.batchAudits,
                        }}
                    />
                    <DateRangePicker fetchByDateRange={actions.fetchBatchAudits} />
                    <Tooltip title="Download as CSV">
                        <CSVLink
                            filename={`Batch_Audit_${now()}.csv`}
                            data={generateCsvData(batchAudits, batchAuditColumnDefs)}
                            headers={batchAuditColumnDefs}
                        >
                            <button
                                className="stress__header__button stress__header__action-button"
                                type="button"
                            >
                                <CloudDownloadIcon />
                            </button>
                        </CSVLink>
                    </Tooltip>
                    <MainMenu />
                </header>

                <LoadingData
                    showLoading={model.isFetchingBatches || model.isFetchingBatchAudits}
                    render={() => <div className="stress-loading" />}
                />
                {(model.batchAuditsError || model.batchesError) && (
                    <ErrorMessage message="Sorry, an unexpected error has occurred. Batch audit data cannot be displayed." />
                )}

                {model.batchAudits.length > 0 && batchAudits.length === 0 && (
                    <ErrorMessage message="There are no batch audits matching your filters." />
                )}

                {batchAudits.length > 0 && (
                    <Paper className="stress-paper">
                        <table className="stress-table">
                            <TableHeadWithSorting
                                order={order}
                                orderBy={orderBy}
                                sortHandler={this.sortHandler}
                                columnDefs={batchAuditColumnDefs}
                            />
                            <tbody>
                                {batchAudits.map(audit => (
                                    <tr className="stress-table--row" key={shortid.generate()}>
                                        {batchAuditColumnDefs.map(column =>
                                            DefaultStressTableCell(column, audit),
                                        )}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </Paper>
                )}
            </section>
        );
    }
}

export const BatchAuditConnected = connect(
    (state: RootState) => getBatchAuditState(state),
    dispatch => ({ actions: bindActionCreators(BatchAuditActions, dispatch) }),
)(BatchAudit);
