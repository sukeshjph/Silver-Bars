import { createReducer, StateType } from 'typesafe-actions';
import orderBy from 'lodash.orderby';
import * as BatchAuditActions from './batchAuditActions';
import { IBatchAuditStateReducer, BatchAuditActionsType } from './batchAudit.types';

const initialState = {
    batchAudits: [],
    isFetchingBatchAudits: false,
    batchAuditsError: '',
} as IBatchAuditStateReducer;

const BatchAuditReducer = createReducer<IBatchAuditStateReducer, BatchAuditActionsType>(
    initialState,
)
    .handleAction(BatchAuditActions.fetchBatchAudits, state => ({
        ...state,
        isFetchingBatchAudits: true,
        batchAuditsError: '',
    }))
    .handleAction(BatchAuditActions.fetchBatchAuditsComplete, (state, action) => ({
        ...state,
        isFetchingBatchAudits: false,
        batchAudits: orderBy(action.payload.batchAudits, ['validFrom'], 'desc'),
    }))
    .handleAction(BatchAuditActions.fetchBatchAuditsError, (state, action) => ({
        ...state,
        isFetchingBatchAudits: false,
        batchAuditsError: action.payload.error,
    }));

export type BatchAuditReducerType = StateType<typeof BatchAuditReducer>;

export default BatchAuditReducer;
