export const SECONDARY_ROOTPATHS = [
    { value: 'stress', label: 'Stress Testing' },
    { value: 'stress/fdsf', label: 'FDSF' },
];
export const DATASET_ROOT = 'appsets/marketrisk/';

// Filter constants
export const ALLOWED_EXTENSIONS = ['.csv.gz'];
export const ALLOWED_REPORTS = ['crisisreports', 'sensitivities', 'stress'];

// MR Reports mapping constants
export const MAIN_REPORT_PATHS = {
    STRESS_PATH: 'appsets/marketrisk/stress',
    FDSF_PATH:'appsets/marketrisk/stress/fdsf',
};

export const ACTIVE_PIVOT_VARIABLES = {
    STRESS: ['global_stress', 'localised_stress'],
    SENSITIVITIES: [''],
};

export const OLD_DATA_PATHS = {
    STRESS: {
        'errors/localised': 'shockType=localised/shockName=All/reportName=error/',
        'fallback/localised': 'shockType=localised/shockName=All/reportName=fallback/',
        'localised-missingshocks': 'shockType=localised/reportName=missing_shocks/',
        localised_stress: 'shockType=localised/shockName=All/reportName=active_pivot/',
        localised: 'shockType=localised/reportName=trades/',
        'errors/global': 'shockType=global/shockName=All/reportName=error/',
        'fallback/global': 'shockType=global/shockName=All/reportName=fallback/',
        'global-missingshocks': 'shockType=global/reportName=missing_shocks/',
        'global/consolidated_desk': 'shockType=global/shockName=All/reportName=consolidated_desk/',
        global_stress: 'shockType=global/shockName=All/reportName=active_pivot/',
        global: 'shockType=global/reportName=trades/',
        'summary/sensitivity': 'shockType=*/shockName=All/reportName=sensitivities_summary/',
        'summary/batch': 'shockType=*/shockName=All/reportName=batch_summary/',
        'summary/performance': 'shockType=*/shockName=All/reportName=performance_summary/',
    },    
};

export const DEFAULT_SORT_COLUMNS = {
    cobDate: { sortOrder: 1, orderBy: 'desc' },
    shockType: { sortOrder: 2, orderBy: 'asc' },
    shockName: { sortOrder: 3, orderBy: 'asc' },
    reportName: { sortOrder: 4, orderBy: 'asc' },
};

// Riskview Table constants
export const ColumnTypes = {
    String: 'String',
    Date: 'Date',
    Long: 'Long',
    Integer: 'Integer',
    BigDecimal: 'BigDecimal',
};

// redux actions
export const downloadActionTypes = ({
    FETCH_FILE_LIST: 'STRESS/FETCH_FILE_LIST',
    FETCH_FILE_LIST_COMPLETE: 'STRESS/FETCH_FILE_LIST_COMPLETE',
    FETCH_FILE_LIST_ERROR: 'STRESS/FETCH_FILE_LIST_ERROR',
    FETCH_FILE_DETAILS: 'STRESS/FETCH_FILE_DETAILS',
    FETCH_FILE_DETAILS_COMPLETE: 'STRESS/FETCH_FILE_DETAILS_COMPLETE',
    FETCH_FILE_DETAILS_ERROR: 'STRESS/FETCH_FILE_DETAILS_ERROR',
    FETCH_FILE_DETAILS_RESET: 'STRESS/FETCH_FILE_DETAILS_RESET',
    FETCH_BLOB: 'STRESS/FETCH_BLOB',
    FETCH_BLOB_COMPLETE: 'STRESS/FETCH_BLOB_COMPLETE',
    FETCH_BLOB_ERROR: 'STRESS/FETCH_BLOB_ERROR',
    FETCH_BLOB_RESET: 'STRESS/FETCH_BLOB_RESET',
}) as const;

export const DATE_TIME_FORMAT = 'DD MMM YYYY HH:mm';
