import { createSelector } from 'reselect';

const getUser = state => state.USER;
export const getUserState = createSelector(
    [getUser],
    user => user,
);

const getReports = state => state.DOWNLOADS;
export const getReportState = createSelector(
    [getReports],
    report => report,
);
