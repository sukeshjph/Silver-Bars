import { createAction, createStandardAction } from 'typesafe-actions';
import { downloadActionTypes } from './downloadsConstants';
import { ErrorType, rootLink, fileListData } from './downloads.types';

// Downloads Actions
export const fetchFileList = createAction(
    downloadActionTypes.FETCH_FILE_LIST,
    action => (root: rootLink, regexFilter: string) =>
        action({
            root,
            regexFilter,
        }),
);

export const fetchFileListComplete = createAction(
    downloadActionTypes.FETCH_FILE_LIST_COMPLETE,
    action => (rootPath: string, label: string, data: fileListData[]) =>
        action({
            rootPath,
            label,
            dataSetList: data,
        }),
);

export const fetchFileListError = createStandardAction(downloadActionTypes.FETCH_FILE_LIST_ERROR)<
    ErrorType
>();

export const fetchFileDetails = createAction(
    downloadActionTypes.FETCH_FILE_DETAILS,
    action => (datasetId: string, orderBy: any, columnFilter: any) =>
        action({
            datasetId,
            orderBy,
            columnFilter,
        }),
);
export const fetchFileDetailsComplete = createStandardAction(
    downloadActionTypes.FETCH_FILE_DETAILS_COMPLETE,
).map((datasetId: string, files: any[]) => ({
    payload: {
        datasetId,
        files,
    },
}));

export const fetchFileDetailsReset = createStandardAction(
    downloadActionTypes.FETCH_FILE_DETAILS_RESET,
)<undefined>();

export const fetchFileDetailsError = createStandardAction(
    downloadActionTypes.FETCH_FILE_DETAILS_ERROR,
)<ErrorType>();

export const fetchBlobFile = createAction(
    downloadActionTypes.FETCH_BLOB,
    action => (datasetId: string, blobName: string) =>
        action({
            datasetId,
            blobName,
        }),
);

export const fetchBlobFileComplete = createAction(
    downloadActionTypes.FETCH_BLOB_COMPLETE,
    action => (datasetId: string, blobName: string, blob: any) =>
        action({
            datasetId,
            blobName,
            blob,
        }),
);

export const fetchBlobFileError = createStandardAction(downloadActionTypes.FETCH_BLOB_ERROR)<
    ErrorType
>();

export const fetchBlobReset = createStandardAction(downloadActionTypes.FETCH_BLOB_RESET)<
undefined
>();
