import React, { FunctionComponent, useState } from 'react';
import sortBy from 'lodash.orderby';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import shortid from 'shortid';
import Button from '@material-ui/core/Button';
import FileDownloadIcon from '@material-ui/icons/FileDownload';
import bytes from 'bytes';

interface IFile {
    name: string;
    sizeInBytes: string;
}

type DownloadBlobFilesProps = {
    tableRow: {
        files: IFile[];
        oldDataSetId: string;
    };
    handleBlobFileDownload: (dataSetId: string, fileName: string) => () => void;
};

const DownloadBlobFiles: FunctionComponent<DownloadBlobFilesProps> = React.memo(
    ({ tableRow: { files = [], oldDataSetId }, handleBlobFileDownload }) => {
        const OrderValues = {
            asc: 'asc',
            desc: 'desc',
        } as const;

        const [order, setOrder] = useState(OrderValues.asc);
        const [orderBy, setOrderBy] = useState('name');

        const createSortHandler = (property: string) => () => {
            const isDesc = orderBy === property && order === OrderValues.desc;
            setOrder(isDesc ? OrderValues.asc : OrderValues.desc);
            setOrderBy(property);
        };

        const getSortedRows = (filesToSort: IFile[]) => sortBy(filesToSort, [orderBy], order);

        return (
            <Table className="stress-reports-file-container">
                <TableHead>
                    <TableRow className="stress-reports-file--header">
                        <TableCell className="stress-reports-file--fileCol">
                            <TableSortLabel
                                active={orderBy === 'name'}
                                direction={order}
                                onClick={createSortHandler('name')}
                            >
                                Name
                            </TableSortLabel>
                        </TableCell>
                        <TableCell numeric>
                            <TableSortLabel
                                active={orderBy === 'sizeInBytes'}
                                direction={order}
                                onClick={createSortHandler('sizeInBytes')}
                            >
                                Size
                            </TableSortLabel>{' '}
                        </TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {getSortedRows(files).map(file => (
                        <TableRow key={shortid.generate()}>
                            <TableCell className="stress-reports-file--fileCol">
                                <Button
                                    size="small"
                                    onClick={handleBlobFileDownload(oldDataSetId, file.name)}
                                    className="stress-reports-file--name"
                                >
                                    <FileDownloadIcon className="fileIcon" />
                                    <span className="fileName">{file.name}</span>
                                </Button>
                            </TableCell>
                            <TableCell>
                                {bytes(parseInt(file.sizeInBytes, 10), {
                                    unitSeparator: ' ',
                                })}
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        );
    },
);

export default DownloadBlobFiles;
