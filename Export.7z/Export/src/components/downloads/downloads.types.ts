import { ActionType } from 'typesafe-actions';
import * as DownloadsActions from './downloadsActions';
// component Types
export type rootLink = {
    path: string;
    label: string;
};

export interface IDownloadsState {
    asOfDate: any;
    currentRootLink: rootLink;
    currentActiveLink: string;
    regexFilter: string;
    dataSetView: any;
}

type actionsType = {
    signOut(): void;
    fetchFileList(currentRootLink: rootLink, regexFilter: string): void;
    fetchBlobFile(datasetId: string, fileName: string): void;
    fetchFileDetails(oldDataSetId: string, orderBy: any, columnFilter: any): void;
    fetchBlobReset(): void;
    fetchFileDetailsReset(): void;
};

interface dataColumn {
    columnName: string;
    displayName: string;
    allowFilter: boolean;
    allowSorting: boolean;
    className: string;
    type: string;
}

interface DsView {
    columns: dataColumn[];
    rows: any[];
    viewname: string;
    csvFileName: string;
}

interface IReport {
    dataSetView: DsView;
    currentDataSetIdWithFileRequest: string;
    filesInProgress: any[];
    currentRvOrderBy: any;
    currentRvFilter: any[];
    isFetchingDataSetList: boolean;
    isFetchingFiles: boolean;
    isDownloadingFile: boolean;
    error: string;
}

export interface IDownloadsProps {
    actions: actionsType;
    reports: IReport;
}

// Actions type
export type ErrorType = {
    error: string;
};

export interface fileListData {
    dataSetId: string;
    modificationTime: string;
}

export type DownloadsActionsType = ActionType<typeof DownloadsActions>;

// Reducer Types

export interface IDownlaodsReducer {
    dataSetView: DsView;
    currentDataSetIdWithFileRequest: string;
    currentRvOrderBy: any;
    currentRvFilter: any[];
    filesInProgress: any[];
    isFetchingDataSetList: boolean;
    isFetchingFiles: boolean;
    isDownloadingFile: boolean;
    error: string;
}

export interface fileDataListPayload {
    rootPath: string;
    label: string;
    dataSetList: fileListData[];
}
