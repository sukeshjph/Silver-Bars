import fileDownload from 'js-file-download';
import { createReducer, StateType } from 'typesafe-actions';
import moment from 'moment';
import _ from 'lodash';
import { IDownlaodsReducer, DownloadsActionsType, fileDataListPayload } from './downloads.types';
import * as DownloadsActions from './downloadsActions';
import {
    downloadActionTypes,
    ALLOWED_EXTENSIONS,
    ColumnTypes,
    DATE_TIME_FORMAT,
    MAIN_REPORT_PATHS,
    OLD_DATA_PATHS,
    DEFAULT_SORT_COLUMNS,
} from './downloadsConstants';
import getFilesFilteredByExtensions from './getFilesFilteredByExtensions';
import { getformattedColumnfromCamel, pipe } from '../../helpers/utilities';

const initialState = {
    dataSetView: {
        columns: [],
        rows: [],
        viewname: '',
        csvFileName: '',
    },
    currentDataSetIdWithFileRequest: '',
    currentRvOrderBy: {},
    currentRvFilter: [],
    filesInProgress: [],
    isFetchingDataSetList: false,
    isFetchingFiles: false,
    isDownloadingFile: false,
    error: '',
};

export const getUpdatedFilesInProgress = (file, filesInProgress) => {
    const { datasetId, blobName } = file;
    const foundIndex = filesInProgress.findIndex(
        f => f.datasetId === datasetId && f.blobName === blobName,
    );

    if (foundIndex !== -1) {
        return [...filesInProgress.slice(0, foundIndex), ...filesInProgress.slice(foundIndex + 1)];
    }
    return filesInProgress;
};

export const getColumnType = columnName => {
    if (columnName === 'version') return ColumnTypes.Integer;
    if (columnName.endsWith('Date') || columnName.includes('Date')) return ColumnTypes.Date;
    return ColumnTypes.String;
};

export const noOfColumnValuePair = (rootPath, dsId) =>
    dsId
        .slice(rootPath.length + 1)
        .split('/')
        .filter(val => val.indexOf('=') !== -1)
        .reduce((acc, curr) => {
            if (curr.indexOf('=')) return acc + 1;
            return acc;
        }, 0);

export const getDefaultSortedColumns = columns => {
    const sortKeys = Object.keys(DEFAULT_SORT_COLUMNS);
    return columns.map(col => {
        if (sortKeys.includes(col.columnName)) {
            const { sortOrder, orderBy } = DEFAULT_SORT_COLUMNS[col.columnName];
            return {
                ...col,
                orderBy,
                sortOrder,
            };
        }
        return col;
    });
};

export const generateColumnsFromKeyValueIdPairs = (columnRowArray: string[]) =>
    columnRowArray
        .filter(keyVal => keyVal.indexOf('=') !== -1)
        .map(keyVal => {
            const columnName = keyVal.substring(0, keyVal.indexOf('='));
            return {
                columnName,
                displayName: getformattedColumnfromCamel(columnName),
                allowFilter: true,
                allowSorting: true,
                className: 'reports__column',
                type: getColumnType(columnName),
            };
        });

export const removeEmptyDelimiter = (id, delimiter = '/') =>
    id
        .split(delimiter)
        .filter(x => x)
        .join(delimiter);

// strip version from dsId
export const getDsIdWithoutVersion = (dsId, withRemove = false) => {
    const dsIdWithoutVersion = dsId.replace(/version[=][0-9]/g, '');
    return !withRemove ? dsIdWithoutVersion : () => removeEmptyDelimiter(dsIdWithoutVersion);
};

// stripe the version and date out to make slicing easier
export const getDsIdWithoutVersionDate = (dsId, rootPath) => {
    const dateRegex = /date[=]\d{4}-\d{2}-\d{2}/g;
    return pipe([getDsIdWithoutVersion, Id => Id.replace(dateRegex, ''), removeEmptyDelimiter])(
        dsId.slice(rootPath.length + 1),
    );
};

export const getDsColumn = props => {
    const defaultCol = {
        columnName: '',
        displayName: '',
        allowFilter: false,
        allowSorting: false,
        className: 'reports__column',
        type: 'String',
    };

    return {
        ...defaultCol,
        ...props,
    };
};

export const rePositionCobDateBatchDateColumn = doesItHaveBatchDate => columnArray => {
    let colArrWithFilesDate = [...columnArray, getDsColumn({ columnName: 'files' })];
    if (doesItHaveBatchDate) {
        colArrWithFilesDate =
            colArrWithFilesDate.findIndex(col => col.columnName === 'batchDate') === -1
                ? [
                    ...colArrWithFilesDate,
                    getDsColumn({
                        columnName: 'batchDate',
                        displayName: 'Batch Date',
                        type: 'Date',
                    }),
                ]
                : colArrWithFilesDate;
    }

    const [dateColArray, nonDateColArray] = colArrWithFilesDate.reduce(
        (finalArr, col) => {
            if (['cobDate', 'batchDate'].includes(col.columnName)) finalArr[0].push(col);
            else finalArr[1].push(col);
            return finalArr;
        },

        [[], []],
    );

    return dateColArray.length === 0
        ? colArrWithFilesDate
        : [
            ..._.orderBy(dateColArray, 'columnName', 'desc').map(col => {
                if (col.columnName === 'cobDate')
                    return {
                        ...col,
                        displayName: 'CoB Date',
                    };
                return col;
            }),
            ...nonDateColArray,
        ];
};

export const getViewColumns = ({ primaryRootPath, IdLists, isOldOnly }) => {
    const doesItHaveBatchDate = IdLists.some(ds => ds.newDsId.includes('batchDate'));
    // Pick the row with max no of columns
    const validColumnRow = IdLists.reduce((acc, currentDs) =>
        noOfColumnValuePair(primaryRootPath, acc.newDsId) >
        noOfColumnValuePair(primaryRootPath, currentDs.newDsId)
            ? acc
            : currentDs,
    );

    const validColumnRowArray = !isOldOnly
        ? getDsIdWithoutVersion(
            validColumnRow.newDsId.slice(primaryRootPath.length + 1),
            true,
        )().split('/')
        : getDsIdWithoutVersion(validColumnRow.newDsId, true)().split('/');

    // Using function pipe..applied from left to right
    return pipe([
        generateColumnsFromKeyValueIdPairs,
        rePositionCobDateBatchDateColumn(doesItHaveBatchDate),
        getDefaultSortedColumns,
    ])(validColumnRowArray);
};

export const getDsIdWithCobDate = dsId =>
    pipe([
        datasetId =>
            datasetId
                .replace(/date[=]/g, 'cobDate=')
                .replace(/runDate[=]/g, 'batchDate=')
                .replace(/asOfDate[=]/g, 'cobDate='),
        removeEmptyDelimiter,
    ])(dsId);

// Extrack Shockname for the old dataset ids
export const getDsIdWithShockName = (newDs, oldDs, rootpath) => {
    const newDsIdWithoutRootPath = newDs.newDsId.slice(rootpath.length + 1);
    if (newDsIdWithoutRootPath.indexOf('shockName=') === -1) {
        const shockName = oldDs.newDsId.slice(rootpath.length + 1).split('/')[1];
        return {
            ...newDs,
            newDsId: pipe([
                (dsId, delimiter = '/') =>
                    dsId
                        .split('/')
                        .filter(item => item.indexOf('=') !== -1)
                        .join(delimiter),
                removeEmptyDelimiter,
            ])(`${newDsIdWithoutRootPath}/shockName=${shockName}`),
        };
    }

    return {
        ...newDs,
        newDsId: newDsIdWithoutRootPath,
    };
};

// regex substitution for old datasetids to convert to new format
export const getMappedDsId = (ds, mapKeyObj) => {
    const foundRegexMatchIndex = Object.keys(mapKeyObj).findIndex(curPathKey =>
        ds.newDsId.match(new RegExp(curPathKey)),
    );
    const newUpdatedDs =
        foundRegexMatchIndex !== -1
            ? {
                ...ds,
                newDsId: pipe([
                    newId =>
                        newId.replace(
                            new RegExp(Object.keys(mapKeyObj)[foundRegexMatchIndex]),
                            mapKeyObj[Object.keys(mapKeyObj)[foundRegexMatchIndex]],
                        ),
                    getDsIdWithCobDate,
                ])(ds.newDsId),
            }
            : ds;

    return getDsIdWithShockName(newUpdatedDs, ds, MAIN_REPORT_PATHS.STRESS_PATH);
};

// Main method that transforms the older datasetlist to new one
export const getTransformedOldDataList = (oldDatasetList, rootPath) => {
    if (rootPath === MAIN_REPORT_PATHS.STRESS_PATH)
        return [...oldDatasetList.map(ds => getMappedDsId(ds, OLD_DATA_PATHS.STRESS))];
    return [...oldDatasetList];
};

export const getEmptyDsView = (viewname: string) => ({
    columns: [],
    rows: [],
    viewname,
    csvFileName: '',
});

export const getDatasetsWithoutFDSF = (dataSetListToBeScanned, primaryRootPath) =>
    primaryRootPath === MAIN_REPORT_PATHS.STRESS_PATH
        ? dataSetListToBeScanned.filter(ds => !ds.dataSetId.startsWith(MAIN_REPORT_PATHS.FDSF_PATH))
        : dataSetListToBeScanned;

/**
 *
 * @param {*} dsPayload
 * This transforms data into a consumable form to be used by RiskviewTable
 */

export const getDataSetView = (dsPayload: fileDataListPayload) => {
    const {
        rootPath: primaryRootPath,
        label: viewname,
        dataSetList: dataSetListToBeScanned,
    } = dsPayload;

    /**
     * Create list with only datasetids
     * OldDsId : This is kept for making further fetch file queries, this is same as newDsId for newer ones
     * newDsId: This is a transformed DsId UI side by applying regex replacements(not to be used for database queries)
     */
    const dataSetIdListsToBeScanned = getDatasetsWithoutFDSF(
        dataSetListToBeScanned,
        primaryRootPath,
    ).map(ds => ({
        oldDsId: ds.dataSetId,
        newDsId: ds.dataSetId,
    }));

    if (dataSetIdListsToBeScanned.length === 0) {
        return getEmptyDsView(viewname);
    }

    // Partion data to new or old format lists respectively
    const [oldDataSetIdLists, newDataSetIdLists] = dataSetIdListsToBeScanned.reduce(
        (finalArr, ds) => {
            if (getDsIdWithoutVersionDate(ds.newDsId, primaryRootPath).indexOf('=') === -1)
                finalArr[0].push(ds);
            else
                finalArr[1].push({
                    ...ds,
                    newDsId: getDsIdWithCobDate(ds.newDsId),
                });
            return finalArr;
        },

        [[] as typeof dataSetIdListsToBeScanned, [] as typeof dataSetIdListsToBeScanned],
    );

    const transformedOldDsList = getTransformedOldDataList(oldDataSetIdLists, primaryRootPath);

    return {
        columns: getViewColumns({
            primaryRootPath,
            IdLists: newDataSetIdLists.length !== 0 ? newDataSetIdLists : transformedOldDsList,
            isOldOnly: newDataSetIdLists.length === 0,
        }), // build columns
        rows: [
            ...(newDataSetIdLists.length !== 0
                ? newDataSetIdLists.map(ds =>
                    ds.newDsId
                        .slice(primaryRootPath.length + 1)
                        .split('/')
                        .reduce(
                            (acc, keyVal) => ({
                                ...acc,
                                [keyVal.slice(0, keyVal.indexOf('='))]: keyVal.slice(
                                    keyVal.indexOf('=') + 1,
                                ),
                            }),
                            {
                                files: null,
                                oldDataSetId: ds.oldDsId,
                                newDataSetId: ds.newDsId,
                                className: 'reports__row',
                            },
                        ),
                )
                : []),
            ...(transformedOldDsList.length !== 0
                ? transformedOldDsList.map(ds =>
                    ds.newDsId
                        .split('/')
                        .filter(x => x)
                        .reduce(
                            (acc, keyVal) => ({
                                ...acc,
                                [keyVal.slice(0, keyVal.indexOf('='))]: keyVal.slice(
                                    keyVal.indexOf('=') + 1,
                                ),
                            }),
                            {
                                files: null,
                                oldDataSetId: ds.oldDsId,
                                newDataSetId: ds.newDsId,
                                className: '',
                            },
                        ),
                )
                : []),
        ].filter(row => {
            if (!row.shockName) return true;
            return row.shockName.toLowerCase() !== 'all';
        }),
        viewname,
        csvFileName: `${viewname.replace(' ', '_')}_${moment().format(DATE_TIME_FORMAT)}.csv`,
    };
};

export const getDataSetViewWithoutFiles = dataSetView => ({
    ...dataSetView,
    rows: dataSetView.rows
        .filter(row => !row.columns)
        .map(row => {
            if (row.isParentNode) {
                const { isParentNode, ...newRow } = row;
                return newRow;
            }
            return row;
        }),
});

export const getDatasetViewWithLoadingFiles = (dataSetView, datasetId) => {
    const { rows, columns } = getDataSetViewWithoutFiles(dataSetView);
    const foundFileRowIndex = rows.findIndex(row => row.oldDataSetId === datasetId);
    const filesRow = {
        ...rows[foundFileRowIndex],
        files: [],
        columns: [
            {
                columnName: 'files',
                displayName: 'Files',
                allowFilter: false,
                allowSorting: false,
                className: 'reports-file__column reports__column',
                colSpan: columns.length,
                type: 'String',
            },
        ],
        className: 'reports-file-row',
        isChildNode: true,
    };

    return {
        ...dataSetView,
        rows: [
            ...rows.slice(0, foundFileRowIndex),
            {
                ...rows[foundFileRowIndex],
                isParentNode: true,
            },
            filesRow,
            ...rows.slice(foundFileRowIndex + 1),
        ],
    };
};

export const getUpdateDatasetViewWithFiles = (dataSetView, { datasetId, files }) => {
    const { rows } = dataSetView;
    const foundFileRowIndex = rows.findIndex(row => row.oldDataSetId === datasetId && row.columns);
    return {
        ...dataSetView,
        rows: [
            ...rows.slice(0, foundFileRowIndex),
            {
                ...rows[foundFileRowIndex],
                files: getFilesFilteredByExtensions(files, ALLOWED_EXTENSIONS, 'name'),
            },
            ...rows.slice(foundFileRowIndex + 1),
        ],
    };
};

const DownloadsReducer = createReducer<IDownlaodsReducer, DownloadsActionsType>(
    initialState as IDownlaodsReducer,
)
    .handleAction(
        [DownloadsActions.fetchFileList, DownloadsActions.fetchFileListComplete],
        (state, action) =>
            action.type === downloadActionTypes.FETCH_FILE_LIST
                ? {
                    ...state,
                    isFetchingDataSetList: true,
                    currentRvOrderBy: {},
                    currentRvFilter: [],
                    currentDataSetIdWithFileRequest: '',
                }
                : {
                    ...state,
                    dataSetView: getDataSetView(action.payload),
                    isFetchingDataSetList: false,
                },
    )
    .handleAction(DownloadsActions.fetchFileListError, (state, action) => ({
        ...state,
        isFetchingDataSetList: false,
        error: action.payload.error,
    }))
    .handleAction(DownloadsActions.fetchFileDetails, (state, action) => {
        const { datasetId, orderBy, columnFilter } = action.payload;
        return {
            ...state,
            dataSetView: getDatasetViewWithLoadingFiles(
                state.dataSetView,
                decodeURIComponent(datasetId),
            ),
            currentDataSetIdWithFileRequest: decodeURIComponent(datasetId),
            currentRvOrderBy: orderBy,
            currentRvFilter: columnFilter,
            isFetchingFiles: true,
        };
    })
    .handleAction(DownloadsActions.fetchFileDetailsComplete, (state, action) => {
        const { datasetId, files } = action.payload;
        return {
            ...state,
            dataSetView: getUpdateDatasetViewWithFiles(state.dataSetView, { datasetId, files }),
            isFetchingFiles: false,
        };
    })
    .handleAction(
        [DownloadsActions.fetchBlobFile, DownloadsActions.fetchBlobFileError],
        (state, action) =>
            action.type === downloadActionTypes.FETCH_BLOB
                ? {
                    ...state,
                    isDownloadingFile: true,
                    filesInProgress: [
                        ...state.filesInProgress,
                        {
                            datasetId: decodeURIComponent(action.payload.datasetId),
                            blobName: action.payload.blobName,
                        },
                    ],
                }
                : {
                    ...state,
                    isDownloadingFile: false,
                    error: action.payload.error,
                },
    )
    .handleAction(DownloadsActions.fetchBlobFileComplete, (state, action) => {
        const { blob, blobName, datasetId } = action.payload;
        fileDownload(blob, blobName);
        return {
            ...state,
            isDownloadingFile: false,
            filesInProgress: getUpdatedFilesInProgress(
                {
                    datasetId: decodeURIComponent(datasetId),
                    blobName,
                },
                state.filesInProgress,
            ),
        };
    })
    .handleAction(DownloadsActions.fetchFileDetailsReset, state => ({
        ...state,
        dataSetView: getDataSetViewWithoutFiles(state.dataSetView),
        currentDataSetIdWithFileRequest: '',
    }))
    .handleAction(DownloadsActions.fetchFileDetailsError, (state, action) => ({
        ...state,
        isFetchingFiles: false,
        currentDataSetIdWithFileRequest: '',
        error: action.payload.error,
    }))
    .handleAction(DownloadsActions.fetchBlobReset, (state: IDownlaodsReducer) => ({
        ...state,
        filesInProgress: [],
    }));

export type DownloadsReducerType = StateType<typeof DownloadsReducer>;

export default DownloadsReducer;
