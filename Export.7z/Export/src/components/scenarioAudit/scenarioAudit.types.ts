import { ActionType } from 'typesafe-actions';
import * as ScenarioAuditActions from './scenarioAuditActions';
import { IScenario } from '../../interfaces/globals';

export type ScenarioAuditActionsType = ActionType<typeof ScenarioAuditActions>;

// Reducer types
export interface IScenarioAuditReducerState {
    scenarioAudits: IScenario[];
    isFetchingScenarioAudits: boolean;
    scenarioAuditsError: string;
}

// Component types
export interface IScenarioAuditMainProps {
    model: {
        scenarioAudits: IScenario[];
        isFetchingScenarioAudits: boolean;
        scenarioAuditsError: string;
    };
    actions: {
        fetchScenarioAudits: (validFromDate: any, validToDate: any) => void;
    };
}

export interface IScenarioAuditCompState {
    order: 'desc' | 'asc';
    orderBy: string;
    scenarioAudits: IScenario[];
    filterText: string;
}
