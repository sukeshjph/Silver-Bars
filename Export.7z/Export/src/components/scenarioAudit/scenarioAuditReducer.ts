import { createReducer, StateType } from 'typesafe-actions';
import orderBy from 'lodash.orderby';
import * as ScenarioAuditActions from './scenarioAuditActions';
import { IScenarioAuditReducerState, ScenarioAuditActionsType } from './scenarioAudit.types';

const initialState = {
    scenarioAudits: [],
    isFetchingScenarioAudits: false,
    scenarioAuditsError: '',
} as IScenarioAuditReducerState;

const ScenarioAuditReducer = createReducer<IScenarioAuditReducerState, ScenarioAuditActionsType>(
    initialState,
)
    .handleAction(ScenarioAuditActions.fetchScenarioAudits, state => ({
        ...state,
        isFetchingScenarioAudits: true,
        scenarioAuditsError: '',
    }))
    .handleAction(ScenarioAuditActions.fetchScenarioAuditsComplete, (state, action) => ({
        ...state,
        isFetchingScenarioAudits: false,
        scenarioAudits: orderBy(action.payload.scenarioAudits, ['validFrom'], 'desc'),
    }))
    .handleAction(ScenarioAuditActions.fetchScenarioAuditsError, (state, action) => ({
        ...state,
        isFetchingScenarioAudits: false,
        scenarioAuditsError: action.payload.error,
    }));

export type ScenarioAuditReducerType = StateType<typeof ScenarioAuditReducer>;

export default ScenarioAuditReducer;
