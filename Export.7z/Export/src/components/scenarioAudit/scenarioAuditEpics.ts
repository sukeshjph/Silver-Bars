import { of } from 'rxjs';
import { mergeMap, catchError, map, filter } from 'rxjs/operators';
import { isActionOf } from 'typesafe-actions';
import { combineEpics, Epic } from 'redux-observable';
import { ScenarioAuditActionsType } from './scenarioAudit.types';
import * as ScenarioAuditActions from './scenarioAuditActions';
import { getConfig } from '../../common/config';
import http from '../../helpers/http';
import { dateRangeQueryStringGenerator } from '../shared/dateRangePicker';

const fetchScenarioAudits: Epic<ScenarioAuditActionsType> = action$ =>
    action$.pipe(
        filter(isActionOf(ScenarioAuditActions.fetchScenarioAudits)),
        mergeMap(action =>
            http
                .getData(
                    `${
                        getConfig().SdxService
                    }/batchmanagement/Scenario${dateRangeQueryStringGenerator(action.payload)}`,
                )
                .pipe(
                    map(scenarioAudits =>
                        ScenarioAuditActions.fetchScenarioAuditsComplete(scenarioAudits),
                    ),
                    catchError(() =>
                        of(
                            ScenarioAuditActions.fetchScenarioAuditsError({
                                error:
                                    'Sorry, an error has occurred whilst fetching scenario audit data',
                            }),
                        ),
                    ),
                ),
        ),
    );

export default combineEpics(fetchScenarioAudits);
