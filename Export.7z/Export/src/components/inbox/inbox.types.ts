import { ActionType } from 'typesafe-actions';
import { Assign, Optional } from 'utility-types';
import { IBatch, IScenario } from '../../interfaces/globals';
import * as InboxActions from './inboxActions';

export type InBoxScenario = Assign<IScenario, { currentActiveFileVersion: number }>;

// Component Types
type batchModel = {
    batches: IBatch[];
};
interface inBoxModel {
    inbox: InBoxScenario[];
    inboxError: string;
    isSaving: boolean;
    hasInboxSaved: boolean;
    isFetchingInbox: boolean;
    saveError: string;
}

type diffModel = {
    fetchDiffError: string;
    diff: any | {};
    isFetchingDiff: boolean;
};

type user = {
    userName: string;
};

type actions = {
    fetchDiff: () => void;
    fetchBatches: () => void;
    fetchInbox(): void;
    approveScenario(scenario: InBoxScenario, comments: any, committee: any): void;
    declineScenario(scenario: InBoxScenario, comments: any, committee: any): void;
    downloadScenarioFile: (
        Inbox: Pick<InBoxScenario, 'ukId' | 'name' | 'validFrom' | 'pending'> & {
            version: number;
        },
        versionKey: 'currentActiveFileVersion' | 'activeFileVersion',
    ) => void;
};
export interface IInboxProps {
    batchModel: batchModel;
    inboxModel: inBoxModel;
    diffModel: diffModel;
    user: user;
    actions: actions;
}

export interface IInboxState {
    openCompareDialog: boolean;
    selectedScenario: Optional<InBoxScenario>;
    userAction: 'approve' | 'decline' | '';
    openFormDialog: boolean;
    inbox: InBoxScenario[];
    user: any;
    userIsSuperUser?: boolean;
    userCanEdit?: boolean;
}

export type IInboxFormHandlerTypes = {
    fileAction: 'CREATE' | 'UPDATE' | 'SWITCH' | 'DELETE';
    userAction: 'approve' | 'decline';
    open: boolean;
    affectedBatches: string;
    cancelHandler(fetch?: boolean): void;
    saveHandler(comments: any, committee: any): void;
};

export type IInboxFormHandlerState = {
    reasonForChange: string;
    approvalCommittee: string;
    valid: boolean;
    reasonForChangeTouched?: boolean;
    saveError: string;
};

export type IInboxFormStateProps = IInboxFormHandlerTypes &
    IInboxFormHandlerState &
    Pick<inBoxModel, 'isSaving' | 'saveError' | 'hasInboxSaved'>;

// Action types
export interface IInboxResponse {
    inbox: InBoxScenario[];
    scenarios: InBoxScenario[];
}

export type ErrorType = {
    error: string;
};

export type InBoxBlobFile = { fileName: string; blob: any };
export type InboxActionsType = ActionType<typeof InboxActions>;

// Reducer types

export type IInboxReducerState = Pick<
    inBoxModel,
    'inbox' | 'isSaving' | 'isFetchingInbox' | 'hasInboxSaved'
>;
