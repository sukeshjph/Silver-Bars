import { formatDateTime } from '../../helpers/dateTime';

export default [
    {
        label: 'ID',
        key: 'ukId',
    },
    {
        label: 'Scenario Name',
        key: 'name',
    },
    {
        label: 'Action',
        key: 'action',
    },
    {
        label: 'Category',
        key: 'category',
    },
    {
        label: 'Proposed Version',
        key: 'activeFileVersion',
    },
    {
        label: 'Active Version',
        key: 'currentActiveFileVersion',
    },
    {
        label: 'Updated',
        key: 'validFrom',
        className: 'td-no-wrap',
        formatter: (date) => formatDateTime(date),
        csvFormatter: (date) => `'${date}'`,
        sortable: true,
    },
    {
        label: 'Updated By',
        key: 'modifiedBy',
        sortable: true,
    },
    {
        label: 'Reason for change',
        key: 'comments',
    },
];