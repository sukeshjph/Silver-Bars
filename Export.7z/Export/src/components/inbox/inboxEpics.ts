import { of, forkJoin } from 'rxjs';
import { mergeMap, catchError, map, filter } from 'rxjs/operators';
import moment from 'moment';
import { isActionOf } from 'typesafe-actions';
import { combineEpics, Epic } from 'redux-observable';
import * as InboxActions from './inboxActions';
import { InboxActionsType, InBoxBlobFile } from './inbox.types';
import { getConfig } from '../../common/config';
import http from '../../helpers/http';
import { VersionTypes } from './inboxConstants';

const fetchInbox: Epic<InboxActionsType> = action$ =>
    action$.pipe(
        filter(isActionOf(InboxActions.fetchInbox)),
        mergeMap(() =>
            forkJoin(
                http.getData(`${getConfig().SdxService}/batchmanagement/Scenario?status=pending`),
                http.getData(`${getConfig().SdxService}/batchmanagement/Scenario`),
            ).pipe(
                map(data =>
                    InboxActions.fetchInboxComplete({
                        inbox: data[0],
                        scenarios: data[1],
                    }),
                ),
                catchError(() =>
                    of(
                        InboxActions.fetchInboxError({
                            error: 'Sorry, an error has occurred whilst fetching inbox data',
                        }),
                    ),
                ),
            ),
        ),
    );

const fetchScenarioFile = ({ scenarioVersion, versionType }) => {
    const { ukId, name, version } = scenarioVersion;

    const downloadUrl = `${
        getConfig().SdxService
    }/batchmanagement/Scenario/data/fileStream?ukId=${ukId}&activeFileVersion=${version}${
        versionType === VersionTypes.CurrentVersion
            ? `&status=approved&asOf=${encodeURI(moment.utc().format('YYYY-MM-DD HH:mm:ss.SSS'))}`
            : `&status=pending&asOf=${encodeURI(moment.utc().format('YYYY-MM-DD HH:mm:ss.SSS'))}`
    }`;
    return http.getFile(downloadUrl).pipe(
        map(blob => ({
            fileName: `${name}-v${version}_${ukId}.csv`,
            blob,
        })),
        catchError(error => of(InboxActions.downloadScenarioFileError({ error }))),
    );
};

const downloadScenarioFileVersion: Epic<InboxActionsType> = action$ =>
    action$.pipe(
        filter(isActionOf(InboxActions.downloadScenarioFile)),
        mergeMap(action => fetchScenarioFile(action.payload)),
        map(blobObject => InboxActions.downloadScenarioFileComplete(blobObject as InBoxBlobFile)),
    );

const approveScenario: Epic<InboxActionsType> = action$ =>
    action$.pipe(
        filter(isActionOf(InboxActions.approveScenario)),
        mergeMap(action =>
            http
                .postFormData(
                    `${getConfig().SdxService}/batchmanagement/Scenario/approve`,
                    action.payload,
                )
                .pipe(
                    map(() => InboxActions.approveScenarioComplete()),
                    catchError(() =>
                        of(
                            InboxActions.approveScenarioError({
                                error:
                                    "An error has occurred. The scenario hasn't yet been approved",
                            }),
                        ),
                    ),
                ),
        ),
    );

const declineScenario: Epic<InboxActionsType> = action$ =>
    action$.pipe(
        filter(isActionOf(InboxActions.declineScenario)),
        mergeMap(action =>
            http
                .postFormData(
                    `${getConfig().SdxService}/batchmanagement/Scenario/decline`,
                    action.payload,
                )
                .pipe(
                    map(() => InboxActions.declineScenarioComplete()),
                    catchError(() =>
                        of(
                            InboxActions.declineScenarioError({
                                error:
                                    "An error has occurred. The scenario hasn't yet been declined",
                            }),
                        ),
                    ),
                ),
        ),
    );

export default combineEpics(
    fetchInbox,
    downloadScenarioFileVersion,
    approveScenario,
    declineScenario,
);
