/* eslint-disable react/destructuring-assignment,react/button-has-type */
import React, { PureComponent } from 'react';
import { RootState } from 'typesafe-actions';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import _ from 'lodash';
import classnames from 'classnames';
import shortid from 'shortid';
import Paper from '@material-ui/core/Paper';
import ThumbUpIcon from '@material-ui/icons/ThumbUp';
import ThumbDownIcon from '@material-ui/icons/ThumbDown';
import CompareIcon from '@material-ui/icons/CompareArrows';
import { Required } from 'utility-types';
import * as Actions from '../../actions';
import * as BatchActions from '../batchManager/batchManagerActions';
import * as InboxActions from './inboxActions';
import inboxColumnDefs from './inboxColumnDefinitions';
import './inbox.scss';
import MainMenu from '../shared/mainMenu';
import ErrorMessage from '../shared/errorMessage';
import DefaultStressTableCell from '../shared/defaultStressTableCell';
import ScenarioCompareDialog from '../shared/scenarioCompareDialog';
import TooltipButton from '../shared/tooltipButton';
import CsvDownloadButton from '../shared/csvDownloadButton';
import InboxFormDialog from './inboxFormDialog';
import { readWrite, isSuperUser } from '../../helpers/authentication';
import getAffectedBatches from '../../helpers/getAffectedBatches';
import LoadingData from '../shared/loadingData';
import { IInboxProps, IInboxState, InBoxScenario } from './inbox.types';

export class Inbox extends PureComponent<IInboxProps, IInboxState> {
    constructor(props: IInboxProps) {
        super(props);
        this.createOpenDialogHandler = this.createOpenDialogHandler.bind(this);
        this.closeFormDialog = this.closeFormDialog.bind(this);
        this.saveHandler = this.saveHandler.bind(this);
    }

    state: IInboxState = {
        openCompareDialog: false,
        selectedScenario: {},
        userAction: '',
        openFormDialog: false,
        inbox: [] as InBoxScenario[],
        user: this.props.user,
    };

    componentDidMount() {
        this.props.actions.fetchInbox();
        this.props.actions.fetchBatches();
    }

    static getDerivedStateFromProps(nextProps, prevState) {
        if (nextProps.inboxModel.inbox !== prevState.inbox || nextProps.user !== prevState.user) {
            return {
                inbox: nextProps.inboxModel.inbox,
                userCanEdit: readWrite(),
                userIsSuperUser: isSuperUser(),
            };
        }

        return null;
    }

    isCompareButtonDisabled = ({ ukId, activeFileVersion, currentActiveFileVersion, action }) =>
        _.some([
            ukId === undefined,
            activeFileVersion === 1 && action === 'CREATE',
            action === 'DELETE',
            this.props.inboxModel.inbox.length === 0,
            !currentActiveFileVersion,
        ]);

    isApproveButtonDisabled = ({ ukId, modifiedBy, action, currentActiveFileVersion }) =>
        _.some([
            ukId === undefined,
            _.includes(modifiedBy, this.props.user.userName),
            action === 'CREATE' && !this.state.userIsSuperUser,
            action === 'DELETE' && !this.state.userIsSuperUser,
            action === 'UPDATE' && !this.state.userIsSuperUser && !currentActiveFileVersion,
        ]);

    isDeclineButtonDisabled = ({ ukId, action, currentActiveFileVersion }) =>
        _.some([
            ukId === undefined,
            action === 'CREATE' && !this.state.userIsSuperUser,
            action === 'DELETE' && !this.state.userIsSuperUser,
            action === 'UPDATE' && !this.state.userIsSuperUser && !currentActiveFileVersion,
        ]);

    getScenarioTableColumnByKey = (column, scenario) => {
        if (column.key === 'currentActiveFileVersion' || column.key === 'activeFileVersion') {
            return (
                <td className={column.className} key={shortid.generate()}>
                    <button
                        className="stress__button_link"
                        onClick={this.downloadInboxItemActiveVersion(scenario, column.key)}
                    >
                        {scenario[column.key]}
                    </button>
                </td>
            );
        }

        return DefaultStressTableCell(column, scenario);
    };

    downloadInboxItemActiveVersion = (
        curInboxItem: InBoxScenario,
        versionKey: 'currentActiveFileVersion' | 'activeFileVersion',
    ) => () => {
        const { ukId, validFrom, name, pending } = curInboxItem;
        this.props.actions.downloadScenarioFile(
            {
                ukId,
                name,
                validFrom,
                version: curInboxItem[versionKey],
                pending,
            },
            versionKey,
        );
    };

    createOpenDialogHandler(userAction) {
        return () => {
            this.setState({
                userAction,
                openFormDialog: true,
            });
        };
    }

    closeFormDialog(fetch) {
        if (fetch) {
            this.props.actions.fetchInbox();
        }
        this.setState({
            userAction: '',
            openFormDialog: false,
        });
    }

    saveHandler(comments, committee) {
        const scenario = _.find(this.props.inboxModel.inbox, {
            ukId: this.state.selectedScenario.ukId,
        });
        const { approveScenario, declineScenario } = this.props.actions;
        if (this.state.userAction === 'approve') {
            approveScenario(scenario, comments, committee);
        } else {
            declineScenario(scenario, comments, committee);
        }
    }

    render() {
        const {
            inboxModel,
            diffModel,
            actions,
            batchModel: { batches },
        } = this.props;
        const {
            openCompareDialog,
            selectedScenario,
            openFormDialog,
            inbox,
            userCanEdit,
        } = this.state;
        const isApproveButtonDisabled = this.isApproveButtonDisabled(selectedScenario as Required<
            InBoxScenario
        >);
        const isDeclineButtonDisabled = this.isDeclineButtonDisabled(selectedScenario as Required<
            InBoxScenario
        >);
        const isCompareButtonDisabled = this.isCompareButtonDisabled(selectedScenario as Required<
            InBoxScenario
        >);
        const csvButtonClass = classnames({
            stress__header__button: true,
            'stress__header__action-button': true,
            'stress-button__disabled': inboxModel.inbox.length === 0,
        });
        const compareButtonClass = classnames({
            stress__header__button: true,
            'stress__header__action-button': true,
            'stress-button__disabled': isCompareButtonDisabled,
        });
        const approveButtonClass = classnames({
            stress__header__button: true,
            'stress__header__action-button': true,
            'stress-button__disabled': isApproveButtonDisabled,
        });
        const declineButtonClass = classnames({
            stress__header__button: true,
            'stress__header__action-button': true,
            'stress-button__disabled': isDeclineButtonDisabled,
        });
        const rowClass = ukId =>
            classnames({
                'stress-table--row': true,
                'stress-table--row_selected': ukId === selectedScenario.ukId,
            });
        return (
            <section id="stress-inbox" className="stress-ui-container">
                <header className="stress__header">
                    <div className="stress__header__title">
                        <h2 className="stress__header__title__main-text">Approvals Inbox</h2>
                    </div>
                    {!inboxModel.isFetchingInbox && (
                        <div>
                            {userCanEdit && (
                                <TooltipButton
                                    id="stress-inbox--approve-button"
                                    disabled={isApproveButtonDisabled}
                                    className={approveButtonClass}
                                    clickHandler={this.createOpenDialogHandler('approve')}
                                    tooltip="Approve"
                                >
                                    <ThumbUpIcon />
                                </TooltipButton>
                            )}
                            {userCanEdit && (
                                <TooltipButton
                                    id="stress-inbox--decline-button"
                                    disabled={isDeclineButtonDisabled}
                                    className={declineButtonClass}
                                    clickHandler={this.createOpenDialogHandler('decline')}
                                    tooltip="Decline"
                                >
                                    <ThumbDownIcon />
                                </TooltipButton>
                            )}
                            <TooltipButton
                                id="stress-inbox--compare-button"
                                disabled={isCompareButtonDisabled}
                                className={compareButtonClass}
                                clickHandler={() => {
                                    this.setState({ openCompareDialog: true });
                                }}
                                tooltip="Compare"
                            >
                                <CompareIcon />
                            </TooltipButton>
                            <CsvDownloadButton
                                id="stress__inbox__download"
                                tooltip="Download as CSV"
                                disabled={inboxModel.inbox.length === 0}
                                headers={inboxColumnDefs}
                                csvData={inboxModel.inbox}
                                className={csvButtonClass}
                                filename="Approvals_Inbox"
                            />
                        </div>
                    )}
                    <MainMenu />
                </header>

                <Paper className="stress-paper">
                    {inboxModel.inboxError && <ErrorMessage message={inboxModel.inboxError} />}

                    <LoadingData
                        showLoading={inboxModel.isFetchingInbox}
                        render={() => <div className="stress-loading" />}
                    />

                    {!inboxModel.isFetchingInbox && inboxModel.inbox.length === 0 && (
                        <ErrorMessage message="There are no scenario files awaiting approval." />
                    )}

                    {inbox.length > 0 && (
                        <table className="stress-table">
                            <thead>
                                <tr>
                                    {inboxColumnDefs.map(heading => (
                                        <th key={heading.key}>{heading.label}</th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody>
                                {inbox.map(scenario => (
                                    <tr
                                        key={shortid.generate()}
                                        className={rowClass(scenario.ukId)}
                                        onClick={() =>
                                            this.setState({ selectedScenario: scenario })
                                        }
                                    >
                                        {inboxColumnDefs.map(column =>
                                            this.getScenarioTableColumnByKey(column, scenario),
                                        )}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}
                </Paper>

                {openCompareDialog && (
                    <ScenarioCompareDialog
                        scenario={{
                            ...selectedScenario,
                            activeFileVersion: (selectedScenario as Required<InBoxScenario>)
                                .currentActiveFileVersion,
                        }}
                        fileVersionToCompare="PENDING"
                        closeHandler={() => {
                            this.setState({ openCompareDialog: false });
                        }}
                        fetchDiff={actions.fetchDiff}
                        diff={diffModel.diff}
                        isFetchingDiff={diffModel.isFetchingDiff}
                        fetchDiffError={diffModel.fetchDiffError}
                    />
                )}

                {openFormDialog && (
                    <InboxFormDialog
                        userAction={this.state.userAction}
                        fileAction={(selectedScenario as Required<InBoxScenario>).action}
                        open={openFormDialog}
                        isSaving={inboxModel.isSaving}
                        saveError={inboxModel.saveError}
                        hasInboxSaved={inboxModel.hasInboxSaved}
                        saveHandler={this.saveHandler}
                        cancelHandler={this.closeFormDialog}
                        affectedBatches={getAffectedBatches(batches, selectedScenario)}
                    />
                )}
            </section>
        );
    }
}

export const mapStateToProps = (state: RootState) => ({
    batchModel: state.BATCHES,
    inboxModel: state.INBOX,
    user: state.USER,
    diffModel: state.DIFF,
});

export const mapDispatchToProps = dispatch => ({
    actions: bindActionCreators(Object.assign({}, Actions, BatchActions, InboxActions), dispatch),
});

export const InboxConnected = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Inbox);
