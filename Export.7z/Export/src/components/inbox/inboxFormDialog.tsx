/* eslint-disable react/destructuring-assignment,react/button-has-type */
import React from 'react';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import ErrorMessage from '../shared/errorMessage';
import LoadingButton from '../shared/loadingButton';
import { APPROVAL_COMMITTEES } from './inboxConstants';
import getFormFieldClass from '../../helpers/getFormFieldClass';
import { IInboxFormStateProps, IInboxFormHandlerState } from './inbox.types';

const actionTypes = {
    approve: {
        dialogTitle: 'Approve',
        verb: 'approving',
        actionButtonLabel: 'Approve',
        CREATE: {
            inputLabel: 'Reason for approving',
            saveActionCompletedMessage: 'File created and set as ACTIVE version.',
        },
        UPDATE: {
            inputLabel: 'Reason for approving this update',
            saveActionCompletedMessage: 'File updated and set as ACTIVE version.',
        },
        SWITCH: {
            inputLabel: 'Reason for approving active file version change',
            saveActionCompletedMessage: 'Scenario active file version updated',
        },
        DELETE: {
            inputLabel: 'Reason for approving scenario deletion',
            saveActionCompletedMessage: 'Scenario deleted',
        },
    },
    decline: {
        dialogTitle: 'Decline',
        verb: 'declining',
        actionButtonLabel: 'Decline',
        CREATE: {
            inputLabel: 'Reason for declining',
            saveActionCompletedMessage:
                'New file rejected and file status has been marked as DECLINED.',
        },
        UPDATE: {
            inputLabel: 'Reason for declining this update',
            saveActionCompletedMessage:
                'Update rejected and file status has been marked as DECLINED.',
        },
        SWITCH: {
            inputLabel: 'Reason for declining active file version change',
            saveActionCompletedMessage: 'Scenario active version remains unchanged',
        },
        DELETE: {
            inputLabel: 'Reason for declining scenario deletion',
            saveActionCompletedMessage: 'Deletion has been declined',
        },
    },
};

class InboxFormDialog extends React.PureComponent<IInboxFormStateProps> {
    constructor(props: IInboxFormStateProps) {
        super(props);
        this.saveHandler = this.saveHandler.bind(this);
        this.cancelHandler = this.cancelHandler.bind(this);
        this.closeHandler = this.closeHandler.bind(this);
        this.handleFormInputTouched = this.handleFormInputTouched.bind(this);
        this.createFormInputChangeHandler = this.createFormInputChangeHandler.bind(this);
    }

    state: IInboxFormHandlerState = {
        reasonForChange: '',
        approvalCommittee: '',
        valid: false,
        saveError: this.props.saveError,
    };

    static getInitialState() {
        return {
            reasonForChange: '',
            approvalCommittee: '',
            valid: false,
        } as IInboxFormHandlerState;
    }

    static getDerivedStateFromProps(nextProps, prevState) {
        if (nextProps.saveError !== prevState.saveError) {
            return {
                saveError: nextProps.saveError,
            };
        }

        return null;
    }

    fieldIsValid = () => (this.state.reasonForChangeTouched ? this.state.valid : true);

    cancelHandler() {
        this.setState(InboxFormDialog.getInitialState());
        this.props.cancelHandler();
    }

    closeHandler() {
        this.setState(InboxFormDialog.getInitialState());
        this.props.cancelHandler(true);
    }

    saveHandler() {
        const { reasonForChange, approvalCommittee } = this.state;
        this.props.saveHandler(reasonForChange, approvalCommittee);
    }

    createFormInputChangeHandler(fieldName) {
        return ({ target: { value } }) => {
            this.setState(
                {
                    [fieldName]: value,
                },
                () => {
                    const { reasonForChange } = this.state;
                    const rules = [reasonForChange.length >= 20];
                    this.setState({ valid: rules.every(x => x) });
                },
            );
        };
    }

    handleFormInputTouched() {
        this.setState({
            reasonForChangeTouched: true,
        });
    }

    render() {
        const {
            open,
            userAction,
            fileAction,
            isSaving,
            affectedBatches = '',
            hasInboxSaved,
        } = this.props;
        const { valid, reasonForChange, saveError } = this.state;
        const formFieldClassName = getFormFieldClass(this.fieldIsValid());
        return (
            <div className="stress__inbox-dialog">
                <Dialog open={open} onClose={this.cancelHandler} className="stress__dialog">
                    <DialogTitle>{actionTypes[userAction].dialogTitle}</DialogTitle>
                    <DialogContent>
                        <p className="stress__inbox-dialog__intro">
                            Please give a reason for {actionTypes[userAction].verb} this scenario
                            file. {userAction === 'decline' ? '' : `${affectedBatches}`}
                        </p>
                        <div className={`${formFieldClassName} stress__inbox-dialog__comments`}>
                            <label
                                className="stress__form__label"
                                htmlFor="stress__inbox-dialog__comments"
                            >
                                {actionTypes[userAction][fileAction].inputLabel}
                            </label>
                            <input
                                id="stress__inbox-dialog__comments"
                                className="stress__form__input"
                                onChange={this.createFormInputChangeHandler('reasonForChange')}
                                onBlur={this.handleFormInputTouched}
                                disabled={isSaving || hasInboxSaved}
                                type="text"
                            />
                            <p className="stress__form__help-text">
                                20 characters minimum ({reasonForChange.length})
                            </p>
                        </div>
                        <div className="stress__form__field stress__inbox-dialog__committee">
                            <label
                                htmlFor="stress__inbox-dialog__committee"
                                className="stress__form__label"
                            >
                                Approval committee
                            </label>
                            <select
                                value={this.state.approvalCommittee}
                                className="stress__form__select"
                                onChange={this.createFormInputChangeHandler('approvalCommittee')}
                                id="stress__inbox-dialog__committee"
                                disabled={isSaving || hasInboxSaved}
                            >
                                <option value="">Please select</option>
                                {APPROVAL_COMMITTEES.map(option => (
                                    <option key={option.value} value={option.value}>
                                        {option.label}
                                    </option>
                                ))}
                            </select>
                            <p className="stress__form__help-text">This field is optional</p>
                        </div>
                        {isSaving && <LoadingButton text="Saving" />}
                        {!hasInboxSaved && !isSaving && (
                            <button
                                id="stress__inbox-dialog__confirm"
                                className="stress__button"
                                disabled={!valid}
                                onClick={this.saveHandler}
                            >
                                {actionTypes[userAction].actionButtonLabel}
                            </button>
                        )}
                        {hasInboxSaved && !saveError && (
                            <p id="stress__inbox-dialog__action">
                                <span className="stress__inbox-dialog__outcome">
                                    {actionTypes[userAction][fileAction].saveActionCompletedMessage}
                                </span>
                                <button
                                    className="stress__button-secondary"
                                    onClick={this.closeHandler}
                                >
                                    OK
                                </button>
                            </p>
                        )}
                        {saveError && <ErrorMessage important message={saveError} />}
                    </DialogContent>
                    <DialogActions>
                        {hasInboxSaved ? (
                            <button
                                id="stress__inbox-dialog__close"
                                className="stress__button-secondary"
                                onClick={this.closeHandler}
                            >
                                Close
                            </button>
                        ) : (
                            <button
                                id="stress__inbox-dialog__cancel"
                                className="stress__button-secondary"
                                onClick={this.cancelHandler}
                            >
                                Cancel
                            </button>
                        )}
                    </DialogActions>
                </Dialog>
            </div>
        );
    }
}

export default InboxFormDialog;
