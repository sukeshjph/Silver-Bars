import React from 'react';
import PropTypes from 'prop-types';
import AddIcon from '@material-ui/icons/Add';
import PendingIcon from './batchPendingIcon.tsx';

class BatchListAvailableScenario extends React.PureComponent {
    static propTypes = {
        scenario: PropTypes.shape({
            pending: PropTypes.bool,
            activeFileVersion: PropTypes.number,
        }).isRequired,
        addScenarioToBatch: PropTypes.func.isRequired,
        displayName: PropTypes.string.isRequired,
        limitReached: PropTypes.bool.isRequired,
    };

    render() {
        const {
            scenario,
            addScenarioToBatch,
            displayName,
            limitReached,
        } = this.props;
        return (
            <div>
                { scenario.activeFileVersion &&
                <li
                    className="stress-batch__list__item"
                    onDoubleClick={ addScenarioToBatch }
                    title={ limitReached ? 'Maximum number of scenarios selected' : '' }
                >
                    <h4 className="stress-batch__list__item__title" title={ displayName }>
                        { displayName }
                    </h4>
                    <PendingIcon pending={ scenario.pending }/>
                    <button
                        disabled={ limitReached }
                        className="stress__batch__list__add-button"
                        onClick={ addScenarioToBatch }
                        type="button"
                    >
                        <AddIcon />
                    </button>
                </li>
                }
            </div>
        );
    }
};

export default BatchListAvailableScenario;