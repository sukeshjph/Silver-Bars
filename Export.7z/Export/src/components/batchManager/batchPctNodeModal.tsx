/* eslint-disable react/destructuring-assignment  */
import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import classnames from 'classnames';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import Button from '@material-ui/core/Button';
import ExpandIcon from '@material-ui/icons/ChevronRight';
import { get } from '../../helpers/utilities';
import * as BatchActions from './batchManagerActions';
import ReasonForChange from '../shared/reasonForChange';
import ErrorMessage from '../shared/errorMessage';
import { IErrorTypeProps } from '../../interfaces/globals';
import {
    IPctModalProps,
    IPctModalStateProps,
    IPctNode,
    IPCTMapStateProps,
    IPCTDispatchProps,
} from './batchManager.types';

class BatchPctNodeModal extends React.PureComponent<IPctModalProps, IPctModalStateProps> {
    constructor(props: IPctModalProps) {
        super(props);
        this.state = {
            expandedNodes: [],
            selectedNode: undefined,
            disableTree: false,
        };
        this.handleUndoClick = this.handleUndoClick.bind(this);
        this.handleSaveClick = this.handleSaveClick.bind(this);
    }

    componentDidMount() {
        if (Object.keys(this.props.pctNodeTree).length === 0) {
            this.props.fetchPctNodes();
        }
    }

    getNode = (nodeId: string) => this.props.pctNodeTree[nodeId];

    getButtonClass = (nodeId: string) => {
        const isSelected = nodeId === get(this.state.selectedNode, 'id', false);
        return classnames({
            'stress-batch__pct__select-button': !isSelected,
            'stress-batch__pct__select-button--selected': isSelected,
        });
    };

    isNodeExpanded = (nodeId: string) => this.state.expandedNodes.includes(nodeId);

    createNodeSelectHandler = (node: IPctNode) => () => this.handleNodeSelectClick(node);

    createNodeExpandHandler = (node: IPctNode) => () => this.handleNodeExpandClick(node);

    handleNodeExpandClick(clickedNode: IPctNode) {
        const { expandedNodes } = this.state;
        this.setState({
            expandedNodes: expandedNodes.includes(clickedNode.id)
                ? expandedNodes.filter(node => node !== clickedNode.id) // close node
                : [...expandedNodes, clickedNode.id], // expand node
        });
    }

    handleNodeSelectClick(selectedNode: IPctNode) {
        this.setState({ selectedNode });
    }

    handleSaveClick(comments: string) {
        this.setState({
            disableTree: true,
        });
        this.props.saveBatch({
            ...this.props.batch,
            pctNode: this.state.selectedNode.name,
            pctNodeId: this.state.selectedNode.id,
            comments,
        });
    }

    handleUndoClick() {
        this.setState({ selectedNode: undefined });
    }

    renderTree(list: Array<string>) {
        return (
            <ul className="stress-batch__pct__list">
                {list.map(nodeId => this.renderNode(nodeId))}
            </ul>
        );
    }

    renderNode(nodeId: string) {
        const node = this.getNode(nodeId);
        const isExpanded = this.isNodeExpanded(nodeId);

        return (
            <li
                key={nodeId}
                className={`stress-batch__pct__node  ${
                    isExpanded ? 'stress-batch__pct__list--expanded' : ''
                }`}
            >
                {node.children.length > 0 ? (
                    <div>
                        <Button
                            disabled={this.state.disableTree}
                            className={`stress-batch__pct__toggle-button  ${
                                isExpanded ? 'stress-batch__pct__toggle-button--expanded' : ''
                            }`}
                            onClick={this.createNodeExpandHandler(node)}
                        >
                            <ExpandIcon />
                        </Button>
                        <button
                            disabled={this.state.disableTree}
                            className={this.getButtonClass(nodeId)}
                            type="button"
                            onClick={this.createNodeSelectHandler(node)}
                        >
                            {node.name}
                        </button>
                        {isExpanded && this.renderTree(node.children)}
                    </div>
                ) : (
                    <button
                        disabled={this.state.disableTree}
                        className="stress-batch__pct__select-button stress-batch__pct__select-button--leaf"
                        type="button"
                        onClick={this.createNodeSelectHandler(node.id)}
                    >
                        {node.name}
                    </button>
                )}
            </li>
        );
    }

    render() {
        const {
            closePctNodeDialog,
            isFetchingPctNodes,
            pctNodeTree,
            batch,
            isSavingBatch,
            pctNodeError,
        } = this.props;
        const { selectedNode } = this.state;

        const errorMessageProps = { message: pctNodeError } as IErrorTypeProps;
        return (
            <Dialog className="stress-batch__pct__dialog" open onClose={closePctNodeDialog}>
                <DialogTitle>Select new PCT node for {batch.name} batch</DialogTitle>
                <DialogContent className="stress-batch__pct__dialog__content">
                    {pctNodeError && <ErrorMessage {...errorMessageProps} />}
                    {isFetchingPctNodes && (
                        <div className="stress-loading stress-batch__pct__loading" />
                    )}
                    {pctNodeTree.rootNodes && pctNodeTree.rootNodes.length > 0 && (
                        <div
                            className={`stress-batch__pct__list__container ${
                                this.state.selectedNode
                                    ? 'stress-batch__pct__list__container--compressed'
                                    : ''
                            }`}
                        >
                            <ul className="stress-batch__pct__list">
                                {pctNodeTree.rootNodes.map(nodeId => this.renderNode(nodeId))}
                            </ul>
                        </div>
                    )}
                    {selectedNode && batch.pctNode !== selectedNode && (
                        <div>
                            <p className="stress-batch__pct__message">{`Setting PCT node to ${
                                selectedNode.name
                            } (${selectedNode.id}) on ${batch.name} batch`}</p>
                            <ReasonForChange
                                actions={{
                                    handleSaveClick: this.handleSaveClick,
                                    handleUndoClick: this.handleUndoClick,
                                    handleDoneClick: closePctNodeDialog,
                                }}
                                model={{
                                    isSaving: isSavingBatch,
                                }}
                            />
                        </div>
                    )}
                </DialogContent>
                <DialogActions>
                    <Button onClick={closePctNodeDialog}>Cancel</Button>
                </DialogActions>
            </Dialog>
        );
    }
}

const mapStateToProps = (state: IPCTMapStateProps) => ({
    isFetchingPctNodes: state.BATCHES.isFetchingPctNodes,
    isSavingBatch: state.BATCHES.isSavingBatch,
    pctNodeTree: state.BATCHES.pctNodeTree,
    pctNodeError: state.BATCHES.pctNodeError,
});

const mapDispatchToProps = (dispatch: IPCTDispatchProps) => {
    const { fetchPctNodes, saveBatch } = bindActionCreators(
        Object.assign({}, BatchActions),
        dispatch,
    );
    return {
        fetchPctNodes,
        saveBatch,
    };
};

export const BatchPctNodeModalConnected = connect(
    mapStateToProps,
    mapDispatchToProps,
)(BatchPctNodeModal);
