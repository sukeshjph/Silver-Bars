import { of, forkJoin } from 'rxjs';
import { mergeMap, catchError, map } from 'rxjs/operators';
import { combineEpics, ofType } from 'redux-observable';
import { batchActionTypes, pctNodeRequestBody } from './batchManagerConstants';
import { getConfig } from '../../common/config';
import http from '../../helpers/http';

const fetchBatchesAndScenarios = action$ =>
    action$.pipe(
        ofType(batchActionTypes.FETCH_BATCHES_AND_SCENARIOS),
        mergeMap(() =>
            forkJoin(
                http.getData(`${getConfig().SdxService}/batchmanagement/Batch`),
                http.getData(`${getConfig().SdxService}/batchmanagement/Scenario`),
                http.getData(`${getConfig().SdxService}/batchmanagement/Scenario?status=pending`),
            ).pipe(
                map(data => ({
                    type: batchActionTypes.FETCH_BATCHES_AND_SCENARIOS_COMPLETE,
                    payload: {
                        batches: data[0],
                        scenarios: data[1],
                        pendingScenarios: data[2],
                        pctNodes: data[3],
                    },
                })),
                catchError(error =>
                    of({
                        type: batchActionTypes.FETCH_BATCHES_AND_SCENARIOS_ERROR,
                        payload: { error },
                    }),
                ),
            ),
        ),
    );

const fetchBatches = action$ =>
    action$.pipe(
        ofType(batchActionTypes.FETCH_BATCHES),
        mergeMap(() =>
            http.getData(`${getConfig().SdxService}/batchmanagement/Batch`).pipe(
                map(batches => ({
                    type: batchActionTypes.FETCH_BATCHES_COMPLETE,
                    payload: {
                        batches,
                    },
                })),
                catchError(error =>
                    of({
                        type: batchActionTypes.FETCH_BATCHES_ERROR,
                        payload: { error },
                    }),
                ),
            ),
        ),
    );

const fetchPctNodes = action$ =>
    action$.pipe(
        ofType(batchActionTypes.FETCH_PCT_NODES),
        mergeMap(() =>
            http.getDataFromMDS(`${getConfig().MdsService}/queryMaster`, pctNodeRequestBody).pipe(
                map(data => ({
                    type: batchActionTypes.FETCH_PCT_NODES_COMPLETE,
                    payload: {
                        pctHeaders: data.columnHeaders,
                        pctData: data.relationData,
                    },
                })),
                catchError(() =>
                    of({
                        type: batchActionTypes.FETCH_PCT_NODES_ERROR,
                        payload: {
                            error: 'Unable to fetch PCT node tree',
                        },
                    }),
                ),
            ),
        ),
    );

const saveBatch = action$ =>
    action$.pipe(
        ofType(batchActionTypes.SAVE_BATCH),
        mergeMap(action =>
            http.postData(
                `${getConfig().SdxService}/batchmanagement/Batch/update`,
                action.payload.batch,
            ),
        ),
        mergeMap(() =>
            forkJoin(
                http.getData(`${getConfig().SdxService}/batchmanagement/Batch`),
                http.getData(`${getConfig().SdxService}/batchmanagement/Batch?asOf=ALL`),
            ).pipe(
                map(data => ({
                    type: batchActionTypes.SAVE_BATCH_COMPLETE,
                    payload: {
                        batches: data[0],
                        batchAudits: data[1],
                    },
                })),
                catchError(error =>
                    of({
                        type: batchActionTypes.SAVE_BATCH_ERROR,
                        payload: { error },
                    }),
                ),
            ),
        ),
    );

export default combineEpics(fetchBatches, fetchPctNodes, fetchBatchesAndScenarios, saveBatch);
