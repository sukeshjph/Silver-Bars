import { pick } from '../../helpers/utilities';
import { batchActionTypes } from './batchManagerConstants';
import { IBatch } from '../../interfaces/globals';

// Batch Actions
export const fetchBatches = () => ({ type: batchActionTypes.FETCH_BATCHES });
export const fetchPctNodes = () => ({ type: batchActionTypes.FETCH_PCT_NODES });
export const fetchBatchesAndScenarios = () => ({
    type: batchActionTypes.FETCH_BATCHES_AND_SCENARIOS,
});
export const saveBatch = (batch: IBatch) => ({
    type: batchActionTypes.SAVE_BATCH,
    payload: {
        batch: pick(batch, [
            'type',
            'id',
            'ukId',
            'comments',
            'name',
            'scenarios',
            'cobDate',
            'pctNode',
            'pctNodeId',
            'scheduleDto',
        ]),
    },
});
