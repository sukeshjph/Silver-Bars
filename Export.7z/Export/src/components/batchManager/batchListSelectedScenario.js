import React from 'react';
import PropTypes from 'prop-types';
import RemoveIcon from '@material-ui/icons/Remove';

class BatchListSelectedScenario extends React.PureComponent {
    static propTypes = {
        removeScenarioFromBatch: PropTypes.func.isRequired,
        displayName: PropTypes.string.isRequired,
        userAction: PropTypes.string,
    };

    render() {
        const {
            displayName,
            userAction,
            removeScenarioFromBatch,
        } = this.props;
        return (
            <li
                className="stress-batch__list__item"
                onDoubleClick={ removeScenarioFromBatch }
            >
                <h4 className="stress-batch__list__item__title" title={ displayName }>
                    { displayName }
                </h4>
                { userAction &&
                <span className={`stress__batch__action--${userAction}`}>{ userAction }</span>
                }
                { userAction !== 'removed' &&
                <button
                    className="stress__batch__list__remove-button"
                    onClick={ removeScenarioFromBatch }
                    type="button"
                >
                    <RemoveIcon />
                </button>
                }
            </li>
        );
    }
}

BatchListSelectedScenario.defaultProps = {
    userAction: '',
};

export default BatchListSelectedScenario;