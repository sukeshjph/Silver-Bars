import * as BatchSummaryActions from '../components/batchSummary/batchSummaryActions';
import * as BatchScheduleActions from '../components/batchSchedule/batchScheduleActions';
import * as DownloadsActions from '../components/downloads/downloadsActions';
import * as BatchDetailsActions from '../components/batchDetails/batchDetailsActions';

export default {
    batchSummary: BatchSummaryActions,
    batchSchedule: BatchScheduleActions,
    downloads: DownloadsActions,
    batchDetails: BatchDetailsActions,
};
