import { createAction, createStandardAction } from 'typesafe-actions';
import { diffActionTypes, authActionTypes } from '../constants';
import { getSessionFromStorage } from '../helpers/authentication';
import { ErrorType } from '../interfaces/globals';

// Diff actions
export const fetchDiff = createAction(
    diffActionTypes.FETCH_DIFF,
    action => (ukId: string, file: any, fileVersionToCompare: any) =>
        action({
            ukId,
            file,
            fileVersionToCompare,
        }),
);

export const fetchDiffComplete = createAction(
    diffActionTypes.FETCH_DIFF_COMPLETE,
    action => (diff: any, ukId: string) => action({ diff, ukId }),
);

export const fetchDiffErrors = createStandardAction(diffActionTypes.FETCH_DIFF_ERROR)<ErrorType>();

// Auth Actions
export const signIn = createAction(
    authActionTypes.AUTHENTICATE,
    action => (username: string, password: string) => action({ username, password }),
);

export const signInComplete = createAction(
    authActionTypes.AUTHENTICATION_COMPLETE,
    action => ({ uvaData }: any) => action({ uvaData }),
);

export const signInError = createAction(
    authActionTypes.AUTHENTICATION_ERROR,
    action => ({ error }: ErrorType) => action({ error }),
);

export const signOut = createAction(authActionTypes.SIGN_OUT);

export const entitlementsComplete = createAction(
    authActionTypes.ENTITLEMENTS_COMPLETE,
    action => (entitlements: any) => action({ ...entitlements }),
);

export const entitlementsError = createAction(
    authActionTypes.AUTHENTICATION_ERROR,
    action => ({ error }: ErrorType) => action({ error }),
);

export const reloadSession = createAction(
    authActionTypes.RELOAD_SESSION,
    action => () => action({ uvaData: getSessionFromStorage() }),
);
