const merge = require('webpack-merge');
const webpack = require('webpack');
const CleanWebpackPlugin = require('clean-webpack-plugin');
const generateBaseConfig = require('./packaging/webpack.base.config');
const production = require('./packaging/webpack.prod.base.config');

module.exports = merge(
    generateBaseConfig(
        {
            app: ['./src/index.js'],
        },
        __dirname,
        'production',
        [
            new CleanWebpackPlugin(['dist']),
            ...production.plugins.slice(0, 2),
            new webpack.DefinePlugin({
                ISLOCAL: JSON.stringify(true),
                'process.env.NODE_ENV': JSON.stringify('production'),
            }),
            ...production.plugins.slice(4),
        ],
    ),
    production.config,
);
