import shortid from 'shortid';
import { StringTMap } from './interfaces/globals';
// State constants
export const NAME = 'STRESS';
export const BASE_URL = '/';
export const MAX_DATE = '9999-12-31 00:00:00';
export const MAX_FILE_SIZE = 5242880;
export const DEFAULT_NUMBER_OF_AUDIT_DAYS_DISPLAYED = 15;
export const API_DATE_FORMAT = 'YYYY-MM-DD';
export const API_DATE_TIME_FORMAT = 'YYYY-MM-DD HH:mm:ss.SSS';

export const diffActionTypes = {
    FETCH_DIFF: 'STRESS/FETCH_DIFF',
    FETCH_DIFF_COMPLETE: 'STRESS/FETCH_DIFF_COMPLETE',
    FETCH_DIFF_ERROR: 'STRESS/FETCH_DIFF_ERROR',
} as const;

export const configUrl: string = '/api/batchmanagement/ui/config';
export const apiUrls = {
    DownloadService:
        'http://uklpadsab102a.uk.standardchartered.com:9401/api/batchmanagement/sabrestore/datasets',
    ShockCompilerService: 'http://uklpadsab104a.uk.standardchartered.com:9202/api/compile/shock',
    SdxService: 'http://sabre-dev-batchmanagement-server.uk.standardchartered.com/api', // 'http://uklpadsab102a.uk.standardchartered.com:9401/api',
    UvaService: 'https://uklpadtoy11a.uk.standardchartered.com:8443/ums', // sha2: 'http://uklvadsab15.uk:8443/ums'
    MdsService: 'https://dev-cloud.uk.standardchartered.com:30758/mds',
    asOfTime: '05:00:00.000',
};

// http://uklvadsab15.uk:8443/ums(UVA hack)
// 'http://sabre-dev-batchmanagement-server.uk.standardchartered.com',

export const headerNavLinks = [
    {
        title: 'Go to All Batches',
        to: '/batches',
        text: 'All Batches',
        id: shortid.generate(),
    },
    {
        title: 'Go to Dashboard',
        to: '/dashboard',
        text: 'Dashboard',
        id: shortid.generate(),
    },
];

export const authActionTypes = {
    AUTHENTICATE: 'STRESS/AUTHENTICATE',
    AUTHENTICATION_COMPLETE: 'STRESS/AUTHENTICATION_COMPLETE',
    AUTHENTICATION_ERROR: 'STRESS/AUTHENTICATION_ERROR',
    ENTITLEMENTS_COMPLETE: 'STRESS/ENTITLEMENTS_COMPLETE',
    SIGN_IN_COMPLETE: 'STRESS/SIGN_IN_COMPLETE',
    SIGN_IN_ERROR: 'STRESS/SIGN_IN_ERROR',
    SIGN_OUT: 'STRESS/SIGN_OUT',
    SIGN_OUT_COMPLETE: 'STRESS/SIGN_OUT_COMPLETE',
    SIGN_OUT_ERROR: 'STRESS/SIGN_OUT_ERROR',
    RELOAD_SESSION: 'STRESS/RELOAD_SESSION',
} as const;

export const PCTOptions = {
    All: false,
    FXO: false,
    CM: false,
    'Rates / & IRO': false,
    Credit: false,
    BCS: false,
} as StringTMap<boolean>;
