let configuration = null;

export const initialise = config => {
    configuration = config;
};

export const getConfig = () => {
    if (!configuration) {
        console.log('Attempting to access configuration prior to it being loaded'); //eslint-disable-line
        return null;
    }
    return configuration;
};
