// @ts-nocheck
import React from 'react';
import Loadable from 'react-loadable';
import RouteLoading from './shared/routeLoading';

export const Downloads = Loadable({
    loader: () => import(/* webpackChunkName: 'downloads' */ './downloads'),
    loading: RouteLoading,
    delay: 500,
});

// export const BatchManager = Loadable({
//     loader: () => import(/* webpackChunkName: 'batchManager' */ './batchManager'),
//     loading: RouteLoading,
//     delay: 500,
//     render(loaded, props) {
//         const Component = loaded.BatchManagerConnected;
//         return <Component {...props} />;
//     },
// });

export const BatchSummary = Loadable({
    loader: () => import(/* webpackChunkName: 'batchSummary' */ './batchSummary'),
    loading: RouteLoading,
    delay: 500,
});

export const BatchDetails = Loadable({
    loader: () => import(/* webpackChunkName: 'batchDetails' */ './batchDetails'),
    loading: RouteLoading,
    delay: 500,
    render(loaded, props) {
        const Component = loaded.BatchDetailsConnected;
        return <Component {...props} />;
    },
});

export const ScenarioManager = Loadable({
    loader: () => import(/* webpackChunkName: 'scenarioManager' */ './scenarioManager'),
    loading: RouteLoading,
    delay: 500,
    render(loaded, props) {
        const Component = loaded.ScenarioManagerConnected;
        return <Component {...props} />;
    },
});

export const ScenarioAudit = Loadable({
    loader: () => import(/* webpackChunkName: 'scenarioAudit' */ './scenarioAudit'),
    loading: RouteLoading,
    delay: 500,
    render(loaded, props) {
        const Component = loaded.ScenarioAuditConnected;
        return <Component {...props} />;
    },
});

export const BatchAudit = Loadable({
    loader: () => import(/* webpackChunkName: 'batchAudit' */ './batchAudit'),
    loading: RouteLoading,
    delay: 500,
    render(loaded, props) {
        const Component = loaded.BatchAuditConnected;
        return <Component {...props} />;
    },
});

export const Inbox = Loadable({
    loader: () => import(/* webpackChunkName: 'inbox' */ './inbox'),
    loading: RouteLoading,
    delay: 500,
    render(loaded, props) {
        const Component = loaded.InboxConnected;
        return <Component {...props} />;
    },
});

export const BatchSchedule = Loadable({
    loader: () => import(/* webpackChunkName: 'batchSchedule' */ './batchSchedule'),
    loading: RouteLoading,
    delay: 500,
    render(loaded, props) {
        const Component = loaded.BatchScheduleConnected;
        return <Component {...props} />;
    },
});
