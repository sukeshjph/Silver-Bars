import React, { FunctionComponent } from 'react';
import { RootState } from 'typesafe-actions';
import { connect, Dispatch } from 'react-redux';
import { createSelector } from 'reselect';
import { bindActionCreators } from 'redux';
import * as BatchCreateActions from './batchCreateActions';
import {
    BatchCreateActionsType,
    IBatchCreateProps,
    IBatchCreateOwnProps,
} from './batchCreate.types';
import CreateBatchModal from './createBatchModal';

const getCreateBatchState = createSelector(
    (state: RootState) => state.BATCH_CREATE,
    ({ batch, isCreatingBatch, error, isBatchCreated }) => ({
        batch,
        isCreatingBatch,
        error,
        isBatchCreated,
    }),
);

const BatchCreate: FunctionComponent<IBatchCreateProps> = (props: IBatchCreateProps) => (
    <CreateBatchModal {...props} />
);

export default connect(
    (state: RootState, ownProps: IBatchCreateOwnProps) => {
        const { closeHandler } = ownProps;
        return {
            model: { ...getCreateBatchState(state), closeHandler },
        };
    },
    (dispatch: Dispatch<BatchCreateActionsType>) => ({
        actions: bindActionCreators(BatchCreateActions, dispatch),
    }),
)(BatchCreate);
