import React, { FunctionComponent, useState } from 'react';
import Spinner from 'react-spinkit';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import SaveIcon from '@material-ui/icons/Save';
import { withRouter, RouteComponentProps } from 'react-router-dom';
import { IBatchCreateProps } from './batchCreate.types';
import PCTNodes from '../shared/pctNodes';
import { InputEvent } from '../../interfaces/globals';
import { initialBatch } from './batchCreateConstant';
import { accent } from '../../styles/_variables.scss';

import './batchCreate.scss';

const CreateBatch: FunctionComponent<RouteComponentProps<{}> & IBatchCreateProps> = props => {
    const {
        model: { batch, isCreatingBatch, error, closeHandler, isBatchCreated },
        actions: { createBatch, createBatchReset },
    } = props;
    const [newBatch, setNewBatch] = useState(batch);
    const handleBatchNameChange = (event: InputEvent): void => {
        setNewBatch({
            ...newBatch,
            name: (event.target as HTMLInputElement).value,
        });
    };

    const handleCommentsChange = (event: InputEvent): void => {
        setNewBatch({
            ...newBatch,
            comments: (event.target as HTMLInputElement).value,
        });
    };

    const handlePCTNodeChange = (pctNodes: string[]): void => {
        setNewBatch({
            ...newBatch,
            pctNode: pctNodes.join(','),
        });
    };

    const handleCreateBatch = () => {
        createBatch(newBatch);
    };

    const clearPastBatch = () => {
        setNewBatch(initialBatch);
        createBatchReset();
        closeHandler();
    };

    const handleBatchNavigation = () => {
        props.history.push(`/batches/${batch.ukId}`);
        clearPastBatch();
    };

    const isFormValid = () =>
        Object.keys(newBatch)
            .filter(key => !['ukId', 'id'].includes(key))
            .every(key => newBatch[key]);

    const getFormError = () => {
        if (error) {
            return <div style={{ paddingBottom: '5px' }}>{`Create Batch error:${error}`}</div>;
        }
        return null;
    };

    if (isBatchCreated) {
        setTimeout(handleBatchNavigation, 2000);
    }

    return (
        <Dialog open className="stress__dialog">
            <DialogTitle id="form-dialog-title">Create New Batch</DialogTitle>
            <DialogContent>
                <form autoComplete="off" className="stress__form">
                    <div className="stress__form__field">
                        <label htmlFor="batch-name" className="stress__form__label">
                            Batch name
                        </label>
                        <input
                            id="batch-name"
                            placeholder="Enter Batch name"
                            className="stress__form__input"
                            onChange={handleBatchNameChange}
                            value={newBatch.name}
                            disabled={isCreatingBatch || isBatchCreated}
                            type="text"
                            required
                        />
                        <p className="stress__form__help-text">Required</p>
                    </div>
                    <div className="stress__form__field">
                        <label htmlFor="batch-name" className="stress__form__label">
                            PCT Node
                        </label>
                        <PCTNodes
                            handlePCTNodeChange={handlePCTNodeChange}
                            disabled={isCreatingBatch || isBatchCreated}
                        />
                        <p className="stress__form__help-text">Required</p>
                    </div>
                    <div className="stress__form__field">
                        <label htmlFor="batch-comments" className="stress__form__label">
                            Comments
                        </label>
                        <input
                            id="batch-comments"
                            placeholder="Reason for creating this Batch"
                            className="stress__form__input"
                            onChange={handleCommentsChange}
                            value={newBatch.comments}
                            disabled={isCreatingBatch || isBatchCreated}
                            type="text"
                            required
                        />
                        <p className="stress__form__help-text">Required</p>
                    </div>
                    <div>{getFormError()}</div>
                    {!isBatchCreated && (
                        <div>
                            <button
                                disabled={!isFormValid()}
                                className="batch-create-save-button"
                                type="button"
                                onClick={handleCreateBatch}
                            >
                                <SaveIcon /> {isCreatingBatch ? 'Saving' : 'Save'}
                            </button>
                        </div>
                    )}
                    {isBatchCreated && (
                        <div className="batch-create-save-panel">
                            {' '}
                            <button disabled className="batch-create-save-button--saved" type="button">
                                <SaveIcon /> Saved
                            </button>
                            <div className="batch-create-loading-panel">
                                <span className="Loading-message">Loading the batch..</span>
                                <Spinner name="line-scale-pulse-out-rapid" color={accent} />
                            </div>
                        </div>
                    )}
                </form>
            </DialogContent>
            <DialogActions>
                <button className="stress__button-secondary" onClick={clearPastBatch} type="button">
                    Close
                </button>
            </DialogActions>
        </Dialog>
    );
};

export default withRouter(CreateBatch);
