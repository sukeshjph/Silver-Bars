import { IBatch } from '../../interfaces/globals';

export const batchCreateTypes = {
    CREATE_BATCH: 'STRESS/CREATE_BATCH',
    CREATE_BATCH_SUCCESS: 'STRESS/CREATE_BATCH_SUCCESS',
    CREATE_BATCH_ERROR: 'STRESS/CREATE_BATCH_ERROR',
    CREATE_BATCH_RESET: 'STRESS/CREATE_BATCH_RESET',
} as const;

export const initialBatch: Partial<IBatch> = {
    type: 'Batch',
    comments: '',
    name: '',
    pctNode: '',
    id: '',
    ukId: '',
} as const;
