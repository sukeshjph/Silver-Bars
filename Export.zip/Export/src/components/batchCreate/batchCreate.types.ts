import { ActionType } from 'typesafe-actions';
import * as BatchCreateActions from './batchCreateActions';
import { IBatch } from '../../interfaces/globals';

// State Types
export interface IBatchReducer {
    batch: Partial<IBatch>;
    isCreatingBatch: boolean;
    error: string;
    isBatchCreated: boolean;
}

// Action types
export type BatchCreateActionsType = ActionType<typeof BatchCreateActions>;

// Component types
export interface IBatchCreateDefaultProps {}

// These are all the required props
export interface IBatchCreateProps {
    model: {
        batch: Partial<IBatch>;
        isCreatingBatch: boolean;
        error: string;
        closeHandler: () => void;
        isBatchCreated: boolean;
    };
    actions: {
        createBatch: (batch: Partial<IBatch>) => void;
        createBatchReset: () => void;
    };
}

// export interface IState {
//     // this might not be needed if the component doesn't have internal state
// }

// export interface IContext {
//     // this might not be needed if the component doesn't consume the context
// }

// Container

// export type StateProps = Pick<IProps, 'title' | 'width' | 'height'>;
export type IBatchCreateOwnProps = {
    closeHandler: () => void;
};
// export type DispatchProps = Pick<IProps, 'onClick'>;
