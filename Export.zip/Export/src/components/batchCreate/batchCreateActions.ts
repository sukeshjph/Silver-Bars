import { createAction, createStandardAction } from 'typesafe-actions';
import { pick } from '../../helpers/utilities';
import { batchCreateTypes } from './batchCreateConstant';
import { IBatch, ErrorType } from '../../interfaces/globals';

// Create Batch
export const createBatch = createAction(
    batchCreateTypes.CREATE_BATCH,
    action => (batch: Partial<IBatch>) =>
        action({
            batch: pick(batch, ['type', 'comments', 'name', 'cobDate', 'scheduleDto']),
        }),
);

export const createBatchComplete = createStandardAction(batchCreateTypes.CREATE_BATCH_SUCCESS)<
    IBatch
>();

export const createBatchError = createStandardAction(batchCreateTypes.CREATE_BATCH_ERROR)<
    ErrorType
>();

export const createBatchReset = createStandardAction(batchCreateTypes.CREATE_BATCH_RESET)<
    undefined
>();
