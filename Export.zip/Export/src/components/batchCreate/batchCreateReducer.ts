import { createReducer, StateType } from 'typesafe-actions';
import { IBatchReducer, BatchCreateActionsType } from './batchCreate.types';
import { batchCreateTypes, initialBatch } from './batchCreateConstant';

const initialState = {
    batch: initialBatch,
    isCreatingBatch: false,
    error: '',
    isBatchCreated: false,
} as IBatchReducer;

const BatchCreateReducer = createReducer<IBatchReducer, BatchCreateActionsType>(initialState)
    .handleAction(batchCreateTypes.CREATE_BATCH, state => ({
        ...state,
        isCreatingBatch: true,
        error: '',
    }))
    .handleAction(batchCreateTypes.CREATE_BATCH_SUCCESS, (state, action) => ({
        ...state,
        isCreatingBatch: false,
        isBatchCreated: true,
        batch: action.payload,
    }))
    .handleAction(batchCreateTypes.CREATE_BATCH_ERROR, (state, action) => ({
        ...state,
        isCreatingBatch: false,
        error: action.payload.error,
    }))
    .handleAction(batchCreateTypes.CREATE_BATCH_RESET, state => ({
        ...state,
        batch: initialBatch,
        error: '',
        isBatchCreated: false,
        isCreatingBatch: false,
    }));

export type BatchCreateReducerType = StateType<typeof BatchCreateReducer>;

export default BatchCreateReducer;
