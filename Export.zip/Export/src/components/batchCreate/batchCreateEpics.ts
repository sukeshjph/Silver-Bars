import { of } from 'rxjs';
import { mergeMap, catchError, map, filter } from 'rxjs/operators';
import { combineEpics, Epic } from 'redux-observable';
import { isActionOf } from 'typesafe-actions';
import { BatchCreateActionsType } from './batchCreate.types';
import * as BatchCreateActions from './batchCreateActions';
import { IBatch } from '../../interfaces/globals';
import { getConfig } from '../../common/config';
import http from '../../helpers/http';

const createBatch: Epic<BatchCreateActionsType> = action$ =>
    action$.pipe(
        filter(isActionOf(BatchCreateActions.createBatch)),
        mergeMap(action =>
            http
                .postData(
                    `${getConfig().SdxService}/batchmanagement/batch/create`,
                    action.payload.batch,
                )
                .pipe(
                    map((createdBatch: IBatch) =>
                        BatchCreateActions.createBatchComplete(createdBatch),
                    ),
                    catchError(error => of(BatchCreateActions.createBatchError({ error }))),
                ),
        ),
    );

export default combineEpics(createBatch);
