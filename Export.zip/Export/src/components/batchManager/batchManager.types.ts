import { IBatch } from '../../interfaces/globals';

interface IPCTBatch {
    name: string;
    pctNode: string;
}

export interface IPctModalProps {
    batch: IPCTBatch;
    pctNodeTree: any;
    closePctNodeDialog: () => void;
    fetchPctNodes: () => void;
    saveBatch: Function;
    isFetchingPctNodes: boolean;
    isSavingBatch: boolean;
    pctNodeError: string;    
}

export interface IPctNode {
    depth: number;
    id: string;
    name: string;
    disabled: boolean;
    children: Array<string>;
    parentIndex?: number;
}

export interface IPctModalStateProps {
    expandedNodes: Array<string>;
    selectedNode: any;
    disableTree: boolean;
}

export interface IPCTMapStateProps {
    isFetchingPctNodes: boolean;
    isSavingBatch: boolean;
    pctNodeTree: Array<IPctNode>;
    pctNodeError: string;
}

export interface IPCTDispatchProps {
    fetchPctNodes: () => void;
    saveBatch: (batch: IBatch) => void;
}
