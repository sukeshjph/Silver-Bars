import { NAME } from '../../constants';

// State constants
export const SCENARIO_LIMIT = 40;
export const PATHS_LIMIT = 1;
export const BATCH_SORT_ORDER = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Paths', 'smoketest'];


// Batch action types
export const batchActionTypes = {
    FETCH_BATCHES_AND_SCENARIOS: `${NAME}_FETCH_BATCHES_AND_SCENARIOS`,
    FETCH_BATCHES_AND_SCENARIOS_COMPLETE: `${NAME}_FETCH_BATCHES_AND_SCENARIOS_COMPLETE`,
    FETCH_BATCHES_AND_SCENARIOS_ERROR: `${NAME}_FETCH_BATCHES_AND_SCENARIOS_ERROR`,
    FETCH_BATCHES: `${NAME}_FETCH_BATCHES`,
    FETCH_BATCHES_COMPLETE: `${NAME}_FETCH_BATCHES_COMPLETE`,
    FETCH_BATCHES_ERROR: `${NAME}_FETCH_BATCHES_ERROR`,
    FETCH_PCT_NODES: `${NAME}_FETCH_PCT_NODES`,
    FETCH_PCT_NODES_COMPLETE: `${NAME}_FETCH_PCT_NODES_COMPLETE`,
    FETCH_PCT_NODES_ERROR: `${NAME}_FETCH_PCT_NODES_ERROR`,
    SAVE_BATCH: `${NAME}_SAVE_BATCH`,
    SAVE_BATCH_COMPLETE: `${NAME}_SAVE_BATCH_COMPLETE`,
    SAVE_BATCH_ERROR: `${NAME}_SAVE_BATCH_ERROR`,
    ADD_SCENARIO_TO_BATCH: `${NAME}_ADD_SCENARIO_TO_BATCH`,
    REMOVE_SCENARIO_FROM_BATCH: `${NAME}_REMOVE_SCENARIO_FROM_BATCH`,
};

export const pctNodeRequestBody = {
    'className':'SD_PCT_PORTFOLIO',
    'columns':['BUSINESS_HIERARCHYL0','BUSINESS_HIERARCHYL1'],
    'criteria':[
        {'name':'IS_ACTIVE', 'type':'STRING', 'data':['Y']},
        {'name':'SOURCE_SYSTEM', 'type':'STRING', 'data':['MUREX', 'SABRE']}
    ],
    'options':['Blame', 'Master'],
};