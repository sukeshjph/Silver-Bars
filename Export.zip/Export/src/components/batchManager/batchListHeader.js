/* eslint-disable react/destructuring-assignment  */
import React from 'react';
import PropTypes from 'prop-types';
import CloneIcon from '@material-ui/icons/OpenInNew';
import DeleteIcon from '@material-ui/icons/Delete';
import ClearIcon from '@material-ui/icons/Clear';
import BatchCloneDialog from './batchCloneDialog';

class BatchListHeader extends React.PureComponent {
    static propTypes = {
        heading: PropTypes.string.isRequired,
        added: PropTypes.string,
        removed: PropTypes.string,
        filterText: PropTypes.string.isRequired,
        handleTextChange: PropTypes.func.isRequired,
        removeAllScenariosFromBatch: PropTypes.func,
        cloneBatch: PropTypes.func,
        batches: PropTypes.arrayOf(PropTypes.shape({})),
        disableCloneButton: PropTypes.bool,
        selectedBatch: PropTypes.shape({}),
    };

    constructor(props) {
        super(props);
        this.initialState = {
            filterText: this.props.filterText,
            isCloneDialogOpen: false,
        };
        this.state = this.initialState;
        this.handleFilterTextChange = this.handleFilterTextChange.bind(this);
        this.clearFilterText = this.clearFilterText.bind(this);
        this.handleRemoveAllClick = this.handleRemoveAllClick.bind(this);
        this.toggleCloneDialog = this.toggleCloneDialog.bind(this);
    }

    // If a user navigates between batches in the parent component,
    // we need to be able to clear the value on the filter text input
    componentWillReceiveProps({ filterText }) {
        this.setState({
            filterText,
        });
    }

    handleFilterTextChange(e) {
        this.updateFilterText(e.target.value);
    }

    clearFilterText() {
        this.updateFilterText('');
    }

    updateFilterText(filterText) {
        this.setState(
            {
                filterText,
            },
            this.props.handleTextChange(filterText),
        );
    }

    handleRemoveAllClick() {
        this.clearFilterText();
        this.props.removeAllScenariosFromBatch();
    }

    toggleCloneDialog() {
        this.setState(prevState => ({
            isCloneDialogOpen: !prevState.isCloneDialogOpen,
        }));
    }

    render() {
        return (
            <header className="stress-batch__list__header">
                <h3 className="stress-batch__list__title">{this.props.heading}</h3>
                <div className="stress__dashboard__field">
                    <input
                        type="text"
                        placeholder="Filter scenarios"
                        className="stress__dashboard__input"
                        value={this.state.filterText}
                        onChange={this.handleFilterTextChange}
                    />
                    <button
                        disabled={this.state.filterText === ''}
                        className="stress__dashboard__button stress-batch__list__header__clear-button"
                        onClick={this.clearFilterText}
                        type="button"
                    >
                        <ClearIcon /> Clear
                    </button>
                </div>

                <div className="stress-batch__list__header__actions">
                    {this.props.cloneBatch && this.props.batches && (
                        <div>
                            <button
                                className="stress__dashboard__button stress-batch__list__header__clone-button"
                                onClick={this.toggleCloneDialog}
                                disabled={this.props.disableCloneButton}
                                type="button"
                            >
                                <CloneIcon /> Clone batch
                            </button>
                            {this.state.isCloneDialogOpen && (
                                <BatchCloneDialog
                                    batches={this.props.batches}
                                    cloneBatch={this.props.cloneBatch}
                                    closeCloneDialog={this.toggleCloneDialog}
                                    selectedBatch={this.props.selectedBatch}
                                />
                            )}
                        </div>
                    )}
                    {this.props.removeAllScenariosFromBatch && (
                        <button
                            className="stress__dashboard__button stress-batch__list__header__remove-button"
                            onClick={this.handleRemoveAllClick}
                            type="button"
                        >
                            <DeleteIcon /> Remove all
                        </button>
                    )}

                    {this.props.added && this.props.removed && (
                        <div className="stress__batch__added-removed">
                            <span className="stress__batch__action--added">{this.props.added}</span>
                            <span className="stress__batch__action--removed">
                                {this.props.removed}
                            </span>
                        </div>
                    )}
                </div>
            </header>
        );
    }
}

BatchListHeader.defaultProps = {
    cloneBatch: null,
    batches: null,
    removeAllScenariosFromBatch: null,
    added: null,
    removed: null,
    disableCloneButton: false,
    selectedBatch: null,
};

export default BatchListHeader;
