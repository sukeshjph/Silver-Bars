import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import shortid from 'shortid';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';

class BatchNameTabs extends React.PureComponent {

    static propTypes = {
        batches: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
        setSelectedBatch: PropTypes.func.isRequired,
        selectedBatch: PropTypes.shape({}),
    };

    render() {
        const { batches, selectedBatch, setSelectedBatch } = this.props;
        return (
            <Tabs
                value={ _.get(selectedBatch, 'ukId', batches[0].ukId) }
                onChange={ setSelectedBatch }
                indicatorColor="primary"
                textColor="primary"
                centered
                scrollable
                scrollButtons="auto"
            >
                { _.map(batches, batch => (
                    <Tab key={ shortid.generate() } label={ batch.name } value={ batch.ukId } />
                )) }
            </Tabs>
        );
    }
}

BatchNameTabs.defaultProps = {
    selectedBatch: {},
};

export default BatchNameTabs;