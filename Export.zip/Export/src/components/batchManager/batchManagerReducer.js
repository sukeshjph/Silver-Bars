import orderBy from 'lodash.orderby';
import { batchActionTypes } from './batchManagerConstants';
import reorderBatches from '../../helpers/reorderBatches';
import reorderScenarios from '../../helpers/reorderScenarios';
import { uniq } from '../../helpers/utilities';

const initialState = {
    batches: [],
    scenarios: [],
    batchAudits: [],
    pctNodeTree: {},
    isSavingBatch: false,
    isFetchingBatches: false,
    isFetchingScenarios: false,
    isFetchingPctNodes: false,
    pctNodeError: '',
};

export default (state = initialState, action) => {
    switch (action.type) {
        case batchActionTypes.FETCH_BATCHES:
            return {
                ...state,
                isFetchingBatches: true,
                error: null,
            };
        case batchActionTypes.FETCH_BATCHES_COMPLETE: {
            return {
                ...state,
                isFetchingBatches: false,
                batches: reorderBatches(action.payload.batches),
            };
        }
        case batchActionTypes.FETCH_BATCHES_ERROR: {
            return {
                ...state,
                isFetchingBatches: false,
                error: action.payload.error,
            };
        }
        case batchActionTypes.FETCH_BATCHES_AND_SCENARIOS:
            return {
                ...state,
                isFetchingBatches: true,
                isFetchingScenarios: true,
                error: null,
            };
        case batchActionTypes.FETCH_BATCHES_AND_SCENARIOS_COMPLETE: {
            const { scenarios, pendingScenarios, batches, batchAudits } = action.payload;
            return {
                ...state,
                isFetchingBatches: false,
                isFetchingScenarios: false,
                batches: reorderBatches(batches),
                scenarios: reorderScenarios(scenarios, pendingScenarios, batches),
                batchAudits: orderBy(batchAudits, ['validFrom'], 'desc'),
            };
        }
        case batchActionTypes.FETCH_BATCHES_AND_SCENARIOS_ERROR: {
            return {
                ...state,
                isFetchingBatches: false,
                isFetchingScenarios: false,
                error: action.payload.error,
            };
        }
        case batchActionTypes.SAVE_BATCH:
            return {
                ...state,
                isSavingBatch: true,
            };
        case batchActionTypes.SAVE_BATCH_COMPLETE: {
            // Find corresponding batch in state and update with revised version
            return {
                ...state,
                isSavingBatch: false,
                batches: reorderBatches(action.payload.batches),
                batchAudits: orderBy(action.payload.batchAudits, ['validFrom'], 'desc'),
            };
        }
        case batchActionTypes.SAVE_BATCH_ERROR: {
            return {
                ...state,
                isSavingBatch: false,
                error: action.payload.error,
            };
        }
        case batchActionTypes.FETCH_PCT_NODES:
            return {
                ...state,
                isFetchingPctNodes: true,
                pctNodeError: '',
            };
        case batchActionTypes.FETCH_PCT_NODES_COMPLETE: {
            // Create reference object of PCT nodes
            // It should look like something this when finished:
            // {
            //  rootNodes: ['0'],
            // '0': {
            //     depth: 0,
            //     children: [1], // Indexes for child list items. If undefined, list item will be treated as leaf
            //     id: 0,
            //     name: 'Group',
            // },
            // '1': {
            //     depth: 1,
            //     children: [2,3],
            //     parentIndex: 0, // Index of parent list item
            //     disabled: false, // false by default, disables click event listeners for disabled list items
            //     id: 1,
            //     name: 'Group 1',
            // },
            // '2': {
            //     depth: 2,
            //     children: [4,5],
            //     parentIndex: 1,
            //     disabled: false,
            //     id: 2,
            //     name: 'Group 2',
            // },
            // '3': {
            //     depth: 2,
            //     parentIndex: 1,
            //     children: [4,5,6,7,8,9],
            //     disabled: false,
            //     id: 3,
            //     name: 'Group 3',
            // }

            const pctNodeTree = { rootNodes: [] };
            action.payload.pctData.forEach(dataItem => {
                const nodeIds = dataItem[1].substring(1).split('|');
                const nodeNames = dataItem[2].substring(1).split('|');

                nodeIds.forEach((id, i) => {
                    // Create the node, if it doesn't already exist
                    if (!Object.prototype.hasOwnProperty.call(pctNodeTree, id)) {
                        pctNodeTree[id] = {
                            depth: i,
                            id,
                            name: nodeNames[i],
                            disabled: false,
                            children: [],
                        };
                        if (i > 0) {
                            pctNodeTree[id].parentIndex = i - 1;
                        } else {
                            pctNodeTree.rootNodes = uniq([...pctNodeTree.rootNodes, id]);
                        }
                    }

                    // Update parent node's children reference
                    const parentNodeId = nodeIds[i - 1];
                    if (parentNodeId) {
                        pctNodeTree[parentNodeId].children = uniq([
                            ...pctNodeTree[parentNodeId].children,
                            id,
                        ]);
                    }
                });
            });

            return {
                ...state,
                isFetchingPctNodes: false,
                pctNodeTree,
            };
        }
        case batchActionTypes.FETCH_PCT_NODES_ERROR: {
            return {
                ...state,
                isFetchingPctNodes: false,
                pctNodeError: action.payload.error,
            };
        }
        default:
            return state;
    }
};
