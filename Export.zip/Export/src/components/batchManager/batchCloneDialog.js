/* eslint-disable react/destructuring-assignment  */
import React from 'react';
import PropTypes from 'prop-types';
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Button from '@material-ui/core/Button';

class BatchCloneDialog extends React.PureComponent {

    static propTypes = {
        batches: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
        cloneBatch: PropTypes.func.isRequired,
        closeCloneDialog: PropTypes.func.isRequired,
        selectedBatch: PropTypes.shape({ ukId: PropTypes.string }).isRequired,
    };

    handleClick(ukId) {
        return () => {
            this.props.closeCloneDialog();
            this.props.cloneBatch(ukId);
        };
    }

    render() {
        const { batches, selectedBatch, closeCloneDialog } = this.props;
        return (
            <Dialog className="stress__dialog" open onClose={ closeCloneDialog }>
                <DialogTitle>Copy scenarios from:</DialogTitle>
                <List className="stress__clone-list">
                    { batches.map(batch => (
                        <ListItem
                            button
                            className="stress__clone-list__batch"
                            disabled={ selectedBatch.ukId === batch.ukId }
                            onClick={ this.handleClick(batch.ukId) }
                            key={ batch.id }
                        >
                            <ListItemText primary={ batch.name } />
                        </ListItem>
                    ))}
                </List>
                <Button
                    className="stress__clone-list__cancel"
                    onClick={ closeCloneDialog }
                >
                    Cancel
                </Button>
            </Dialog>
        );
    }
}

export default BatchCloneDialog;