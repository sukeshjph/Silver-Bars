/* eslint-disable react/destructuring-assignment  */
import React from 'react';
import ClearIcon from '@material-ui/icons/Clear';
import filterDataSet from '../../helpers/filterDataSet';

const DataSetFilter: React.FC<{
    actions: {
        handleChange: (filterText: string, data: any) => void;
    };
    model: {
        value: string;
        data: any;
    };
}> = React.memo(({ actions: { handleChange }, model: { data, value } }) => {
    const clearField = () => {
        handleChange('', data);
    };

    const handleChangeDS = evt => {
        const filterText = evt.target.value;
        handleChange(filterText, filterDataSet(filterText, data));
    };

    return (
        <div className="stress__header__search">
            <input
                placeholder="Search"
                label="Filter data set"
                value={value}
                onChange={handleChangeDS}
                className="stress__header__input stress__header__search__input"
            />
            {value && (
                <div className="stress__header__search__clear">
                    <button
                        onClick={clearField}
                        className="stress__header__clear-button"
                        type="button"
                    >
                        <ClearIcon />
                    </button>
                </div>
            )}
        </div>
    );
});

export default DataSetFilter;
