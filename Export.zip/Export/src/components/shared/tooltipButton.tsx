import React, { FunctionComponent } from 'react';
import Tooltip from '@material-ui/core/Tooltip';

type ITooltipProps = {
    id?: string;
    className: string;
    disabled?: boolean;
    clickHandler(e: React.MouseEvent<HTMLElement>): void;
    tooltip: string;
    children: React.ReactNode;
};

const TooltipButton: FunctionComponent<ITooltipProps> = React.memo(
    ({ className = '', id = '', disabled = false, children, tooltip, clickHandler }) => {
        if (disabled) {
            return (
                <button disabled id={id} className={className} type="button">
                    {children}
                </button>
            );
        }
        return (
            <Tooltip title={tooltip}>
                <button id={id} className={className} onClick={clickHandler} type="button">
                    {children}
                </button>
            </Tooltip>
        );
    },
);

export default TooltipButton;
