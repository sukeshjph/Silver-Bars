/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { FunctionComponent, useState } from 'react';
import Divider from '@material-ui/core/Divider';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import { Link } from 'react-router-dom';
import MenuIcon from '@material-ui/icons/MoreVert';
import Tooltip from '@material-ui/core/Tooltip';
import AddCircleIcon from 'mdi-material-ui/FolderPlus';
import BatchCreate from '../batchCreate';
import UserPopover from './userPopover';

const MainMenu: FunctionComponent<{}> = React.memo(() => {
    const [anchorEl, setAnchorEl] = useState(null);
    const [BatchDialog, setBatchDialog] = useState(false);
    const [menuLinks] = useState({
        '/dashboard': 'Dashboard',
        '/batches': 'Batches',
        '/scenarios': 'Scenarios',
        '/inbox': 'Approvals Inbox',
        '/batch-audit': 'Batch Audit',
        '/scenario-audit': 'Scenario Audit',
    });

    const handleMenuClick = event => {
        setAnchorEl(event.currentTarget);
    };

    const handleMenuClose = () => {
        setAnchorEl(null);
    };

    const handleBatchDialogOpen = () => {
        setBatchDialog(true);
    };

    const handleBatchDialogClose = () => {
        setBatchDialog(false);
    };

    return (
        <div className="stress__header__menu">
            {BatchDialog && <BatchCreate closeHandler={handleBatchDialogClose} />}
            <Tooltip
                title="Add Batch"
                placement="bottom"
                enterDelay={100}
                leaveDelay={100}
                classes={{ tooltip: 'stress-left-nav__tooltip' }}
            >
                <button
                    type="button"
                    className="stress__header__button stress__header__action-button"
                    onClick={handleBatchDialogOpen}
                >
                    <AddCircleIcon />
                </button>
            </Tooltip>
            <button
                className="stress__header__button stress__header__menu__button"
                aria-label="Menu"
                onClick={handleMenuClick}
                type="button"
            >
                <MenuIcon />
            </button>
            <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={handleMenuClose}>
                <li>
                    <h4 className="stress__header__menu__title">Market Risk Stress Testing</h4>
                </li>
                {Object.keys(menuLinks).map(menuLinkKey => (
                    <MenuItem onClick={handleMenuClose} className="stress__header__menu__item">
                        <Link to={menuLinkKey} className="stress__header__menu__link">
                            {menuLinks[menuLinkKey]}
                        </Link>
                    </MenuItem>
                ))}
                <Divider />
                <li>
                    <h4 className="stress__header__menu__title">Dataset Downloads</h4>
                </li>
                <MenuItem onClick={handleMenuClose} className="stress__header__menu__item">
                    <Link to="/downloads" className="stress__header__menu__link">
                        MR Reports
                    </Link>
                </MenuItem>
            </Menu>
            <UserPopover />
        </div>
    );
});

export default MainMenu;
