import React from 'react';
import PropTypes from 'prop-types';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import moment from 'moment';
import CalendarIcon from '@material-ui/icons/Event';
import '../../styles/dateRangePicker.scss';
import { DEFAULT_NUMBER_OF_AUDIT_DAYS_DISPLAYED } from '../../constants';

class DateRangePicker extends React.PureComponent {
    constructor(props) {
        super(props);
        this.initialState = {
            validFromDate: moment().subtract(DEFAULT_NUMBER_OF_AUDIT_DAYS_DISPLAYED, 'days'),
            validToDate: moment(),
        };
        this.state = this.initialState;
        this.changeValidFromDateSelection = this.changeValidFromDateSelection.bind(this);
        this.changeValidToDateSelection = this.changeValidToDateSelection.bind(this);
        this.viewLastMonth = this.viewLastMonth.bind(this);
        this.resetDates = this.resetDates.bind(this);
    }

    componentDidMount() {
        const { fetchByDateRange } = this.props;
        const { validFromDate, validToDate } = this.state;
        fetchByDateRange(validFromDate, validToDate);
    }

    changeValidFromDateSelection(date) {
        this.setState({ validFromDate: date });
        const { validToDate } = this.state;
        const { fetchByDateRange } = this.props;
        fetchByDateRange(date, validToDate);
    }

    changeValidToDateSelection(date) {
        const { fetchByDateRange } = this.props;
        this.setState({ validToDate: date });
        const { validFromDate } = this.state;
        fetchByDateRange(validFromDate, date);
    }

    viewLastMonth() {
        const { fetchByDateRange } = this.props;
        const daysInPreviousMonth = moment()
            .subtract(1, 'month')
            .daysInMonth();
        const validFromDate = moment()
            .subtract(1, 'month')
            .date(1);
        const validToDate = moment()
            .subtract(1, 'month')
            .date(daysInPreviousMonth);
        this.setState({ validFromDate, validToDate });
        fetchByDateRange(validFromDate, validToDate);
    }

    resetDates() {
        const { validFromDate, validToDate } = this.initialState;
        const { fetchByDateRange } = this.props;
        this.setState({ validFromDate, validToDate });
        fetchByDateRange(validFromDate, validToDate);
    }

    render() {
        const { validFromDate, validToDate } = this.state;
        return (
            <div className="stress--date-range--container">
                <span className="stress--date-range--label">Date range</span>
                <DatePicker
                    selectsStart
                    selected={validFromDate}
                    onChange={this.changeValidFromDateSelection}
                    isClearable
                    dateFormat="DD/MM/YYYY"
                    className="stress__header__input stress--date-range--from"
                    placeholderText="Start date"
                    maxDate={
                        !validToDate
                            ? moment().subtract(1, 'days')
                            : moment(validToDate).subtract(1, 'days')
                    }
                />
                <span className="stress--date-range--label">to</span>
                <DatePicker
                    selectsEnd
                    selected={validToDate}
                    isClearable
                    onChange={this.changeValidToDateSelection}
                    dateFormat="DD/MM/YYYY"
                    className="stress__header__input stress--date-range--to"
                    placeholderText="End date"
                    minDate={moment(validFromDate).add(1, 'days')}
                    maxDate={this.initialState.validToDate}
                />
                <button
                    onClick={this.resetDates}
                    className="stress__header__action-button stress--date-range--reset"
                    type="button"
                >
                    Reset dates
                </button>
                <button
                    className="stress__header__action-button stress--date-range--last-month"
                    onClick={this.viewLastMonth}
                    type="button"
                >
                    <CalendarIcon />
                    {moment()
                        .subtract(1, 'month')
                        .format('MMMM')}
                </button>
            </div>
        );
    }
}

DateRangePicker.propTypes = {
    fetchByDateRange: PropTypes.func.isRequired,
};

export default DateRangePicker;

export const dateRangeQueryStringGenerator = dates => {
    const { validToDate, validFromDate } = dates;
    const validTo = validToDate ? `&validTo=${validToDate}` : '';
    const validFrom = validFromDate ? `&validFrom=${validFromDate}` : '';
    const asOf = !validFromDate && !validToDate ? 'asOf=ALL' : 'asOf=RANGE';
    return `?${asOf}${validFrom}${validTo}`;
};
