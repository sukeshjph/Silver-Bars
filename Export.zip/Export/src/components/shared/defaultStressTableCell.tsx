import React from 'react';

const DefaultStressTableCell = (column, row) => (
    <td className={ column.className } key={ column.key }>
        { column.formatter ? column.formatter(row[column.key]) : row[column.key] }
    </td>
);

export default DefaultStressTableCell;