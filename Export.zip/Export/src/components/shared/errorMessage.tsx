import React, { FunctionComponent } from 'react';
import ReportIcon from '@material-ui/icons/Report';
import { IErrorTypeProps } from '../../interfaces/globals';

const ErrorMessage: FunctionComponent<IErrorTypeProps> = React.memo(
    ({ showError = true, className = '', important = false, message }) => {
        if (!showError) return null;
        return (
            <div
                className={`stress__error ${className}  ${
                    important ? 'stress__error--important' : ''
                } `}
            >
                <ReportIcon />
                <p>{message}</p>
            </div>
        );
    },
);

export default ErrorMessage;
