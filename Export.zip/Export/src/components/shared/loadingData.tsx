import React from 'react';
import PropTypes from 'prop-types';
import Fade from '@material-ui/core/Fade';

const LoadingData = ({ showLoading, render, delay = '900ms' }) =>
    showLoading ? (
        <Fade
            in={showLoading}
            style={{
                transitionDelay: showLoading ? delay : '0ms',
            }}
            unmountOnExit
        >
            {render()}
        </Fade>
    ) : null;

LoadingData.propTypes = {
    showLoading: PropTypes.bool,
};

LoadingData.defaultProps = {
    showLoading: false,
};

export default LoadingData;
