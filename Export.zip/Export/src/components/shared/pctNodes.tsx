import React, { useState, useEffect } from 'react';
import Divider from '@material-ui/core/Divider';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Checkbox from '@material-ui/core/Checkbox';
import shortid from 'shortid';
import { PCTOptions } from '../../constants';
import { InputMouseEvent } from '../../interfaces/globals';
import { setObjectValues, ObjectWithoutKey } from '../../helpers/utilities';

const PCTNodes: React.FC<{
    handlePCTNodeChange: (nodes: string[]) => void;
    disabled: boolean;
}> = React.memo(({ handlePCTNodeChange, disabled }) => {
    const [PCTNodeOptions, setPCTNodeOptions] = useState(PCTOptions);
    const [AllCheckboxIndeterminate, setAllCheckBoxIndeterminate] = useState(false);

    useEffect(
        () =>
            handlePCTNodeChange(
                Object.keys(PCTNodeOptions).filter(
                    nodeKey => nodeKey !== 'All' && PCTNodeOptions[nodeKey],
                ),
            ),
        [PCTNodeOptions],
    );

    const handleCheckboxChange = (nodeKey: string) => (event: InputMouseEvent) => {
        event.preventDefault();
        const target = event.target as HTMLInputElement;
        const nodeOptions = { ...PCTNodeOptions };
        if (nodeKey === 'All') {
            setPCTNodeOptions(setObjectValues<boolean>(nodeOptions, target.checked));
        } else if (Object.keys(nodeOptions).includes(nodeKey)) {
            nodeOptions[nodeKey] = target.checked;
            const checkNonAllKeys = Object.keys(nodeOptions).filter(op => op !== 'All');

            const areAllSelected = checkNonAllKeys.every(chk => nodeOptions[chk]);
            const allAreUnselected = checkNonAllKeys.every(chk => !nodeOptions[chk]);

            if (areAllSelected) {
                setPCTNodeOptions(setObjectValues<boolean>(nodeOptions, true));
                setAllCheckBoxIndeterminate(false);
                return;
            }

            setPCTNodeOptions(
                allAreUnselected ? setObjectValues<boolean>(nodeOptions, false) : nodeOptions,
            );
            setAllCheckBoxIndeterminate(!allAreUnselected);
        }
    };

    return (
        <List className="stress-PCTNode-list stress__form__input">
            <ListItem className="stress-PCTNode-list-item">
                <Checkbox
                    tabIndex={-1}
                    disableRipple
                    disabled={disabled}
                    onClick={handleCheckboxChange('All')}
                    checked={PCTNodeOptions.All}
                    className={`${
                        PCTNodeOptions.All
                            ? 'stress-PCTNode__checkbox--checked'
                            : 'stress-PCTNode__checkbox'
                    }`}
                    indeterminate={AllCheckboxIndeterminate}
                />
                <ListItemText primary="Select All" />
            </ListItem>
            <Divider />
            {Object.keys(ObjectWithoutKey<boolean>(PCTNodeOptions, 'All')).map(pctNodeKey => (
                <ListItem
                    key={shortid.generate()}
                    className="stress-PCTNode-list-item"
                    role={undefined}
                    disabled={disabled}
                    dense
                    onClick={handleCheckboxChange(pctNodeKey)}
                >
                    <Checkbox
                        tabIndex={-1}
                        disableRipple
                        checked={PCTNodeOptions[pctNodeKey]}
                        className={`${
                            PCTNodeOptions[pctNodeKey]
                                ? 'stress-PCTNode__checkbox--checked'
                                : 'stress-PCTNode__checkbox'
                        }`}
                    />
                    <ListItemText primary={pctNodeKey} />
                </ListItem>
            ))}
        </List>
    );
});

export default PCTNodes;
