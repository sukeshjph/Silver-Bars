/* eslint-disable react/destructuring-assignment, react/no-find-dom-node, jsx-a11y/anchor-is-valid  */
import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { findDOMNode } from 'react-dom';
import { Link } from 'react-router-dom';
import Popover from '@material-ui/core/Popover';
import IdentityIcon from '@material-ui/icons/PermIdentity';
import ExitIcon from '@material-ui/icons/ExitToApp';
import * as Actions from '../../actions';

type UserPopoverState = {
    open: boolean;
    anchorEl: React.ReactElement | null;
    anchorOriginVertical: string;
    anchorOriginHorizontal: string;
    transformOriginVertical: string;
    transformOriginHorizontal: string;
    positionTop: number;
    positionLeft: number;
    anchorReference: string;
};

class UserPopoverElement extends React.PureComponent<
    {
        userDisplayName: string;
        entitlements: string;
        actions: {
            signOut: () => void;
        };
    },
    UserPopoverState
> {
    state: UserPopoverState = {
        open: false,
        anchorEl: null,
        anchorOriginVertical: 'bottom',
        anchorOriginHorizontal: 'center',
        transformOriginVertical: 'top',
        transformOriginHorizontal: 'center',
        positionTop: 200, // Just so the popover can be spotted more easily
        positionLeft: 400, // Same as above
        anchorReference: 'anchorEl',
    };

    button = null;

    handleClickButton = () => {
        this.setState({
            open: true,
            anchorEl: findDOMNode(this.button),
        });
    };

    handleClose = () => {
        this.setState({
            open: false,
        });
    };

    render() {
        const {
            open,
            anchorEl,
            anchorOriginVertical,
            anchorOriginHorizontal,
            transformOriginVertical,
            transformOriginHorizontal,
            positionTop,
            positionLeft,
            anchorReference,
        } = this.state;

        return (
            <span className="stress__header__user-popup">
                {this.props.entitlements && (
                    <span>
                        <button
                            ref={node => {
                                this.button = node;
                            }}
                            className="stress__header__button stress__header__user-popup__button"
                            onClick={this.handleClickButton}
                            type="button"
                        >
                            <IdentityIcon />
                        </button>
                        <Popover
                            className="stress__dialog"
                            open={open}
                            anchorEl={anchorEl}
                            anchorReference={anchorReference}
                            anchorPosition={{ top: positionTop, left: positionLeft }}
                            onClose={this.handleClose}
                            anchorOrigin={{
                                vertical: anchorOriginVertical,
                                horizontal: anchorOriginHorizontal,
                            }}
                            transformOrigin={{
                                vertical: transformOriginVertical,
                                horizontal: transformOriginHorizontal,
                            }}
                        >
                            <p className="stress__header__user-name">
                                <span>Logged in as</span>
                                {`${this.props.userDisplayName.replace(',', ', ')} (${
                                    this.props.entitlements
                                })`}
                            </p>
                            <p className="stress__header__sign-out">
                                <Link
                                    onClick={this.props.actions.signOut}
                                    to="/"
                                    className="stress__button stress__header__sign-out__button"
                                >
                                    <ExitIcon />
                                    Sign out
                                </Link>
                            </p>
                        </Popover>
                    </span>
                )}
            </span>
        );
    }
}

const mapStateToProps = state => ({
    userDisplayName: state.USER.userDisplayName,
    entitlements: state.USER.entitlements,
});
const mapDispatchToProps = dispatch => ({
    actions: bindActionCreators(Object.assign({}, Actions), dispatch),
});

const UserPopover = connect(
    mapStateToProps,
    mapDispatchToProps,
)(UserPopoverElement);

export default UserPopover;
