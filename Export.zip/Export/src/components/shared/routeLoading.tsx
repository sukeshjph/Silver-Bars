import React from 'react';
import PropTypes from 'prop-types';

const RouteLoading = ({ error, pastDelay, retry }) => {
    if (error) {
        return (
            <div className="stress-loading-panel">
                Error!{' '}
                <button onClick={retry} type="button">
                    Retry
                </button>
            </div>
        );
    }
    if (pastDelay) {
        return <div className="stress-loading-panel">Loading...</div>;
    }
    return null;
};

RouteLoading.propTypes = {
    error: PropTypes.bool,
    pastDelay: PropTypes.bool,
    retry: PropTypes.func,
};

RouteLoading.defaultProps = {
    error: false,
    pastDelay: false,
    retry: () => undefined,
};

export default RouteLoading;
