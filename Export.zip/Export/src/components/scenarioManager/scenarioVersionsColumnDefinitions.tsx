import { formatDateTime } from '../../helpers/dateTime';

export default [
    {
        label: 'Active',
        key: 'radio',
    },
    {
        label: 'Compare',
        key: 'compare',
    },
    {
        label: 'Scenario name',
        key: 'name',
        className: 'td-break-word',
    },
    {
        label: 'Description',
        key: 'description',
        className: 'td-break-word',
    },
    {
        label: 'Category',
        key: 'category',
    },
    {
        label: 'Version',
        key: 'activeFileVersion',
    },
    {
        label: 'Updated',
        key: 'validFrom',
        className: 'td-no-wrap',
        formatter: (date) => formatDateTime(date),
        csvFormatter: (date) => `'${date}'`,
    },
    {
        label: 'Updated By',
        key: 'modifiedBy',
    },
    {
        label: 'Comments',
        key: 'comments',
    },
];