/* eslint-disable react/destructuring-assignment,react/button-has-type */
import React, { PureComponent } from 'react';
import shortid from 'shortid';
import _ from 'lodash';
import sortBy from 'lodash.sortby';
import classnames from 'classnames';
import Radio from '@material-ui/core/Radio';
import CompareIcon from '@material-ui/icons/CompareArrows';
import DoneIcon from '@material-ui/icons/Done';
import scenarioVersionsColumnDefinitions from './scenarioVersionsColumnDefinitions';
import ScenarioCompareDialog from '../shared/scenarioCompareDialog';
import defaultStressTableCell from '../shared/defaultStressTableCell';
import ErrorMessage from '../shared/errorMessage';
import { uniq } from '../../helpers/utilities';
import {
    IScenarioMainModel,
    ScenarioActionsFunc,
    IScenarioManagerState,
} from './scenarioMngr.types';

type ScenarioVersionsTableProps = Pick<IScenarioMainModel, 'approvedScenarios'> &
    Pick<ScenarioActionsFunc, 'fetchDiff'> &
    Pick<IScenarioManagerState, 'userCanEdit'> & {
        children: React.ReactNode;
        currentActiveFileVersion: number;
        setActiveFileVersion: () => void;
        isFetchingDiff: boolean;
        hasChangePending: boolean;
        fetchDiffError: string;
        diff: any;
    };

type versionTableStateType = {
    currentlySelected: any;
    comparing: any[];
    inCompareMode: boolean;
    displayError: boolean;
    disableCompareButton: boolean;
};

class ScenarioVersionsTable extends PureComponent<
    ScenarioVersionsTableProps,
    versionTableStateType
> {
    static defaultProps = {
        fetchDiffError: '',
        hasChangePending: false,
        children: null,
    };

    constructor(props) {
        super(props);
        this.state = {
            currentlySelected: null,
            comparing: [],
            inCompareMode: false,
            displayError: false,
            disableCompareButton: true,
        };
        this.setSelected = this.setSelected.bind(this);
        this.compareHandler = this.compareHandler.bind(this);
    }

    setSelected(file) {
        this.setState(
            {
                currentlySelected: file.activeFileVersion,
            },
            () => {
                this.props.setActiveFileVersion(file.activeFileVersion, file.category);
            },
        );
    }

    // Allow maximum of two to be selected, sorted by version number.
    // Don't allow user to compare a version to itself
    addToCompareList(version) {
        const { comparing: oldComparing } = this.state;
        const comparing = sortBy(uniq([version, ...oldComparing].slice(0, 2)), 'activeFileVersion');
        const displayError =
            comparing.length === 2 && comparing[0].category !== _.get(comparing[1], 'category');
        const disableCompareButton = comparing.length !== 2 || displayError;
        this.setState({
            comparing,
            displayError,
            disableCompareButton,
        });
    }

    compareHandler() {
        this.setState(prevState => ({
            inCompareMode: !prevState.inCompareMode,
        }));
    }

    renderTableCell(column, file, userCanEdit) {
        const isSelected =
            file.activeFileVersion ===
            (this.state.currentlySelected || this.props.currentActiveFileVersion);
        const isRadioDisabled = this.props.hasChangePending === true;
        if (column.key === 'radio') {
            if (userCanEdit) {
                return (
                    <td className={column.className} key={column.key}>
                        <Radio
                            disabled={isRadioDisabled}
                            checked={isSelected}
                            onChange={() => this.setSelected(file)}
                            value={file.activeFileVersion.toString()}
                            name="select_file_version"
                            className="stress--version-radio"
                            color="primary"
                        />
                    </td>
                );
            }
            return (
                <td className={column.className} key={column.key}>
                    {isSelected ? <DoneIcon /> : ''}
                </td>
            );
        }
        if (column.key === 'compare') {
            return (
                <td className="stress-table--compare-cell" key={column.key}>
                    <button
                        className="stress__button-secondary stress-table--compare-button"
                        onClick={() => this.addToCompareList(file)}
                    >
                        <CompareIcon className="stress-table--compare-icon" />
                    </button>
                </td>
            );
        }
        return defaultStressTableCell(column, file);
    }

    render() {
        const {
            approvedScenarios,
            userCanEdit,
            diff,
            fetchDiff,
            isFetchingDiff,
            fetchDiffError,
        } = this.props;
        const { inCompareMode, comparing, displayError, disableCompareButton } = this.state;
        const rowClass = id =>
            classnames({
                'stress-table--row': true,
                'stress-table--row_selected': _.includes(_.map(comparing, 'id'), id),
            });
        return (
            <div>
                {displayError && (
                    <ErrorMessage message="You can only compare files with matching categories." />
                )}
                {this.props.children}
                {!this.props.children && (
                    <React.Fragment>
                        <button
                            disabled={disableCompareButton}
                            className="stress__button stress--compare-button"
                            onClick={this.compareHandler}
                        >
                            <CompareIcon /> Compare selected files
                        </button>
                        <table className="stress-table stress__versions-table">
                            <thead>
                                <tr key={shortid.generate()}>
                                    {scenarioVersionsColumnDefinitions.map(column =>
                                        column.key === 'radio' && userCanEdit ? (
                                            <th key={shortid.generate()} />
                                        ) : (
                                            <th key={column.key}>{column.label}</th>
                                        ),
                                    )}
                                </tr>
                            </thead>
                            <tbody>
                                {approvedScenarios.map(file => (
                                    <tr key={file.id} className={rowClass(file.id)}>
                                        {scenarioVersionsColumnDefinitions.map(column =>
                                            this.renderTableCell(column, file, userCanEdit),
                                        )}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </React.Fragment>
                )}

                {inCompareMode && (
                    <ScenarioCompareDialog
                        scenario={comparing[0]}
                        fileVersionToCompare={comparing[1].activeFileVersion}
                        closeHandler={this.compareHandler}
                        fetchDiff={fetchDiff}
                        diff={diff}
                        isFetchingDiff={isFetchingDiff}
                        fetchDiffError={fetchDiffError}
                    />
                )}
            </div>
        );
    }
}

ScenarioVersionsTable.defaultProps = {
    fetchDiffError: '',
    hasChangePending: false,
    children: null,
};

export default ScenarioVersionsTable;
