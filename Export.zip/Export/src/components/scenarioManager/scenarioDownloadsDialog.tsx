/* eslint-disable react/destructuring-assignment,react/button-has-type */
import React from 'react';
import PropTypes from 'prop-types';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import ScenarioDownloadsTable from './scenarioDownloadsTable';

class ScenarioDownloadsDialog extends React.PureComponent {

    constructor(props) {
        super(props);
        props.actions.fetchScenarioDetails(props.model.scenario.ukId);
    }
    
    downloadScenarioFileVersion = (ukId, version) => () => {
        const { activeFileVersion, validFrom, name, pending } = version;
        this.props.actions.downloadScenarioFile({
            ukId,
            name,
            validFrom,
            version: activeFileVersion,
            pending,
        });      
    };
    

    render() {
        const { approvedScenarios, pendingScenarios, scenario } = this.props.model;
        const { cancelHandler } = this.props.actions;
        const fileVersionProps = {
            approvedScenarios,
            pendingScenarios,
            scenario,
            downloadScenarioFileVersion: this.downloadScenarioFileVersion,
        };
        return (
            <Dialog
                maxWidth={ false }
                open
                id="file-version-scenario-dialog"
                className="stress__dialog stress__downloads"
                onClose={ cancelHandler }
            >
                <DialogTitle>{`${scenario.name} downloads`}</DialogTitle>
                <DialogContent>
                    <ScenarioDownloadsTable { ...fileVersionProps } />
                </DialogContent>
                <DialogActions>
                    <button
                        className="stress__button-secondary stress__downloads__cancel"
                        onClick={ cancelHandler }
                    >
                        Close
                    </button>
                </DialogActions>
            </Dialog>
        )
    }
}

ScenarioDownloadsDialog.propTypes = {
    actions: PropTypes.shape({
        cancelHandler: PropTypes.func.isRequired,
        fetchScenarioDetails: PropTypes.func.isRequired,
        downloadScenarioFile: PropTypes.func.isRequired,
    }).isRequired,
    model: PropTypes.shape({
        scenario: PropTypes.shape({
            ukId: PropTypes.string.isRequired,            
        }).isRequired,
        approvedScenarios: PropTypes.array.isRequired,
        pendingScenarios: PropTypes.array.isRequired,
    }).isRequired,
};

export default ScenarioDownloadsDialog;