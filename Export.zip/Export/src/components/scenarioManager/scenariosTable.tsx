import React from 'react';
import sortBy from 'lodash.orderby';
import shortid from 'shortid';
import { Link } from 'react-router-dom';
import Paper from '@material-ui/core/Paper';
import scenarioColumnDefs from './scenarioColumnDefinitions';
import TableHeadWithSorting from '../shared/tableHeadWithSorting'; //eslint-disable-line
import DefaultStressTableCell from '../shared/defaultStressTableCell';
import { IScenario } from '../../interfaces/globals';

type ScenariosTableState = {
    order: 'desc' | 'asc';
    orderBy: string;
    scenarios: IScenario[];    
};

class ScenariosTable extends React.Component<
    {
        scenarios: IScenario[];
        setSelectedScenario: (uId: string) => void;
        selectedScenarioUkId: string;
        downloadScenarioActiveVersion: (scenario: IScenario) => () => void;
        inCompareMode?: boolean;
    },
    ScenariosTableState
> {
    state: ScenariosTableState = {
        order: 'desc',
        orderBy: 'validFrom',
        scenarios: this.props.scenarios || [],
    };

    static getDerivedStateFromProps(nextProps, prevState) {
        if (nextProps.scenarios !== prevState.scenarios) {
            return { scenarios: nextProps.scenarios };
        }

        return null;
    }

    getScenarioTableColumnByKey = (column, scenario) => {
        if (column.key === 'name' && scenario.pending) {
            return (
                <td className="stress--pending-cell" key={shortid.generate()}>
                    {scenario.name}
                    <Link
                        title="A newer version of this scenario is awaiting approval"
                        to="/inbox"
                        className="stress--pending-link"
                    >
                        pending
                    </Link>
                </td>
            );
        }

        if (column.key === 'activeFileVersion') {
            return (
                <td className={column.className} key={shortid.generate()}>
                    <button
                        className="stress__button_link"
                        onClick={this.props.downloadScenarioActiveVersion(scenario)}
                        type="button"
                    >
                        {scenario.activeFileVersion}
                    </button>
                </td>
            );
        }

        return DefaultStressTableCell(column, scenario);
    };

    sortHandler = (event, newOrderBy: string) => {
        const { order, orderBy } = this.state;
        this.setState({
            order: orderBy === newOrderBy && order === 'asc' ? 'desc' : 'asc',
            orderBy: newOrderBy,
        });
    };

    sortScenarios(scenarios: IScenario[]) {
        const { order, orderBy } = this.state;
        return sortBy(scenarios, orderBy, order);
    }

    render() {
        const { setSelectedScenario, selectedScenarioUkId } = this.props;
        const { scenarios, order, orderBy } = this.state;
        return (
            <Paper className="stress-paper">
                <table className="stress-table">
                    <TableHeadWithSorting
                        order={order}
                        orderBy={orderBy}
                        sortHandler={this.sortHandler}
                        columnDefs={scenarioColumnDefs}
                    />
                    <tbody>
                        {this.sortScenarios(scenarios).map(scenario => (
                            <tr
                                tabIndex={-1}
                                key={scenario.ukId}
                                onClick={() => setSelectedScenario(scenario.ukId)}
                                className={`stress-table--row ${
                                    selectedScenarioUkId === scenario.ukId
                                        ? 'stress-table--row_selected'
                                        : ''
                                }`}
                            >
                                {scenarioColumnDefs.map(column =>
                                    this.getScenarioTableColumnByKey(column, scenario),
                                )}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </Paper>
        );
    }
}

export default ScenariosTable;
