/* eslint-disable react/destructuring-assignment,react/button-has-type */
import React from 'react';
import PropTypes from 'prop-types';
import getFormFieldClass from '../../helpers/getFormFieldClass';

class ScenarioNameField extends React.PureComponent {

    static propTypes = {
        scenarioName: PropTypes.string.isRequired,
        handleNameChange: PropTypes.func.isRequired,
        disabled: PropTypes.bool.isRequired,
    };

    static isScenarioNameValid = name => {
        // Name cannot be blank
        if (!name) {
            return false;
        }
        // Only alphanumeric, - or _ characters are acceptable
        const regex = new RegExp(/^[-_\w]*$/gi);
        return regex.test(name);
    };

    static scenarioNameFieldHelpText = (name, nameIsValid) => {
        if (name && !nameIsValid) {
            return 'Name can only contain letters, numbers, - or _ ';
        }
        return 'Required';
    };

    constructor(props) {
        super(props);
        this.initialState = {
            touched: false,
            nameIsValid: props.scenarioName || false,
            name: props.scenarioName || '',
        };
        this.state = this.initialState;
        this.handleNameChange = this.handleNameChange.bind(this);
    }

    componentWillReceiveProps(nextProps) {
        // To handle form undo functionality
        if (nextProps.scenarioName !== this.state.name) {
            this.setState(this.initialState);
        }
    }

    handleNameChange({ target: { value }}) {
        const nameIsValid = ScenarioNameField.isScenarioNameValid(value);
        this.setState({
            touched: true,
            nameIsValid,
            name: value,
        }, () => this.props.handleNameChange(this.state.name, this.state.nameIsValid));
    }

    render() {
        const showErrorState = this.state.touched === true && this.state.nameIsValid === false;
        return (
            <div className={ `stress__add-edit__name ${getFormFieldClass(!showErrorState)}` }>
                <label htmlFor="scenario-name" className="stress__form__label">Scenario name</label>
                <input
                    id="scenario-name"
                    placeholder="Enter scenario name"
                    className="stress__form__input"
                    onChange={ this.handleNameChange }
                    value={ this.state.name }
                    disabled={ this.props.disabled }
                    type="text"
                />
                <p className="stress__form__help-text">
                    { ScenarioNameField.scenarioNameFieldHelpText(this.state.name, this.state.nameIsValid) }
                </p>
            </div>
        )
    }
}

export default ScenarioNameField;