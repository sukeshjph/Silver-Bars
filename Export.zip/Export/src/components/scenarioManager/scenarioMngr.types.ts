import { ActionType } from 'typesafe-actions';
import * as ScenarioActions from './scenarioActions';
import { IScenario, IBatch } from '../../interfaces/globals';

export type ScenarioActionsType = ActionType<typeof ScenarioActions>;

// Component Types
export interface ScenarioActionsFunc {
    fetchBatches: () => void;
    fetchScenarios: () => void;
    fetchScenarioDetails: () => void;
    compileScenarioFileCancel: () => void;
    updateScenario: () => void;
    createScenario: () => void;
    deleteScenario: (scenarioBeingDeleted: string, reason: string) => void;
    downloadScenarioFile: (
        Scenario: Pick<IScenario, 'ukId' | 'name' | 'validFrom' | 'activeFileVersion' | 'pending'>,
    ) => void;
    fetchDiff: () => void;
}

export interface IScenarioMainModel {
    scenarios: IScenario[];
    approvedScenarios: IScenario[];
    pendingScenarios: IScenario[];
    isFetchingScenarios: boolean;
    isFetchingScenarioDetails: boolean;
    isDeletingScenario: boolean;
    scenarioError: string;
}

export interface IBatchesMainModel {
    batches: IBatch[];
    isFetchingBatches: boolean;
}

export interface IScenarioManagerProps {
    actions: ScenarioActionsFunc;
    scenarioModel: IScenarioMainModel;
    batchModel: IBatchesMainModel;
    diffModel: {
        diff: any;
        isFetchingDiff: boolean;
        fetchDiffError: string;
    };
}

export interface IScenarioManagerState {
    scenarioBeingDeleted: string;
    scenarioBeingEdited?: string;
    scenarioBeingDownloaded?: string;
    openEditModal: boolean;
    openFileVersionModal: boolean;
    openFileDownload: boolean;
    openCreateModal: boolean;
    openDeleteModal: boolean;
    deleteMessage: string;
    selectedScenarioUkId: string;
    inCompareMode: boolean;
    filterText: string;
    scenarios: IScenario[];
    userCanEdit?: boolean;
    userIsSuperUser?: boolean;
}
