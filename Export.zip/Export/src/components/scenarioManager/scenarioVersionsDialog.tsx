/* eslint-disable react/destructuring-assignment,react/button-has-type */
import React from 'react';
import PropTypes from 'prop-types';
import CircularProgress from '@material-ui/core/CircularProgress';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import ReasonForChange from '../shared/reasonForChange';
import ScenarioVersionsTable from './scenarioVersionsTable';

class ScenarioVersionsDialog extends React.PureComponent {
    constructor(props) {
        super(props);
        this.state = {};
        this.setActiveFileVersion = this.setActiveFileVersion.bind(this);
        this.saveHandler = this.saveHandler.bind(this);
    }

    componentDidMount() {
        this.props.actions.fetchScenarioDetails(this.props.model.scenario.ukId);
    }

    setActiveFileVersion(selectedFileVersion, selectedFileCategory) {
        this.setState({
            selectedFileVersion,
            selectedFileCategory,
        });
    }

    saveHandler(comments) {
        this.props.actions.updateScenario({
            ...this.props.model.scenario,
            activeFileVersion: this.state.selectedFileVersion,
            category: this.state.selectedFileCategory,
            comments,
        });
    }

    render() {
        const { model } = this.props;
        const {
            scenario: { activeFileVersion },
            userCanEdit,
            isFetchingScenarioDetails,
        } = model;
        const { cancelHandler, doneHandler, fetchDiff } = this.props.actions;
        const { selectedFileVersion } = this.state;
        const showReasonForChange =
            selectedFileVersion && selectedFileVersion !== activeFileVersion && userCanEdit;

        return (
            <Dialog
                maxWidth={false}
                open
                id="stress-scenario-version-dialog"
                className="stress__dialog"
                onClose={cancelHandler}
            >
                <DialogTitle>Scenario file versions</DialogTitle>
                <DialogContent>
                    <ScenarioVersionsTable
                        approvedScenarios={model.approvedScenarios}
                        hasChangePending={model.hasChangePending}
                        currentActiveFileVersion={model.scenario.activeFileVersion}
                        setActiveFileVersion={this.setActiveFileVersion}
                        userCanEdit={model.userCanEdit}
                        fetchDiff={fetchDiff}
                        diff={model.diff}
                        isFetchingDiff={model.isFetchingDiff}
                        fetchDiffError={model.fetchDiffError}
                    >
                        {isFetchingScenarioDetails ? (
                            <CircularProgress style={{ color: '#6ac075' }} />
                        ) : null}
                    </ScenarioVersionsTable>
                    {showReasonForChange && (
                        <ReasonForChange
                            actions={{
                                handleSaveClick: this.saveHandler,
                                handleDoneClick: doneHandler,
                                handleUndoClick: cancelHandler,
                            }}
                            model={{
                                isSaving: model.isSavingScenario,
                                saveSuccessMessage:
                                    'Changes saved and queued for approval. Check Approval Inbox.',
                            }}
                        />
                    )}
                </DialogContent>
                <DialogActions>
                    <button
                        className="stress__button-secondary stress__version-dialog__cancel"
                        onClick={cancelHandler}
                    >
                        Close
                    </button>
                </DialogActions>
            </Dialog>
        );
    }
}

ScenarioVersionsDialog.defaultProps = {
    model: PropTypes.shape({
        fetchDiffError: '',
        hasChangePending: false,
    }),
};

ScenarioVersionsDialog.propTypes = {
    actions: PropTypes.shape({
        updateScenario: PropTypes.func.isRequired,
        cancelHandler: PropTypes.func.isRequired,
        doneHandler: PropTypes.func.isRequired,
        fetchScenarioDetails: PropTypes.func.isRequired,
        fetchDiff: PropTypes.func.isRequired,
    }).isRequired,
    model: PropTypes.shape({
        scenario: PropTypes.shape({
            ukId: PropTypes.string.isRequired,
            activeFileVersion: PropTypes.number.isRequired,
        }).isRequired,
        approvedScenarios: PropTypes.array.isRequired,
        isSavingScenario: PropTypes.bool.isRequired,
        hasChangePending: PropTypes.bool,
        userCanEdit: PropTypes.bool.isRequired,
        isFetchingDiff: PropTypes.bool.isRequired,
        fetchDiffError: PropTypes.string,
        diff: PropTypes.shape({}).isRequired,
    }),
};

export default ScenarioVersionsDialog;
