import { NAME } from '../../constants';

export const localisedHeadings = [
    'scenarioCategory',
    'scenarioType',
    'scenarioName',
    'scenarioAssetClass',
    'scenarioUnderlyingScope',
];
export const commonHeadings = [
    'nodeType',
    'identifier',
    'guard',
    'selector1',
    'selector2',
    'selector3',
    'selector4',
    'selector5',
    'flag',
    'parameter',
    'shock',
];
export const SCENARIO_TAGS = ['Global', 'Localised', 'ESA', 'Reverse', 'Historical', 'Others'];
export const SCENARIO_COMPILATION_STATES = {
    FAILED: 'Failed',
    COMPILED: 'Compiled',
    COMPILEDWITHERRORS: 'CompiledWithErrors',
};
export const SCENARIO_COMPILATION_TYPES = {
    CATEGORY: 'Category',
    FILEUPLOAD: 'File Upload',
};

export const scenarioActionTypes = {
    CREATE_SCENARIO: `${NAME}_CREATE_SCENARIO`,
    CREATE_SCENARIO_COMPLETE: `${NAME}_CREATE_SCENARIO_COMPLETE`,
    CREATE_SCENARIO_ERROR: `${NAME}_CREATE_SCENARIO_ERROR`,
    COMPILE_SCENARIO: `${NAME}_COMPILE_SCENARIO`,
    COMPILE_SCENARIO_COMPLETE: `${NAME}_COMPILE_SCENARIO_COMPLETE`,
    COMPILE_SCENARIO_CANCEL: `${NAME}_COMPILE_SCENARIO_CANCEL`,
    COMPILE_SCENARIO_RESET: `${NAME}_COMPILE_SCENARIO_RESET`,
    COMPILE_SCENARIO_ERROR: `${NAME}_COMPILE_SCENARIO_ERROR`,
    DOWNLOAD_SCENARIO_FILE: `${NAME}_DOWNLOAD_SCENARIO_FILE`,
    DOWNLOAD_SCENARIO_FILE_COMPLETE: `${NAME}_DOWNLOAD_SCENARIO_FILE_COMPLETE`,
    DOWNLOAD_SCENARIO_FILE_ERROR: `${NAME}_DOWNLOAD_SCENARIO_FILE_ERROR`,
    DELETE_SCENARIO: `${NAME}_DELETE_SCENARIO`,
    DELETE_SCENARIO_COMPLETE: `${NAME}_DELETE_SCENARIO_COMPLETE`,
    DELETE_SCENARIO_ERROR: `${NAME}_DELETE_SCENARIO_ERROR`,
    FETCH_SCENARIOS: `${NAME}_FETCH_SCENARIOS`,
    FETCH_SCENARIOS_COMPLETE: `${NAME}_FETCH_SCENARIOS_COMPLETE`,
    FETCH_SCENARIOS_ERROR: `${NAME}_FETCH_SCENARIOS_ERROR`,
    FETCH_SCENARIO: `${NAME}_FETCH_SCENARIO`,
    FETCH_SCENARIO_COMPLETE: `${NAME}_FETCH_SCENARIO_COMPLETE`,
    FETCH_SCENARIO_ERROR: `${NAME}_FETCH_SCENARIO_ERROR`,
    SEARCH_SCENARIO: `${NAME}_SEARCH_SCENARIO`,
    SEARCH_SCENARIO_COMPLETE: `${NAME}_SEARCH_SCENARIO_COMPLETE`,
    SEARCH_SCENARIO_ERROR: `${NAME}_SEARCH_SCENARIO_ERROR`,
    UPDATE_SCENARIO: `${NAME}_UPDATE_SCENARIO`,
    UPDATE_SCENARIO_COMPLETE: `${NAME}_UPDATE_SCENARIO_COMPLETE`,
    UPDATE_SCENARIO_ERROR: `${NAME}_UPDATE_SCENARIO_ERROR`,
};

export const filePicker = 'stress__add-edit__file-picker';

export const VersionTypes = {
    CurrentVersion: 'currentActiveFileVersion',
    ActiveFileVersion: 'activeFileVersion',
} as const;