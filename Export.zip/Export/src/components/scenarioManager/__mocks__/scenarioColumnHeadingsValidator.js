const scenarioColumnHeadingsValidator = jest.fn(() => ({
    isValid: true,
    localisedHeadingsError: false,
    commonHeadingsError: false,
}));

export default scenarioColumnHeadingsValidator;