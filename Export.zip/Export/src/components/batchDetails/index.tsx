/* eslint-disable react/destructuring-assignment  */
// @ts-nocheck
import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import queryString from 'query-string';
import _ from 'lodash';
import sortBy from 'lodash.sortby';
import { withRouter, RouteComponentProps } from 'react-router-dom';
import moment from 'moment';
import ReportIcon from '@material-ui/icons/Report';
import Grid from '@material-ui/core/Grid';
import SnackbarContent from '@material-ui/core/SnackbarContent';
import { RootState } from 'typesafe-actions';
import EditPctNodeIcon from 'mdi-material-ui/SquareEditOutline';
import ClearIcon from '@material-ui/icons/Event';
import { formatDateTime } from '../../helpers/dateTime';
import { readWrite } from '../../helpers/authentication';
import ReasonForChange from '../shared/reasonForChange';
import { API_DATE_FORMAT } from '../../constants';
import { SCENARIO_LIMIT, PATHS_LIMIT, ScenarioListTypes } from './batchDetailsConstants';
import * as BatchDetailsActions from './batchDetailsActions';
import BatchLinksHeader from '../shared/batchHeaderLinks';
import BatchListHeader from './batchListHeader';
import BatchListAvailableScenario from './batchListAvailableScenario';
import BatchListSelectedScenario from './batchListSelectedScenario';
import BatchCoBDate from './batchCoBDate';
import { BatchPctNodeModalConnected as BatchPctNodeModal } from './batchPctNodeModal';
import ErrorMessage from '../shared/errorMessage';
import filterDataSet from '../../helpers/filterDataSet';
import LoadingData from '../shared/loadingData';
import { IBatchDetailsMainState, IBatchDetailsMainProps } from './batchDetails.types';
import { IBatch, IScenario } from '../../interfaces/globals';
import { get } from '../../helpers/utilities';
import { getConfig } from '../../common/config';

import './batchDetails.scss';

export class BatchDetails extends React.Component<
    RouteComponentProps<{}> & IBatchDetailsMainProps,
    IBatchDetailsMainState
> {
    static getBatchAsOf(querystr) {
        const { asOf, cutOff = `${getConfig().asOfTime}` } = queryString.parse(querystr);
        if (asOf) {
            if (asOf.toLowerCase() === 'now') {
                return { asOf, isPastbatch: false };
            }
        }

        if (moment().date() - moment(asOf as string).date() === 0) {
            const gmtCutOff = moment.utc(`${moment().format('YYYY-MM-DD')} ${cutOff}`);
            return gmtCutOff.isAfter(moment.utc())
                ? { asOf, isPastbatch: false }
                : {
                    asOf: `${moment(asOf).format('YYYY-MM-DD')} ${getConfig().asOfTime}`,
                    isPastbatch: true,
                };
        }

        return { asOf, isPastbatch: moment(asOf as string).isBefore(moment()) };
    }

    constructor(props) {
        super(props);
        this.initialState = {
            removed: 0,
            added: 0,
            limit: SCENARIO_LIMIT,
            availableFilterText: '',
            deltaFilterText: '',
            scenarioDelta: [],
            availableScenarios: [],
            saveCompleted: false,
            isSavingBatch: false,
            isEditingPctNodes: false,
            isPctNodeClear: false,
            batchAsOf: BatchDetails.getBatchAsOf(this.props.location.search),
            hasError: false,
            selectedBatch: {},
            showGMTMessage: false,
            userCanEdit: false,
        };
        this.state = this.initialState;
        this.setSelectedBatch = this.setSelectedBatch.bind(this);
        this.removeScenarioFromBatch = this.removeScenarioFromBatch.bind(this);
        this.addScenarioToBatch = this.addScenarioToBatch.bind(this);
        this.handleSaveClick = this.handleSaveClick.bind(this);
        this.handleUndoClick = this.handleUndoClick.bind(this);
        this.handleDoneClick = this.handleDoneClick.bind(this);
        this.handleAvailableFilterTextChange = this.handleAvailableFilterTextChange.bind(this);
        this.handleDeltaFilterTextChange = this.handleDeltaFilterTextChange.bind(this);
        this.removeAllScenariosFromBatch = this.removeAllScenariosFromBatch.bind(this);
        this.handleCoBDateChange = this.handleCoBDateChange.bind(this);
        this.handleUndoCoBDateChange = this.handleUndoCoBDateChange.bind(this);
        this.togglePctNodeModal = this.togglePctNodeModal.bind(this);
        this.cloneBatch = this.cloneBatch.bind(this);
    }

    componentDidMount() {
        const {
            actions: { fetchBatchAndScenarios },
            match: {
                params: { batchId },
            },
        } = this.props;

        const {
            batchAsOf: { asOf = moment().format('YYYY-MM-DD') },
        } = this.state;

        fetchBatchAndScenarios(batchId, asOf);
    }

    // Remove this method and replace with getDerivedStatetoprops and componentDidupdate
    componentWillReceiveProps(nextProps) {
        const {
            model: { batch, isSavingBatch },
        } = nextProps;

        if (Object.keys(batch).length > 0 && batch !== this.props.model.batch) {
            this.setState(
                {
                    selectedBatch: batch,
                    userCanEdit: readWrite(),
                },
                this.updateAddedAndRemovedList,
            );
        }

        if (nextProps.location !== this.props.location) {
            const {
                actions: { fetchBatchAndScenarios },
                location: { search },
                match: {
                    params: { batchId },
                },
            } = nextProps;

            this.setState(
                {
                    batchAsOf: BatchDetails.getBatchAsOf(search),
                },
                () => {
                    const {
                        batchAsOf: { asOf = moment().format('YYYY-MM-DD') },
                    } = this.state;
                    fetchBatchAndScenarios(batchId, asOf);
                },
            );
        }

        if (isSavingBatch !== this.state.isSavingBatch) {
            this.setState(prevState => ({
                isSavingBatch,
                saveCompleted: isSavingBatch === false && prevState.isSavingBatch === true,
            }));
        }
    }

    /**
     * Get batch from store
     * @param batch
     */
    setSelectedBatch(e?: any, batchUkId?: string) {
        const selectedBatch = this.getBatchFromStore(batchUkId);
        if (selectedBatch) {
            this.setState(
                {
                    ...this.initialState,
                    selectedBatch,
                    limit: selectedBatch.name === 'Paths' ? PATHS_LIMIT : SCENARIO_LIMIT,
                    availableFilterText: '',
                    deltaFilterText: '',
                } as IBatchDetailsMainState,
                this.updateAddedAndRemovedList,
            );
        }
    }

    getBatchFromStore(batchUkId = ''): IBatch {
        if (batchUkId) {
            return this.props.model.batches.find(batch => batch.ukId === batchUkId) as IBatch;
        }
        return this.props.model.batch;
    }

    getBatchInfo = ({ validFrom, modifiedBy, comments }) => {
        const batchInfoList = {
            'Updated:': formatDateTime(validFrom),
            'Updated by:': modifiedBy,
            'Comments:': `"${comments}"`,
        };
        return (
            <div className="stress-batch__dashboard__item">
                {Object.keys(batchInfoList).map(itemKey => (
                    <div className="stress-batch__dashboard__row">
                        <h4 className="stress-batch__info__title">{itemKey}</h4>
                        <span>{batchInfoList[itemKey]}</span>
                    </div>
                ))}
            </div>
        );
    };

    // Render formatted scenario name and version number
    getScenarioDisplayName = scenario => `${scenario.name} (v.${scenario.activeFileVersion})`;

    getTopHeader = (selectedBatch, isFetchingBatch) => {
        const {
            batchAsOf: { asOf, isPastbatch },
        } = this.state;

        let titleHeader = '';

        if (isFetchingBatch) {
            titleHeader = 'Loading Batch details';
        } else {
            titleHeader = !this.isEmptyBatch()
                ? `${selectedBatch.name}${
                    isPastbatch ? `(${moment(asOf).format('Do-MMM-YYYY')})` : ''
                }`
                : '';
        }
        return <BatchLinksHeader navHeaderTitle={titleHeader} />;
    };

    createAddScenarioToBatchHandler = (scenario: IScenario) => () =>
        this.addScenarioToBatch(scenario);

    createRemoveScenarioFromBatchHandler = (scenario: IScenario) => () =>
        this.removeScenarioFromBatch(scenario);

    hasCoBDateChanged = () => {
        const prevUnChangedBatch = this.getBatchFromStore();
        if (prevUnChangedBatch) {
            return this.state.selectedBatch.cobDate !== prevUnChangedBatch.cobDate;
        }
        return false;
    };

    handleClearPCTNodeClick = () => {
        const {
            actions: { saveBatch },
        } = this.props;
        this.setState({ isPctNodeClear: true }, () => {
            saveBatch({
                ...this.state.selectedBatch,
                pctNode: null,
                pctNodeId: null,
                comments: `Deleting the current PCT node ${this.state.selectedBatch.pctNode}`,
            });
        });
    };

    isEmptyBatch = () =>
        Object.keys(this.state.selectedBatch).length === 0 && !this.props.model.isFetchingBatch;

    hasGMTTimePassed = () => {
        const {
            location: { search },
        } = this.props;

        const { asOf, cutOff = `${getConfig().asOfTime}` } = queryString.parse(search);

        if (asOf) {
            if (asOf.toLowerCase() === 'now') {
                return false;
            }
        }

        if (moment().date() - moment(asOf).date() === 0) {
            const gmtCutOff = moment.utc(`${moment().format('YYYY-MM-DD')} ${cutOff}`);
            return moment.utc().isAfter(gmtCutOff);
        }

        return false;
    };

    initialState: IBatchDetailsMainState;

    componentDidCatch(error: string, info: string) {
        this.setState({ hasError: true });
        console.log(`Error:${error} and info:${info}`); // eslint-disable-line
    }

    /**
     * Save the updated batch if the input form is valid
     */
    handleSaveClick(comments) {
        const {
            actions: { saveBatch },
            match: {
                params: { batchId },
            },
        } = this.props;

        if (this.hasGMTTimePassed()) {
            const selectedBatch = this.getBatchFromStore(batchId);
            this.setState(
                {
                    ...this.initialState,
                    selectedBatch,
                    limit: selectedBatch.name === 'Paths' ? PATHS_LIMIT : SCENARIO_LIMIT,
                    availableFilterText: '',
                    deltaFilterText: '',
                    showGMTMessage: true,
                },
                this.updateAddedAndRemovedList,
            );
        } else {
            this.setState({ isPctNodeClear: false, showGMTMessage: false }, () => {
                saveBatch({
                    ...this.state.selectedBatch,
                    comments,
                });
            });
        }
    }

    /**
     * Revert selected batch to its previous state
     */
    handleUndoClick() {
        this.setSelectedBatch();
    }

    /**
     *
     */
    handleDoneClick() {
        this.setSelectedBatch();
        this.setState({ saveCompleted: false });
    }

    handleAvailableFilterTextChange(availableFilterText) {
        this.setState({
            availableFilterText,
        });
    }

    handleDeltaFilterTextChange(deltaFilterText) {
        this.setState({
            deltaFilterText,
        });
    }

    handleCoBDateChange(cobDate) {
        this.setState(prevState => ({
            selectedBatch: {
                ...prevState.selectedBatch,
                cobDate: cobDate ? moment(cobDate).format(API_DATE_FORMAT) : null,
            },
        }));
    }

    handleUndoCoBDateChange() {
        this.setState(prevState => ({
            selectedBatch: {
                ...prevState.selectedBatch,
                cobDate: this.getBatchFromStore().cobDate,
            },
        }));
    }

    hasErrorOccurred() {
        const { model } = this.props;
        const { hasError } = this.state;
        if (hasError) return true;
        return model.error && (model.batches.length === 0 || model.scenarios.length === 0);
    }

    hasLoaded() {
        const { model } = this.props;
        return !model.error && !model.isFetchingBatches && model.scenarios.length > 0;
    }

    // Update state to reflect scenario changes in selected batch
    // The difference between state and store will result in
    // the Reason For Change form being displayed
    removeScenarioFromBatch(scenarioToRemove) {
        const { selectedBatch, userCanEdit } = this.state;

        // Ensure user has write permissions
        if (!userCanEdit) {
            return false;
        }

        const scenarios = _.filter(
            selectedBatch.scenarios,
            scenario => scenario.ukId !== scenarioToRemove.ukId,
        );

        this.setState(
            {
                selectedBatch: {
                    ...selectedBatch,
                    scenarios,
                },
            },
            this.updateAddedAndRemovedList,
        );

        return scenarios;
    }

    removeAllScenariosFromBatch() {
        const { selectedBatch, userCanEdit } = this.state;

        // Ensure user has write permissions
        if (userCanEdit) {
            this.setState(
                {
                    selectedBatch: {
                        ...selectedBatch,
                        scenarios: [],
                    },
                },
                this.updateAddedAndRemovedList,
            );
        }
    }

    // Update state to reflect scenario changes in selected batch
    // The difference between state and store will result in
    // the Reason For Change form being displayed
    addScenarioToBatch(scenario) {
        const {
            selectedBatch,
            userCanEdit,
        }: { selectedBatch: NonNullable<Partial<IBatch>>; userCanEdit: boolean } = this.state;

        // Ensure user has write permissions
        if (!userCanEdit) {
            return false;
        }

        // Ensure user isn't breaching the maximum scenario file limit
        if (selectedBatch.scenarios.length === this.state.limit) {
            return false;
        }

        // If scenario param is an array, assume this is a batch rewrite
        // and all scenarios in selected batch are being replaced
        const scenarios = Array.isArray(scenario)
            ? scenario
            : [...selectedBatch.scenarios, scenario];

        this.setState(
            {
                selectedBatch: {
                    ...selectedBatch,
                    scenarios: scenarios.map(sce => {
                        if (sce.tags)
                            return Array.isArray(sce.tags)
                                ? { ...sce, tags: sce.tags.join(', ') }
                                : sce;
                        return sce;
                    }),
                },
            },
            this.updateAddedAndRemovedList,
        );

        return scenarios;
    }

    // Copy scenarios from a different batch to the selected batch
    cloneBatch(batchUkId: string) {
        const { selectedBatch, userCanEdit } = this.state;
        if (userCanEdit && selectedBatch) {
            const prevBatchInState = this.getBatchFromStore(batchUkId);
            if (prevBatchInState) {
                this.setState(
                    {
                        selectedBatch: {
                            ...selectedBatch,
                            scenarios: prevBatchInState.scenarios,
                        },
                    },
                    this.updateAddedAndRemovedList,
                );
            }
        }
    }

    // Iterate each scenario in state
    // If a scenario exists in the store but not in state, it has been removed
    // from the selected batch
    // If a scenario exists in state and not in store it has been added
    // to the selected batch
    updateAddedAndRemovedList() {
        const {
            batchAsOf: { isPastbatch },
        } = this.state;
        let removed = 0;
        let added = 0;

        const everyScenario = this.props.model.scenarios;
        const scenariosInBatchBeforeEditing = this.getBatchFromStore().scenarios;
        const scenariosInBatchCurrently = isPastbatch
            ? scenariosInBatchBeforeEditing
            : _.filter(
                this.state.selectedBatch.scenarios,
                scenario => new Date(scenario.validTo) > new Date(),
            );
        const availableScenarios = _.differenceBy(everyScenario, scenariosInBatchCurrently, 'ukId');

        const scenarioDelta = sortBy(
            everyScenario
                .map(scenario => {
                    const existsInOriginal = _.find(scenariosInBatchBeforeEditing, {
                        ukId: scenario.ukId,
                    });
                    const existsInUpdated = _.find(scenariosInBatchCurrently, {
                        ukId: scenario.ukId,
                    });
                    if (existsInOriginal && !existsInUpdated) {
                        removed += 1;
                        return {
                            ...scenario,
                            userAction: 'removed',
                        };
                    }
                    if (!existsInOriginal && existsInUpdated) {
                        added += 1;
                        return {
                            ...scenario,
                            userAction: 'added',
                        };
                    }
                    if (existsInOriginal) {
                        return {
                            ...scenario,
                        };
                    }
                    return false;
                })
                .filter(val => val),
            ['userAction', 'name'],
        );

        this.setState({
            removed,
            added,
            scenarioDelta,
            availableScenarios,
        });
    }

    isLoading() {
        const { model } = this.props;
        return model.isFetchingBatches || model.isFetchingScenarios;
    }

    isReasonForChangeVisible() {
        const {
            added,
            removed,
            saveCompleted,
            isPctNodeClear,
            batchAsOf: { isPastbatch },
        } = this.state;

        if (this.hasGMTTimePassed()) return false;

        if (isPastbatch) {
            return false;
        }
        return (
            added > 0 ||
            removed > 0 ||
            (!isPctNodeClear && saveCompleted) ||
            this.hasCoBDateChanged()
        );
    }

    togglePctNodeModal() {
        this.setState(prevState => ({
            isEditingPctNodes: !prevState.isEditingPctNodes,
        }));
    }

    render() {
        const {
            model,
            match: {
                params: { batchId },
            },
        } = this.props;
        const {
            scenarioDelta,
            selectedBatch,
            added,
            removed,
            limit,
            availableFilterText,
            deltaFilterText,
            availableScenarios,
            userCanEdit,
            isEditingPctNodes,
            batchAsOf: { isPastbatch, asOf },
            showGMTMessage,
        } = this.state;

        return (
            <section id="stress-batches" className="stress-ui-container">
                {this.getTopHeader(selectedBatch, model.isFetchingBatch)}
                <LoadingData
                    showLoading={this.isLoading()}
                    render={() => <div className="stress-loading" />}
                />
                {this.hasErrorOccurred() && (
                    <ErrorMessage message="Sorry, an unexpected error has occurred." />
                )}

                {this.hasLoaded() && (
                    <Grid container>
                        {!this.isEmptyBatch() && (
                            <Grid
                                item
                                xs={12}
                                sm={12}
                                className="stress-batch__dashoboard-grid-item"
                            >
                                <div className="stress-batch__dashboard">
                                    <BatchCoBDate
                                        editable={userCanEdit && !isPastbatch}
                                        batchName={selectedBatch.name}
                                        batchCoBDate={selectedBatch.cobDate}
                                        handleCoBDateChange={this.handleCoBDateChange}
                                        handleUndoCoBDateChange={this.handleUndoCoBDateChange}
                                        hasCoBDateChanged={this.hasCoBDateChanged()}
                                    >
                                        <div className="stress-batch__dashboard__row">
                                            <h4 className="stress-batch__dashboard__item__title">
                                                PCT Node:
                                            </h4>{' '}
                                            <div className="stress__dashboard__field">
                                                {' '}
                                                <p className="stress-batch__dashboard__item__value stress-batch__PCT_Node_Name">
                                                    {selectedBatch.pctNode
                                                        ? selectedBatch.pctNode
                                                        : 'default'}{' '}
                                                </p>{' '}
                                                <button
                                                    className="stress-batch__edit-pct-button stress__dashboard__button"
                                                    onClick={this.togglePctNodeModal}
                                                    type="button"
                                                >
                                                    <EditPctNodeIcon />
                                                    Edit
                                                </button>
                                                <button
                                                    className="stress__dashboard__button"
                                                    onClick={this.handleClearPCTNodeClick}
                                                    type="button"
                                                >
                                                    <ClearIcon />
                                                    Clear
                                                </button>
                                            </div>
                                        </div>
                                    </BatchCoBDate>
                                    {this.getBatchInfo(selectedBatch)}
                                    {isEditingPctNodes && (
                                        <BatchPctNodeModal
                                            batch={selectedBatch}
                                            closePctNodeDialog={() =>
                                                this.setState({ isEditingPctNodes: false })
                                            }
                                        />
                                    )}
                                </div>
                            </Grid>
                        )}

                        {!this.isEmptyBatch() && (
                            <Grid item xs={12} sm={6} className="stress-batch__list-grid-item">
                                <BatchListHeader
                                    heading="Available scenarios"
                                    filterText={this.state.availableFilterText}
                                    handleTextChange={this.handleAvailableFilterTextChange}
                                    cloneBatch={this.cloneBatch}
                                    batches={model.batches}
                                    isPastBatch={isPastbatch}
                                    selectedBatch={selectedBatch}
                                    disableCloneButton={
                                        selectedBatch.name === 'Paths' && isPastbatch
                                    }
                                    ScenariosType={ScenarioListTypes.Available}
                                />
                                <ul className="stress-batch__list">
                                    {filterDataSet(
                                        availableFilterText,
                                        availableScenarios,
                                        'name',
                                    ).map(scenario => (
                                        <BatchListAvailableScenario
                                            key={scenario.id}
                                            scenario={scenario}
                                            limitReached={
                                                selectedBatch.scenarios.length === this.state.limit
                                            }
                                            isPastBatch={isPastbatch}
                                            displayName={this.getScenarioDisplayName(scenario)}
                                            addScenarioToBatch={this.createAddScenarioToBatchHandler(
                                                scenario,
                                            )}
                                        />
                                    ))}
                                </ul>
                            </Grid>
                        )}

                        {!this.isEmptyBatch() && (
                            <Grid item xs={12} sm={6}>
                                <BatchListHeader
                                    heading={`${
                                        get(selectedBatch, 'scenarios', []).length
                                    } selected (maximum of ${limit})`}
                                    added={`Added ${added}`}
                                    removed={`Removed ${removed}`}
                                    isPastBatch={isPastbatch}
                                    filterText={this.state.deltaFilterText}
                                    handleTextChange={this.handleDeltaFilterTextChange}
                                    removeAllScenariosFromBatch={this.removeAllScenariosFromBatch}
                                    ScenariosType={ScenarioListTypes.Added}
                                />
                                <ul className="stress-batch__list stress-batch__list_delta">
                                    {filterDataSet(deltaFilterText, scenarioDelta, 'name').map(
                                        scenario => (
                                            <BatchListSelectedScenario
                                                key={scenario.id}
                                                userAction={scenario.userAction}
                                                isPastBatch={isPastbatch}
                                                displayName={this.getScenarioDisplayName(scenario)}
                                                removeScenarioFromBatch={this.createRemoveScenarioFromBatchHandler(
                                                    scenario,
                                                )}
                                            />
                                        ),
                                    )}
                                </ul>
                                {this.isReasonForChangeVisible() && (
                                    <div>
                                        <ReasonForChange
                                            actions={{
                                                handleSaveClick: this.handleSaveClick,
                                                handleUndoClick: this.handleUndoClick,
                                                handleDoneClick: this.handleDoneClick,
                                            }}
                                            model={{
                                                isSaving: model.isSavingBatch,
                                            }}
                                        />
                                        {selectedBatch.name === 'Paths' && (
                                            <ErrorMessage message="The PATHS batch must contain a scenario with Cortex paths file attached to it. Using the incorrect paths file can lead to a failure of the stress run." />
                                        )}
                                    </div>
                                )}
                            </Grid>
                        )}

                        {this.isEmptyBatch() && (
                            <SnackbarContent
                                className="stress-batch-no-batch-error"
                                message={
                                    <div className="error-panel">
                                        <ReportIcon />
                                        <span className="error-msg">{`No Batch was found with asOf = '${moment(
                                            asOf,
                                        ).format(
                                            'DD/MMM/YYYY',
                                        )}' and BatchUkId = ${batchId}`}</span>
                                    </div>
                                }
                            />
                        )}
                        {showGMTMessage && (
                            <SnackbarContent message="Today’s Batch is not editable beyond 5AM GMT" />
                        )}
                    </Grid>
                )}
            </section>
        );
    }
}

export const BatchDetailsConnected = withRouter(
    connect(
        (state: RootState) => ({ model: state.BATCH_DETAILS }),
        dispatch => ({ actions: bindActionCreators(BatchDetailsActions, dispatch) }),
    )(BatchDetails),
);
