import orderBy from 'lodash.orderby';
import { createReducer, StateType } from 'typesafe-actions';
import * as BatchDetailsActions from './batchDetailsActions';
import { BatchDetailsRootActions, IBatchDetailsReducerState } from './batchDetails.types';
import reorderBatches from '../../helpers/reorderBatches';
import reorderScenarios from '../../helpers/reorderScenarios';
import { uniq } from '../../helpers/utilities';

const initialState = {
    batch: {},
    batches: [],
    scenarios: [],
    batchAudits: [],
    pctNodeTree: {},
    isSavingBatch: false,
    isFetchingBatch: false,
    isFetchingScenarios: false,
    isFetchingPctNodes: false,
    pctNodeError: '',    
} as IBatchDetailsReducerState;

const DetailsReducer = createReducer<IBatchDetailsReducerState, BatchDetailsRootActions>(
    initialState,
)
    .handleAction(BatchDetailsActions.fetchBatchAndScenarios, state => ({
        ...state,
        isFetchingBatch: true,
        isFetchingScenarios: true,
        error: null,
    }))
    .handleAction(BatchDetailsActions.fetchBatchAndScenariosComplete, (state, action) => {
        const { scenarios, pendingScenarios, batch, batchAudits, batches } = action.payload;
        return {
            ...state,
            isFetchingBatch: false,
            isFetchingScenarios: false,
            batch,
            batches: reorderBatches(batches),
            scenarios: reorderScenarios(scenarios, pendingScenarios, batches),
            batchAudits: orderBy(batchAudits, ['validFrom'], 'desc'),
        };
    })
    .handleAction(BatchDetailsActions.fetchBatchAndScenariosError, (state, action) => ({
        ...state,
        isFetchingBatch: false,
        isFetchingScenarios: false,
        error: action.payload.error,
    }))
    .handleAction(BatchDetailsActions.saveBatch, state => ({
        ...state,
        isSavingBatch: true,
    }))
    .handleAction(BatchDetailsActions.saveBatchComplete, (state, action) => ({
        ...state,
        isSavingBatch: false,
        batch: action.payload.batch,
    }))
    .handleAction(BatchDetailsActions.saveBatchError, (state, action: any) => ({
        ...state,
        isSavingBatch: false,
        error: action.payload.error,
    }))
    .handleAction(BatchDetailsActions.fetchPctNodes, state => ({
        ...state,
        isFetchingPctNodes: true,
        pctNodeError: '',
    }))
    .handleAction(BatchDetailsActions.fetchPctNodesComplete, (state, action) => {
        const pctNodeTree = { rootNodes: [] as any[] };
        action.payload.pctData.forEach(dataItem => {
            const nodeIds = dataItem[1].substring(1).split('|');
            const nodeNames = dataItem[2].substring(1).split('|');

            nodeIds.forEach((id, i) => {
                // Create the node, if it doesn't already exist
                if (!Object.prototype.hasOwnProperty.call(pctNodeTree, id)) {
                    pctNodeTree[id] = {
                        depth: i,
                        id,
                        name: nodeNames[i],
                        disabled: false,
                        children: [],
                    };
                    if (i > 0) {
                        pctNodeTree[id].parentIndex = i - 1;
                    } else {
                        pctNodeTree.rootNodes = uniq([...pctNodeTree.rootNodes, id]);
                    }
                }

                // Update parent node's children reference
                const parentNodeId = nodeIds[i - 1];
                if (parentNodeId) {
                    pctNodeTree[parentNodeId].children = uniq([
                        ...pctNodeTree[parentNodeId].children,
                        id,
                    ]);
                }
            });
        });

        return {
            ...state,
            isFetchingPctNodes: false,
            pctNodeTree,
        };
    })
    .handleAction(BatchDetailsActions.fetchPctNodesError, (state, action) => ({
        ...state,
        isFetchingPctNodes: false,
        pctNodeError: action.payload.error,
    }));

export type DetailsReducerType = StateType<typeof DetailsReducer>;

export default DetailsReducer;
