import React, { FunctionComponent } from 'react';
import RemoveIcon from '@material-ui/icons/Remove';

type BatchListSelectedScenarioProps = {
    removeScenarioFromBatch: () => void;
    displayName: string;
    userAction: string;
    isPastBatch: boolean;
};

const BatchListSelectedScenario: FunctionComponent<BatchListSelectedScenarioProps> = React.memo(
    ({ displayName, userAction = '', removeScenarioFromBatch, isPastBatch = false }) => {
        const removeSelectedScenarioFromBatch = event => {
            event.preventDefault();
            if (isPastBatch) {
                return false;
            }
            return removeScenarioFromBatch();
        };

        return (
            <li
                className="stress-batch__list__item"
                onDoubleClick={removeSelectedScenarioFromBatch}
            >
                <h4 className="stress-batch__list__item__title" title={displayName}>
                    {displayName}
                </h4>
                {userAction && (
                    <span className={`stress__batch__action--${userAction}`}>{userAction}</span>
                )}
                {userAction !== 'removed' && (
                    <button
                        className="stress__batch__list__remove-button"
                        onClick={removeSelectedScenarioFromBatch}
                        type="button"
                        disabled={isPastBatch}
                    >
                        <RemoveIcon />
                    </button>
                )}
            </li>
        );
    },
);

export default BatchListSelectedScenario;
