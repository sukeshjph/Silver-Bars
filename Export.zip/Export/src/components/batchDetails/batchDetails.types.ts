import { ActionType } from 'typesafe-actions';
import { Assign } from 'utility-types';
import { IBatch, IScenario } from '../../interfaces/globals';
import * as BatchDetailsActions from './batchDetailsActions';

/* Component Types starts */
type voidFunc = () => void;

interface actions {
    fetchBatchAndScenarios(batchUkId: string, asOf: any): void;
    closePctNodeDialog: voidFunc;
    fetchPctNodes: voidFunc;
    saveBatch: (batch: Partial<IBatch>) => void;
}

interface reduxFlags {
    isSavingBatch: boolean;
    isFetchingBatches: boolean;
    isFetchingBatch: boolean;
    isFetchingScenarios: boolean;
    isFetchingPctNodes: boolean;
}

// Main Component
export interface IBatchDetailsMainProps {
    model: Assign<
        { batches: Partial<IBatch>[]; batchAudits: any[]; scenarios: IScenario[]; batch: IBatch },
        { error: string },
        Pick<
            reduxFlags,
            'isSavingBatch' | 'isFetchingBatches' | 'isFetchingScenarios' | 'isFetchingBatch'
        >
    >;
    actions: Pick<actions, 'saveBatch' | 'fetchBatchAndScenarios'>;
}

export interface IBatchDetailsMainState {
    removed: number;
    added: number;
    limit: number;
    availableFilterText: string;
    deltaFilterText: string;
    scenarioDelta: [] | any[];
    availableScenarios: [] | IScenario[];
    saveCompleted: boolean;
    isSavingBatch: boolean;
    isEditingPctNodes: boolean;
    isPctNodeClear: boolean;
    selectedBatch: Partial<IBatch>;
    newLocation?: string;
    userCanEdit: boolean;
    batchAsOf: { asOf: any; isPastbatch: boolean };
    hasError: boolean;
    showGMTMessage: boolean;
}

// PCT Node
export interface IPctNode {
    depth: number;
    id: string;
    name: string;
    disabled: boolean;
    children: string[];
    parentIndex?: number;
}

type PCTModalTypesWithoutAction = {
    batch: Partial<IBatch>;
    pctNodeTree: IPctNode[];
    closePctNodeDialog: voidFunc;
    isFetchingPctNodes: boolean;
    isSavingBatch: boolean;
    pctNodeError: string;
};
export type IPctModalProps = Assign<
    PCTModalTypesWithoutAction,
    Pick<actions, 'fetchPctNodes' | 'saveBatch'>
>;

export interface IPctModalState {
    expandedNodes: string[];
    selectedNode: any;
    disableTree: boolean;
}

export interface IPCTDispatchProps {
    fetchPctNodes: voidFunc;
    saveBatch(batch: IBatch): void;
}
/* Component Types ends */

// Action Types
export type ErrorType = {
    error: string;
};

export type BatchDetailsRootActions = ActionType<typeof BatchDetailsActions>;

// reducer types

export interface IBatchDetailsReducerState {
    batch: {} | IBatch;
    batches: [] | IBatch[];
    scenarios: IScenario[];
    batchAudits: any;
    pctNodeTree: any;
    isSavingBatch: boolean;
    isFetchingBatch: boolean;
    isFetchingScenarios: boolean;
    isFetchingPctNodes: boolean;
    pctNodeError: string;
}
