import React, { FunctionComponent } from 'react';
import { Link } from 'react-router-dom';

const PendingIcon: FunctionComponent<{ pending: boolean }> = React.memo(({ pending = false }) => (
    <span>
        {pending && (
            <Link
                title="A newer version of this scenario is awaiting approval"
                to="/inbox"
                className="stress__batch__action--pending"
            >
                pending
            </Link>
        )}
    </span>
));

export default PendingIcon;
