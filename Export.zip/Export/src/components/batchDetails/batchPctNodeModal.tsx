/* eslint-disable react/destructuring-assignment  */
import React from 'react';
import { bindActionCreators } from 'redux';
import { RootState } from 'typesafe-actions';
import { connect } from 'react-redux';
import classnames from 'classnames';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import Button from '@material-ui/core/Button';
import ExpandIcon from '@material-ui/icons/ChevronRight';
import { get } from '../../helpers/utilities';
import * as BatchDetailsActions from './batchDetailsActions';
import ReasonForChange from '../shared/reasonForChange';
import ErrorMessage from '../shared/errorMessage';
import { IPctModalProps, IPctModalState, IPctNode, IPCTDispatchProps } from './batchDetails.types';

type PCTModalPropsState = IPctModalProps & IPctModalState;

class BatchPctNodeModal extends React.PureComponent<PCTModalPropsState> {
    constructor(props: PCTModalPropsState) {
        super(props);
        this.handleUndoClick = this.handleUndoClick.bind(this);
        this.handleSaveClick = this.handleSaveClick.bind(this);
    }

    state: IPctModalState = {
        expandedNodes: [],
        selectedNode: undefined,
        disableTree: false,
    };

    componentDidMount() {
        if (Object.keys(this.props.pctNodeTree).length === 0) {
            this.props.fetchPctNodes();
        }
    }

    getNode = (nodeId: string) => this.props.pctNodeTree[nodeId];

    getButtonClass = (nodeId: string) => {
        const isSelected = nodeId === get(this.state.selectedNode, 'id', false);
        return classnames({
            'stress-batch__pct__select-button': !isSelected,
            'stress-batch__pct__select-button--selected': isSelected,
        });
    };

    isNodeExpanded = (nodeId: string) => this.state.expandedNodes.includes(nodeId);

    createNodeSelectHandler = (node: IPctNode) => () => this.handleNodeSelectClick(node);

    createNodeExpandHandler = (node: IPctNode) => () => this.handleNodeExpandClick(node);

    handleNodeExpandClick(clickedNode: IPctNode) {
        const { expandedNodes } = this.state;
        this.setState({
            expandedNodes: expandedNodes.includes(clickedNode.id)
                ? expandedNodes.filter(node => node !== clickedNode.id) // close node
                : [...expandedNodes, clickedNode.id], // expand node
        });
    }

    handleNodeSelectClick(selectedNode: IPctNode) {
        this.setState({ selectedNode });
    }

    handleSaveClick(comments: string) {
        this.setState({
            disableTree: true,
        });
        this.props.saveBatch({
            ...this.props.batch,
            pctNode: this.state.selectedNode.name,
            pctNodeId: this.state.selectedNode.id,
            comments,
        });
    }

    handleUndoClick() {
        this.setState({ selectedNode: undefined });
    }

    renderTree(list: string[]) {
        return (
            <ul className="stress-batch__pct__list">
                {list.map(nodeId => this.renderNode(nodeId))}
            </ul>
        );
    }

    renderNode(nodeId: string) {
        const node = this.getNode(nodeId);
        const isExpanded = this.isNodeExpanded(nodeId);

        return (
            <li
                key={nodeId}
                className={`stress-batch__pct__node  ${
                    isExpanded ? 'stress-batch__pct__list--expanded' : ''
                }`}
            >
                {node.children.length > 0 ? (
                    <div>
                        <Button
                            disabled={this.state.disableTree}
                            className={`stress-batch__pct__toggle-button  ${
                                isExpanded ? 'stress-batch__pct__toggle-button--expanded' : ''
                            }`}
                            onClick={this.createNodeExpandHandler(node)}
                        >
                            <ExpandIcon />
                        </Button>
                        <button
                            disabled={this.state.disableTree}
                            className={this.getButtonClass(nodeId)}
                            type="button"
                            onClick={this.createNodeSelectHandler(node)}
                        >
                            {node.name}
                        </button>
                        {isExpanded && this.renderTree(node.children)}
                    </div>
                ) : (
                    <button
                        disabled={this.state.disableTree}
                        className="stress-batch__pct__select-button stress-batch__pct__select-button--leaf"
                        type="button"
                        onClick={this.createNodeSelectHandler(node.id)}
                    >
                        {node.name}
                    </button>
                )}
            </li>
        );
    }

    render() {
        const {
            closePctNodeDialog,
            isFetchingPctNodes,
            pctNodeTree,
            batch,
            isSavingBatch,
            pctNodeError,
        } = this.props;
        const { selectedNode } = this.state;
        return (
            <Dialog className="stress-batch__pct__dialog" open onClose={closePctNodeDialog}>
                <DialogTitle>Select new PCT node for {batch.name} batch</DialogTitle>
                <DialogContent className="stress-batch__pct__dialog__content">
                    {pctNodeError && <ErrorMessage message={pctNodeError} />}
                    {isFetchingPctNodes && (
                        <div className="stress-loading stress-batch__pct__loading" />
                    )}
                    {pctNodeTree.rootNodes && pctNodeTree.rootNodes.length > 0 && (
                        <div
                            className={`stress-batch__pct__list__container ${
                                this.state.selectedNode
                                    ? 'stress-batch__pct__list__container--compressed'
                                    : ''
                            }`}
                        >
                            <ul className="stress-batch__pct__list">
                                {pctNodeTree.rootNodes.map(nodeId => this.renderNode(nodeId))}
                            </ul>
                        </div>
                    )}
                    {selectedNode && batch.pctNode !== selectedNode && (
                        <div>
                            <p className="stress-batch__pct__message">{`Setting PCT node to ${
                                selectedNode.name
                            } (${selectedNode.id}) on ${batch.name} batch`}</p>
                            <ReasonForChange
                                actions={{
                                    handleSaveClick: this.handleSaveClick,
                                    handleUndoClick: this.handleUndoClick,
                                    handleDoneClick: closePctNodeDialog,
                                }}
                                model={{
                                    isSaving: isSavingBatch,
                                }}
                            />
                        </div>
                    )}
                </DialogContent>
                <DialogActions>
                    <Button onClick={closePctNodeDialog}>Cancel</Button>
                </DialogActions>
            </Dialog>
        );
    }
}

const mapStateToProps = (state: RootState) => ({
    isFetchingPctNodes: state.BATCH_DETAILS.isFetchingPctNodes,
    isSavingBatch: state.BATCH_DETAILS.isSavingBatch,
    pctNodeTree: state.BATCH_DETAILS.pctNodeTree,
    pctNodeError: state.BATCH_DETAILS.pctNodeError,
});

const mapDispatchToProps = (dispatch: IPCTDispatchProps) => {
    const { fetchPctNodes, saveBatch } = bindActionCreators(
        Object.assign({}, BatchDetailsActions),
        dispatch,
    );
    return {
        fetchPctNodes,
        saveBatch,
    };
};

export const BatchPctNodeModalConnected = connect(
    mapStateToProps,
    mapDispatchToProps,
)(BatchPctNodeModal);
