import React, { FunctionComponent, useState, useEffect } from 'react';
import CloneIcon from '@material-ui/icons/OpenInNew';
import DeleteIcon from '@material-ui/icons/Delete';
import ClearIcon from '@material-ui/icons/Clear';
import { ScenarioListTypes } from './batchDetailsConstants';
import BatchCloneDialog from './batchCloneDialog';
import { IBatch } from '../../interfaces/globals';

type BatchListHeaderProps = {
    heading: string;
    added?: string;
    removed?: string;
    filterText: string;
    handleTextChange(availableFilterText: string): void;
    removeAllScenariosFromBatch?(): void;
    cloneBatch?(batchUkId: string): void;
    batches?: Partial<IBatch>[];
    disableCloneButton?: boolean;
    selectedBatch?: Partial<IBatch>;
    isPastBatch: boolean;
    ScenariosType: 'Available' | 'Added';
};

const BatchListHeader: FunctionComponent<BatchListHeaderProps> = React.memo(
    ({
        filterText,
        cloneBatch = null,
        batches = null,
        removeAllScenariosFromBatch,
        added = null,
        removed = null,
        heading,
        disableCloneButton = false,
        selectedBatch,
        handleTextChange,
        isPastBatch = false,
        ScenariosType,
    }) => {
        const [localFilterText, setFilterText] = useState(filterText);
        const [isCloneDialogOpen, setCloneDialog] = useState(false);

        useEffect(() => handleTextChange(localFilterText), [localFilterText]);

        const updateFilterText = changedFilterVal => setFilterText(changedFilterVal);

        const handleFilterTextChange = e => {
            updateFilterText(e.target.value);
        };

        const clearFilterText = () => {
            updateFilterText('');
        };

        const handleRemoveAllClick = () => {
            clearFilterText();
            if (ScenariosType === ScenarioListTypes.Added && removeAllScenariosFromBatch) {
                removeAllScenariosFromBatch();
            }
        };

        const toggleCloneDialog = () => setCloneDialog(prevClone => !prevClone);

        return (
            <header className="stress-batch__list__header">
                <h3 className="stress-batch__list__title">{heading}</h3>
                <div className="stress__dashboard__field">
                    <input
                        type="text"
                        placeholder="Filter scenarios"
                        className="stress__dashboard__input"
                        value={filterText}
                        onChange={handleFilterTextChange}
                    />
                    <button
                        disabled={filterText === ''}
                        className="stress__dashboard__button stress-batch__list__header__clear-button"
                        onClick={clearFilterText}
                        type="button"
                    >
                        <ClearIcon /> Clear
                    </button>
                </div>
                {!isPastBatch && (
                    <div className="stress-batch__list__header__actions">
                        {cloneBatch && batches && (
                            <div>
                                <button
                                    className="stress__dashboard__button stress-batch__list__header__clone-button"
                                    onClick={toggleCloneDialog}
                                    disabled={disableCloneButton}
                                    type="button"
                                >
                                    <CloneIcon /> Clone batch
                                </button>
                                {isCloneDialogOpen && (
                                    <BatchCloneDialog
                                        batches={batches as NonNullable<IBatch>[]}
                                        cloneBatch={cloneBatch}
                                        closeCloneDialog={toggleCloneDialog}
                                        selectedBatch={selectedBatch as NonNullable<IBatch>}
                                    />
                                )}
                            </div>
                        )}
                        {removeAllScenariosFromBatch && (
                            <button
                                className="stress__dashboard__button stress-batch__list__header__remove-button"
                                onClick={handleRemoveAllClick}
                                type="button"
                            >
                                <DeleteIcon /> Remove all
                            </button>
                        )}

                        {added && removed && (
                            <div className="stress__batch__added-removed">
                                <span className="stress__batch__action--added">{added}</span>
                                <span className="stress__batch__action--removed">{removed}</span>
                            </div>
                        )}
                    </div>
                )}
                {isPastBatch && <div className="stress-batch__list__header__actions" />}
            </header>
        );
    },
);

export default BatchListHeader;
