import React from 'react';
import AddIcon from '@material-ui/icons/Add';
import PendingIcon from './batchPendingIcon';
import { IScenario } from '../../interfaces/globals';

const BatchListAvailableScenario: React.FC<{
    scenario: Pick<IScenario, 'pending' | 'activeFileVersion'>;
    addScenarioToBatch(): void;
    displayName: string;
    limitReached: boolean;
    isPastBatch: boolean;
}> = React.memo(({ scenario, displayName, addScenarioToBatch, limitReached, isPastBatch }) => {
    const addSelectedScenarioToBatch = event => {
        event.preventDefault();
        if (limitReached || isPastBatch) {
            return false;
        }
        return addScenarioToBatch();
    };

    return (
        <div>
            {scenario.activeFileVersion && (
                <li
                    className="stress-batch__list__item"
                    onDoubleClick={addSelectedScenarioToBatch}
                    title={limitReached ? 'Maximum number of scenarios selected' : ''}
                >
                    <h4 className="stress-batch__list__item__title" title={displayName}>
                        {displayName}
                    </h4>
                    <PendingIcon pending={scenario.pending} />
                    <button
                        disabled={limitReached || isPastBatch}
                        className="stress__batch__list__add-button"
                        onClick={addSelectedScenarioToBatch}
                        type="button"
                    >
                        <AddIcon />
                    </button>
                </li>
            )}
        </div>
    );
});

export default BatchListAvailableScenario;
