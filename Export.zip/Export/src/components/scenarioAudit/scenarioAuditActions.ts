import { createAction, createStandardAction } from 'typesafe-actions';
import { scenarioAuditActionTypes } from './scenarioAuditConstants';
import { API_DATE_TIME_FORMAT } from '../../constants';
import { IScenario, ErrorType } from '../../interfaces/globals';

// scenario Audit Actions
export const fetchScenarioAudits = createAction(
    scenarioAuditActionTypes.FETCH_SCENARIO_AUDITS,
    action => (validFromDate: any, validToDate: any) =>
        action({
            validFromDate: validFromDate
                ? validFromDate.startOf('day').format(API_DATE_TIME_FORMAT)
                : null,
            validToDate: validToDate ? validToDate.endOf('day').format(API_DATE_TIME_FORMAT) : null,
        }),
);

export const fetchScenarioAuditsComplete = createAction(
    scenarioAuditActionTypes.FETCH_SCENARIO_AUDITS_COMPLETE,
    action => (scenarioAudits: IScenario[]) => action({ scenarioAudits }),
);

export const fetchScenarioAuditsError = createStandardAction(
    scenarioAuditActionTypes.FETCH_SCENARIO_AUDITS_ERROR,
)<ErrorType>();
