import { formatDateTime } from '../../helpers/dateTime';

export default [
    {
        label: 'Id',
        key: 'ukId',
        csvFormatter: (id) => `'${id}'`,
        className: 'td-no-wrap',
    },
    {
        label: 'Scenario Name',
        key: 'name',
        className: 'td-break-word',
    },
    {
        label: 'Category',
        key: 'category',
        className: 'td td-no-wrap',
    },
    {
        label: 'Proposed Version',
        key: 'proposedFileVersion',
        sortable: true,
    },
    {
        label: 'Active File Version',
        key: 'activeFileVersion',
        sortable: true,
    },
    {
        label: 'Reason for change',
        key: 'comments',
    },
    {
        label: 'Action',
        key: 'action',
        sortable: true,
    },
    {
        label: 'Updated',
        key: 'validFrom',
        formatter: (date) => formatDateTime(date),
        csvFormatter: (date) => `'${date}'`,
        className: 'td td-no-wrap',
        sortable: true,
    },
    {
        label: 'Updated By',
        key: 'modifiedBy',
        sortable: true,
    },
];