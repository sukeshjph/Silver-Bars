/* eslint-disable jsx-a11y/label-has-for */
/* eslint-disable react/destructuring-assignment,react/button-has-type */
import React, { PureComponent } from 'react';
import { RootState } from 'typesafe-actions';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { CSVLink } from 'react-csv';
import shortid from 'shortid';
import Paper from '@material-ui/core/Paper';
import Tooltip from '@material-ui/core/Tooltip';
import CloudDownloadIcon from '@material-ui/icons/CloudDownload';
import { now } from '../../helpers/dateTime';
import generateCsvData from '../../helpers/generateCsvData';
import TableHeadWithSorting from '../shared/tableHeadWithSorting'; //eslint-disable-line
import { tableSorter } from '../../helpers/tableSorter';
import scenarioAuditColumnDefs from './scenarioAuditColumnDefinitions';
import DataSetFilter from '../shared/dataSetFilter';
import * as ScenarioAuditActions from './scenarioAuditActions';
import MainMenu from '../shared/mainMenu';
import DefaultStressTableCell from '../shared/defaultStressTableCell';
import DateRangePicker from '../shared/dateRangePicker';
import ErrorMessage from '../shared/errorMessage';
import LoadingData from '../shared/loadingData';
import { IScenarioAuditMainProps, IScenarioAuditCompState } from './scenarioAudit.types';

export class ScenarioAudit extends PureComponent<IScenarioAuditMainProps, IScenarioAuditCompState> {
    constructor(props) {
        super(props);
        this.tableSorter = tableSorter.bind(this);
        this.sortHandler = this.sortHandler.bind(this);
        this.handleFilterTextChange = this.handleFilterTextChange.bind(this);
    }

    state: IScenarioAuditCompState = {
        order: 'desc',
        orderBy: 'updated',
        scenarioAudits: [],
        filterText: '',
    };

    /**
     * Add scenarioAudits to state to allow filtering and sorting
     * @param nextProps
     */
    static getDerivedStateFromProps(nextProps, prevState) {
        if (nextProps.model.scenarioAudits !== prevState.scenarioAudits) {
            return {
                scenarioAudits: nextProps.model.scenarioAudits,
            };
        }

        return null;
    }

    tableSorter: typeof tableSorter;

    sortHandler(event, orderBy) {
        const stateCopy = { ...this.state };
        const sortResults = this.tableSorter(stateCopy, orderBy, 'scenarioAudits');
        this.setState({
            scenarioAudits: sortResults.data,
            order: sortResults.order,
            orderBy: sortResults.orderBy,
        });
    }

    /**
     * Handler for the DatSetFilter component
     * Triggered when user enters a query in the search filter input
     * @param filterText
     * @param scenarioAudits
     */
    handleFilterTextChange(filterText, scenarioAudits) {
        this.setState({
            filterText,
            scenarioAudits,
        });
    }

    render() {
        const { model, actions } = this.props;
        const { order, orderBy, scenarioAudits, filterText } = this.state;

        return (
            <section id="scenario-audit" className="stress-ui-container">
                <header className="stress__header">
                    <div className="stress__header__title">
                        <h2 className="stress__header__title__main-text">Scenario Audit</h2>
                    </div>
                    <DataSetFilter
                        actions={{
                            handleChange: this.handleFilterTextChange,
                        }}
                        model={{
                            value: filterText,
                            data: model.scenarioAudits,
                        }}
                    />
                    <DateRangePicker fetchByDateRange={actions.fetchScenarioAudits} />
                    <Tooltip title="Download as CSV">
                        <CSVLink
                            filename={`Scenario_Audit_${now()}.csv`}
                            data={generateCsvData(scenarioAudits, scenarioAuditColumnDefs)}
                            headers={scenarioAuditColumnDefs}
                        >
                            <button className="stress__header__action-button">
                                <CloudDownloadIcon className="stress-button--icon" />
                            </button>
                        </CSVLink>
                    </Tooltip>
                    <MainMenu />
                </header>

                <LoadingData
                    showLoading={model.isFetchingScenarioAudits}
                    render={() => <div className="stress-loading" />}
                />

                {model.scenarioAuditsError && (
                    <ErrorMessage message="Sorry, an unexpected error has occurred. Scenario audit data cannot be displayed." />
                )}

                {model.scenarioAudits.length > 0 && scenarioAudits.length === 0 && (
                    <ErrorMessage message="There are no scenario audits matching your filters." />
                )}

                {scenarioAudits.length > 0 && (
                    <Paper className="stress-paper">
                        <table className="stress-table">
                            <TableHeadWithSorting
                                order={order}
                                orderBy={orderBy}
                                sortHandler={this.sortHandler}
                                columnDefs={scenarioAuditColumnDefs}
                            />
                            <tbody>
                                {scenarioAudits.map(audit => (
                                    <tr key={shortid.generate()}>
                                        {scenarioAuditColumnDefs.map(column =>
                                            DefaultStressTableCell(column, audit),
                                        )}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </Paper>
                )}
            </section>
        );
    }
}

export const ScenarioAuditConnected = connect(
    (state: RootState) => ({ model: state.SCENARIO_AUDITS }),
    dispatch => ({ actions: bindActionCreators(ScenarioAuditActions, dispatch) }),
)(ScenarioAudit);
