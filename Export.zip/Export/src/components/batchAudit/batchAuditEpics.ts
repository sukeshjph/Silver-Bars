import { of } from 'rxjs';
import { mergeMap, catchError, map, filter } from 'rxjs/operators';
import { isActionOf } from 'typesafe-actions';
import { combineEpics, Epic } from 'redux-observable';
import { BatchAuditActionsType } from './batchAudit.types';
import * as BatchAuditActions from './batchAuditActions';
import { getConfig } from '../../common/config';
import http from '../../helpers/http';
import { dateRangeQueryStringGenerator } from '../shared/dateRangePicker';

const fetchBatchAudits: Epic<BatchAuditActionsType> = action$ =>
    action$.pipe(
        filter(isActionOf(BatchAuditActions.fetchBatchAudits)),
        mergeMap(action =>
            http
                .getData(
                    `${getConfig().SdxService}/batchmanagement/Batch${dateRangeQueryStringGenerator(
                        action.payload,
                    )}`,
                )
                .pipe(
                    map(batchAudits => BatchAuditActions.fetchBatchAuditsComplete(batchAudits)),
                    catchError(() =>
                        of(
                            BatchAuditActions.fetchBatchAuditsError({
                                error:
                                    'Sorry, an error has occurred whilst fetching batch audit data',
                            }),
                        ),
                    ),
                ),
        ),
    );

export default combineEpics(fetchBatchAudits);
