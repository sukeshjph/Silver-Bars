import React from 'react';
import shortid from 'shortid';

const BatchListItemCell = list => {
    if (list && list.length > 0) {
        return (
            <ul>
                {list.split(',').map(listItem => (
                    <li className="stress-table--list--item" key={shortid.generate()}>
                        {listItem}
                    </li>
                ))}
            </ul>
        );
    }
    return '';
};

export default BatchListItemCell;
