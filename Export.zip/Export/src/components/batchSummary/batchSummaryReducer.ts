import { createReducer, StateType } from 'typesafe-actions';
import * as BatchSummaryActions from './batchSummaryActions';
import reorderBatches from '../../helpers/reorderBatches';
import { IBatchSummaryState, BatchSummaryRootActions } from './batchSummary.types';

const initialState = {
    batches: [],
    isFetchingBatches: false,
    error: '',
};

const SummaryReducer = createReducer<IBatchSummaryState, BatchSummaryRootActions>(
    initialState as IBatchSummaryState,
)
    .handleAction(BatchSummaryActions.fetchAllBatches, state => ({
        ...state,
        isFetchingBatches: true,
        error: '',
    }))
    .handleAction(BatchSummaryActions.fetchAllBatchesComplete, (state, action) => ({
        ...state,
        isFetchingBatches: false,
        batches: reorderBatches(action.payload),
    }))
    .handleAction(BatchSummaryActions.fetchAllBatchesError, (state, action) => ({
        ...state,
        isFetchingBatches: false,
        error: action.payload.error,
    })); 

export type SummaryReducerType = StateType<typeof SummaryReducer>;

export default SummaryReducer; 
