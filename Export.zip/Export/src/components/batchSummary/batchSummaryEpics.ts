import { of } from 'rxjs';
import { mergeMap, catchError, map, filter } from 'rxjs/operators';
import { combineEpics, Epic } from 'redux-observable';
import { isActionOf } from 'typesafe-actions';
import { BatchSummaryRootActions } from './batchSummary.types';
import * as BatchSummaryActions from './batchSummaryActions';
import { getConfig } from '../../common/config';
import http from '../../helpers/http';

const fetchAllBatches: Epic<BatchSummaryRootActions> = action$ =>
    action$.pipe(
        filter(isActionOf(BatchSummaryActions.fetchAllBatches)),
        mergeMap(() => {
            return http.getData(`${getConfig().SdxService}/batchmanagement/Batch`).pipe(
                map(batches => BatchSummaryActions.fetchAllBatchesComplete(batches)),
                catchError(error => of(BatchSummaryActions.fetchAllBatchesError({ error }))),
            );
        }),
    );
export default combineEpics(fetchAllBatches);
