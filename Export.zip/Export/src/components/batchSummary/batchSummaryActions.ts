import { createAction, createStandardAction } from 'typesafe-actions';
import { batchSummaryActionTypes } from './batchSummaryConstants';
import { IBatch } from '../../interfaces/globals';
import { ErrorType } from './batchSummary.types';

// batch schedule Actions
export const fetchAllBatches = createStandardAction(batchSummaryActionTypes.FETCH_ALL_BATCHES)<
    string
>();

export const fetchAllBatchesComplete = createAction(
    batchSummaryActionTypes.FETCH_ALL_BATCHES_COMPLETE,
    action => (allBatches: IBatch[]) => action(allBatches),
);

export const fetchAllBatchesError = createStandardAction(batchSummaryActionTypes.FETCH_ALL_BATCHES_ERROR)<
    ErrorType
>();