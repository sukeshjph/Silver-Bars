// Summary action types
export const batchSummaryActionTypes = ({
    FETCH_ALL_BATCHES: 'STRESS/FETCH_ALL_BATCHES',
    FETCH_ALL_BATCHES_COMPLETE: 'STRESS/FETCH_ALL_BATCHES_COMPLETE',
    FETCH_ALL_BATCHES_ERROR: 'STRESS/FETCH_ALL_BATCHES_ERROR',
}) as const; // use this to enforce Typescript readonly typing 
