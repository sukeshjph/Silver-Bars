import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import moment from 'moment';
import 'react-placeholder/lib/reactPlaceholder.css';
import List from '@material-ui/core/List';
import Paper from '@material-ui/core/Paper';
import ListItem from '@material-ui/core/ListItem';
import BatchListItem from '../shared/batchListItem';
import BatchHeader from '../shared/batchHeaderLinks';
import { IBatch } from '../../interfaces/globals';
import { getPascalCase } from '../../helpers/utilities';
import { BatchSummaryProps } from './batchSummary.types';
import './batchSummary.scss';

const BatchList: React.FC<BatchSummaryProps> = React.memo(props => {
    const {
        model: { batchList, error },
        actions: { fetchAllBatches },
    } = props;

    useEffect(() => {
        fetchAllBatches();
    }, []);

    const getBatchHeader = batch => (
        <React.Fragment>
            <Link
                to={{
                    pathname: `/batches/${batch.ukId}`,
                    search: '?asOf=now',
                }}
                className="batch-summary__batch-name"
                title="View Batch Details"
            >
                {batch.name}
            </Link>
            <div />
        </React.Fragment>
    );

    const getSchedule = scheduleDto => {
        if (scheduleDto === null) {
            return '';
        }
        if (scheduleDto.month) {
            return moment(
                `${scheduleDto.year}-${scheduleDto.month}-${scheduleDto.dayOfMonth}`,
            ).format('DD MMMM YYYY');
        }

        return scheduleDto.daysOfWeek.map(dOfWeek => getPascalCase(dOfWeek)).join(',');
    };

    const getBatchContent = (batch: IBatch) => {
        const { cobDate, pctNode, scheduleDto } = batch;
        let scheduleType = '';
        if (scheduleDto !== null) {
            scheduleType = scheduleDto.month !== null ? 'Run Once' : 'Repeats Weekly';
        }
        return (
            <React.Fragment>
                <span className="batch-summary__batch-details-col">
                    {cobDate ? `Past COB:${moment(cobDate).format('DD MMMM YYYY')}` : ''}
                </span>
                <span className="batch-summary__batch-details-col">{pctNode || ''}</span>
                <span className="batch-summary__batch-details-col">{scheduleType}</span>
                <span className="batch-summary__batch-details-col">{getSchedule(scheduleDto)}</span>
                <span className="batch-summary__batch-details-col">
                    {scheduleDto && 'Next run on'}
                </span>
            </React.Fragment>
        );
    };

    const renderBatchList = () => {
        const batchListLength = batchList.length;
        return (
            <List className="batch-summary-batch__list batch-summary">
                {error && <div>{error}</div>}
                {batchList.length === 0 && (
                    <ListItem
                        className="batch-summary-batch__list-item empty-list-item"
                        alignitems="flex-start"
                    >
                        0 batch found
                    </ListItem>
                )}
                {batchList.length !== 0 &&
                    batchList.map((batch, index) => (
                        <BatchListItem
                            batch={batch}
                            cssNs="batch-summary"
                            islastItem={index + 1 === batchListLength}
                            batchHeader={getBatchHeader}
                            batchContent={getBatchContent}
                        />
                    ))}
            </List>
        );
    };

    return (
        <section id="stress-batch-summary" className="stress-ui-container">
            <BatchHeader navHeaderTitle="Batches" />
            <Paper>{renderBatchList()}</Paper>
        </section>
    );
});

export default BatchList;
