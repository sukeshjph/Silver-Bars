import { ActionType } from 'typesafe-actions';
import * as BatchSummaryActions from './batchSummaryActions';
import { IBatch } from '../../interfaces/globals';

// Reducer state
export interface IBatchSummaryState {
    batches: IBatch[];
    isFetchingBatches: boolean;
    error: string;
}

// Action types
export type ErrorType = {
    error: string;
};

// Component Types
export interface BatchSummaryProps {
    model: {
        batchList: IBatch[];
        isFetchingBatches: boolean;
        error: string;
    };
    actions: {
        fetchAllBatches: () => void;
    };
    children?: React.ReactNode;
}

export type BatchSummaryRootActions = ActionType<typeof BatchSummaryActions>;
