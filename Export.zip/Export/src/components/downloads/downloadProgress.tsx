import React, { FunctionComponent } from 'react';
import Paper from '@material-ui/core/Paper';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import shortid from 'shortid';
import CircularProgress from '@material-ui/core/CircularProgress';
import './downloads.scss';

interface IFiles {
    dataSetId: string;
    blobName: string;
}

type ProgressProps = {
    files: IFiles[];
    setRef?(): void;
    isVisible: boolean;
};

const DownloadProgress: FunctionComponent<ProgressProps> = React.memo(
    ({ files, setRef, isVisible = true }) => {
        if (!isVisible) {
            return null;
        }
        return (
            <Paper className="stress-reports-footer">
                <div ref={setRef}>
                    <List component="nav" className="stress-reports-footer--list">
                        {files.map(file => (
                            <ListItem
                                button
                                className="stress-reports-footer--list__listItem"
                                key={shortid.generate()}
                            >
                                <ListItemIcon>
                                    <CircularProgress
                                        size={30}
                                        thickness={5}
                                        className="stress-reports-footer__progress"
                                    />
                                </ListItemIcon>
                                <span className="stress-reports-footer__fileName">
                                    {file.blobName}
                                </span>
                            </ListItem>
                        ))}
                    </List>
                </div>
            </Paper>
        );
    },
);

export default DownloadProgress;
