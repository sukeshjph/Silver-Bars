export default (sourceFileList, extensionList, prop) =>
    sourceFileList.filter(file =>
        extensionList.reduce(
            (acc, curExtension) =>
                acc || file[prop].toLowerCase().indexOf(curExtension) !== -1,
            file[prop].toLowerCase().indexOf(extensionList[0]) !== -1
        )
    );
