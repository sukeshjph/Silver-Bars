import { of } from 'rxjs';
import { mergeMap, catchError, map, filter } from 'rxjs/operators';
import { combineEpics, Epic } from 'redux-observable';
import { isActionOf } from 'typesafe-actions';
import { DownloadsActionsType } from './downloads.types';
import * as Actions from './downloadsActions';
import { getConfig } from '../../common/config';
import http from '../../helpers/http';

export const fetchFileList: Epic<DownloadsActionsType> = action$ =>
    action$.pipe(
        filter(isActionOf(Actions.fetchFileList)),
        mergeMap(action => {
            const {
                regexFilter,
                root: { path, label },
            } = action.payload;
            const reqUrl = `${getConfig().DownloadService}/list?root=${path}${
                regexFilter ? `&regexFilter=${regexFilter}` : ''
            }`.trim();

            return http.getDataFromSabreStore(reqUrl).pipe(
                map(data => Actions.fetchFileListComplete(path, label, data)),
                catchError(error => of(Actions.fetchFileListError({ error }))),
            );
        }),
    );

export const fetchFileDetails: Epic<DownloadsActionsType> = action$ =>
    action$.pipe(
        filter(isActionOf(Actions.fetchFileDetails)),
        mergeMap(action =>
            http
                .getDataFromSabreStore(
                    `${getConfig().DownloadService}/details?dataSetId=${action.payload.datasetId}`,
                )
                .pipe(
                    map(ds => Actions.fetchFileDetailsComplete(ds.dataSetId, ds.blobs)),
                    catchError(error => of(Actions.fetchFileDetailsError({ error }))),
                ),
        ),
    );

export const fetchBlobFile: Epic<DownloadsActionsType> = action$ =>
    action$.pipe(
        filter(isActionOf(Actions.fetchBlobFile)),
        mergeMap(action => {
            const { datasetId, blobName } = action.payload;
            return http
                .getFileFromSabreStore(
                    `${getConfig().DownloadService}/blob?dataSetId=${datasetId}&name=${blobName}`,
                )
                .pipe(
                    map(blob => Actions.fetchBlobFileComplete(datasetId, blobName, blob)),
                    catchError(error => of(Actions.fetchBlobFileError({ error }))),
                );
        }),
    );

export default combineEpics(fetchFileList, fetchFileDetails, fetchBlobFile);
