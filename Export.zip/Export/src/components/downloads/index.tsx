/* eslint-disable react/destructuring-assignment */
import React, { PureComponent } from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import _ from 'lodash';
import { RootState } from 'typesafe-actions';
import moment from 'moment';
import ChevronDown from '@material-ui/icons/KeyboardArrowDown';
import ChevronUp from '@material-ui/icons/KeyboardArrowUp';
import classnames from 'classnames';
import DatePicker from 'react-datepicker';
import Tooltip from '@material-ui/core/Tooltip';
import CircularProgress from '@material-ui/core/CircularProgress';
import 'react-datepicker/dist/react-datepicker.css';
import RiskViewTable from 'sabre-js-common/src/main';
import { SidePanel } from 'sabre-js-common/src/main/components';
import WithIconButton from './withIconButton';
import { DATASET_ROOT, SECONDARY_ROOTPATHS } from './downloadsConstants';
import * as Actions from '../../actions';
import * as DownloadsActions from './downloadsActions';
import './downloads.scss';
import { getUserState, getReportState } from './downloadSelector';
import MainMenu from '../shared/mainMenu';
import DownloadProgress from './downloadProgress';
import DownloadBlobFiles from './downloadBlobFiles';
import ErrorMessage from '../shared/errorMessage';
import LoadingData from '../shared/loadingData';
import { IDownloadsState, IDownloadsProps } from './downloads.types';

export class Download extends PureComponent<IDownloadsProps, IDownloadsState> {
    /**
     * Build initial datasetView state for first render
     */
    static getDataSetView = dsView => {
        const initialView = {
            columns: [],
            rows: [],
            viewname: '',
            csvFileName: '',
        };

        if (Object.keys(dsView).length === 0) return initialView;
        return dsView;
    };

    static getUpdatedRegexFilter(asOfDate) {
        if (_.isUndefined(asOfDate)) {
            return `.*${moment().format('YYYY-MM')}.*`;
        }
        return `.*${asOfDate.format('YYYY-MM-DD')}.*`;
    }

    static getDefaultRegexFilterText() {
        const currentMonth = moment().format('YYYY-MM');
        const prevMonth = moment()
            .subtract(1, 'month')
            .format('YYYY-MM');
        const prevPrMonth = moment()
            .subtract(2, 'month')
            .format('YYYY-MM');
        return `.*(${encodeURIComponent(`${currentMonth}|${prevMonth}|${prevPrMonth}`)}).*`;
    }

    state: IDownloadsState = {
        asOfDate: undefined,
        currentRootLink: {
            path: DATASET_ROOT + SECONDARY_ROOTPATHS[0].value,
            label: SECONDARY_ROOTPATHS[0].label,
        },
        currentActiveLink: SECONDARY_ROOTPATHS[0].value,
        regexFilter: Download.getDefaultRegexFilterText(),
        dataSetView: Download.getDataSetView(this.props.reports.dataSetView),
    };

    /**
     *  Clear File progress panel and fetch all dataset list
     */
    componentDidMount() {
        const {
            actions: { fetchFileList, fetchBlobReset },
        } = this.props;
        const { currentRootLink, regexFilter } = this.state;
        fetchBlobReset(); // Clear the existing blob progress
        fetchFileList(currentRootLink, regexFilter);
    }

    /**
     *  Update local datasetList in response to newer data
     */
    componentDidUpdate(prevProps: IDownloadsProps) {
        if (this.props.reports.dataSetView !== prevProps.reports.dataSetView) {
            this.setState({ dataSetView: Download.getDataSetView(this.props.reports.dataSetView) }); //eslint-disable-line
        }
    }

    /**
     *  Show folder icon when no files are present
     */

    getFilesRow(row, isRowFileRow: boolean) {
        return {
            ...row,
            onRowClick: this.handleGetFilesClick(row.oldDataSetId, !isRowFileRow),
            files: (
                <WithIconButton
                    buttonProps={{
                        variant: 'fab',
                        className: 'stress-reports__folderIcon',
                        onClick: this.handleGetFilesClick(row.oldDataSetId, !isRowFileRow),
                    }}
                >
                    <Tooltip
                        id="tooltip-bottom"
                        title={`${isRowFileRow ? 'Hide Files' : 'Show files'}`}
                        placement="bottom"
                        enterDelay={300}
                        leaveDelay={300}
                    >
                        {isRowFileRow ? <ChevronUp /> : <ChevronDown />}
                    </Tooltip>
                </WithIconButton>
            ),
        };
    }

    /**
     *  show folder or show files when there are present
     */

    getUpdatedRowsWithFileLinks = rows => {
        if (rows.length === 0) return rows;
        const {
            reports: { currentDataSetIdWithFileRequest, isFetchingFiles },
        } = this.props;

        return rows.map(row => {
            if (Object.prototype.hasOwnProperty.call(row, 'files')) {
                const isRowFileRow = this.isCurrentRowFileRow(row, currentDataSetIdWithFileRequest);
                if (!row.files) {
                    return this.getFilesRow(row, isRowFileRow);
                }

                if (row.files.length === 0) {
                    if (isFetchingFiles)
                        return {
                            ...row,
                            files: (
                                <div className="loading-reports--Panel">
                                    Loading...
                                    <CircularProgress size={25} />
                                </div>
                            ),
                        };
                    return {
                        ...row,
                        onRowClick: this.handleGetFilesClick(row.oldDataSetId, !isRowFileRow),
                        files: <div className="no-reports--Panel">No Reports found</div>,
                    };
                }

                return {
                    ...row,
                    files: (
                        <DownloadBlobFiles
                            tableRow={row}
                            handleBlobFileDownload={this.handleBlobFileDownload}
                        />
                    ),
                };
            }
            return row;
        });
    };

    isCurrentRowFileRow = (row, currentFileRowId) => {
        if (!currentFileRowId) return false;
        return currentFileRowId === row.oldDataSetId;
    };

    /**
     *  Handle side panel click
     */
    handleRootPathChange = (path: string) => {
        const {
            actions: { fetchFileList },
        } = this.props;
        const { regexFilter } = this.state;
        const foundRootPath =
            SECONDARY_ROOTPATHS.find(entry => entry.value === path) || SECONDARY_ROOTPATHS[0];
        const currentRootLink = {
            path: DATASET_ROOT + foundRootPath.value,
            label: foundRootPath.label,
        };

        this.setState(
            {
                currentRootLink,
                currentActiveLink: path,
            },
            () => {
                fetchFileList(currentRootLink, regexFilter);
            },
        );
    };

    /**
     *  handle file download click
     */
    handleBlobFileDownload = (dataSetId: string, fileName: string) => () => {
        const { fetchBlobFile } = this.props.actions;
        fetchBlobFile(encodeURIComponent(dataSetId), encodeURIComponent(fileName));
    };

    /**
     *  Handle File folder click
     */

    handleGetFilesClick = (oldDataSetId: string, getFilesFromServer: boolean) => () => {
        const {
            reports,
            actions: { fetchFileDetails, fetchFileDetailsReset },
        } = this.props;

        if (!reports.isFetchingFiles) {
            if (getFilesFromServer) {
                const { orderBy, columnFilter } = this.rvT.state;
                fetchFileDetails(encodeURIComponent(oldDataSetId), orderBy, columnFilter);
                return;
            }

            fetchFileDetailsReset();
        }
    };

    /**
     *  Handle CobDate change like clear and new date selection
     */

    handleDateChange = (CobDate: any) => {
        const asOfDate = _.isNull(CobDate) ? undefined : CobDate;
        this.setState(
            {
                asOfDate,
                regexFilter: Download.getUpdatedRegexFilter(asOfDate),
            },
            () => {
                const { regexFilter, currentRootLink } = this.state;
                const { fetchFileList } = this.props.actions;
                fetchFileList(currentRootLink, regexFilter);
            },
        );
    };

    render() {
        const {
            reports: {
                filesInProgress,
                isFetchingDataSetList,
                error,
                currentRvOrderBy: orderBy,
                currentRvFilter: columnFilter,
            },
        } = this.props;

        const {
            asOfDate,
            currentActiveLink,
            dataSetView: { rows, columns, viewname, csvFileName },
        } = this.state;

        const areFilesInProgress = filesInProgress || [];

        return (
            <section className={classnames('stress-ui-container', 'stress-reports')}>
                <LoadingData
                    showLoading={isFetchingDataSetList}
                    render={() => <div className="stress-loading" />}
                />

                {error && <ErrorMessage message="Sorry, an unexpected error has occurred." />}

                <header className="stress__header">
                    <div className="stress__header__title">
                        <h2 className="stress__header__title__main-text">MR Reports</h2>
                    </div>
                    <div className="stress--date-range--container">
                        <span className="stress--date-range--label stress-reports--date-range--label">
                            CoB Date
                        </span>
                        <DatePicker
                            className="stress__header__input"
                            selected={asOfDate}
                            onChange={this.handleDateChange}
                            dateFormat="DD/MM/YYYY"
                            isClearable
                        />
                    </div>
                    <MainMenu />
                </header>
                <div className="view-content-panel">
                    <SidePanel
                        data={{
                            listOfLinks: SECONDARY_ROOTPATHS,
                            currentLink: currentActiveLink,
                        }}
                        classes="stress-reports__side-panel"
                        methods={{
                            handleMenuItemChange: this.handleRootPathChange,
                        }}
                    />
                    <RiskViewTable
                        view={{
                            columns: rows.length === 0 ? [] : columns,
                            rows: this.getUpdatedRowsWithFileLinks(rows),
                            viewname,
                            csvFileName,
                            showExportCSV: false,
                            accordionMode: true,
                            orderBy,
                            columnFilter,
                        }}
                        ref={tb => {
                            this.rvT = tb;
                        }}
                    />
                </div>
                <DownloadProgress
                    files={areFilesInProgress}
                    isVisible={areFilesInProgress.length > 0}
                />
            </section>
        );
    }
}

export const mapStateToProps = (state: RootState) => ({
    reports: getReportState(state),
    user: getUserState(state),
});

export const mapDispatchToProps = dispatch => ({
    actions: bindActionCreators({ ...Actions, ...DownloadsActions }, dispatch),
});

export default connect(
    mapStateToProps,
    mapDispatchToProps,
)(Download);
