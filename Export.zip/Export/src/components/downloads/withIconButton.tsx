/* eslint-disable react/destructuring-assignment  */
import React from 'react';
import IconButton from '@material-ui/core/IconButton';
import PropTypes from 'prop-types';

const withIconButton = ({ buttonProps, ...props }) => (
    <IconButton {...buttonProps}>{props.children || null}</IconButton>
);

withIconButton.defaultProps = {
    children: null,
};
withIconButton.propTypes = {
    buttonProps: PropTypes.object.isRequired, // eslint-disable-line react/forbid-prop-types
    children: PropTypes.element,
};

export default withIconButton;
