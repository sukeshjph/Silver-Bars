import { ActionType } from 'typesafe-actions';
import { IBatch, StringTMap } from '../../interfaces/globals';
import * as BatchScheduleActions from './batchScheduleActions';

// Action Types

export type BatchScheduleActionsType = ActionType<typeof BatchScheduleActions>;

export type ErrorType = {
    error: string;
};

export interface IEventType {
    eventType: string;
    eventData: any;
}

// Component types

interface IBatchScheduleActions {
    fetchBatchesByDate(fromDate: string, toDate: string): void;
    fetchBatchStatus(events: string[]): void;
    requestBatchProgressForBatches(batches: IBatch[], subscriptionId: string): void;
    fetchPastBatchProgressStatus(pastDate: any, batches: IBatch[]): void;
}

export interface IBatchesStatus {
    batchUkId: number;
    batchId: number;
    progressStatus: string;
}

export interface IBatchScheduleProps {
    actions: IBatchScheduleActions;
    batchesByDate: StringTMap<IBatch[]>;
    isFetchingBatchesByDate: boolean;
    isFetchingPastBatchesProgress: boolean;
    allbatchesStatus: any;
}

type batchDaysType = {
    date: any;
    weekDay: string;
    id: string;
};

export interface IBatchScheduleState {
    yesterday: any;
    selectedDate: any;
    batchDays: batchDaysType[];
    firstPageLoad: boolean;
}

// state Types
type allbatchesStatus = {
    subscriptionId: string;
    currentBatchesStatus: any;
    error: string;
};

export interface BatchScheduleState {
    batchesByDate: {} | StringTMap<IBatch[]>;
    allBatches: {} | any;
    isFetchingBatchesByDate: boolean;
    errorBatchesByDate: string;
    isSubscibingTostatusEvents: boolean;
    isFetchingPastBatchesProgress: boolean;
    isFetchingTodayBatchesProgress: boolean;
    pastBatchesProgress: { pastDate: null; batches: [] };
    pastBatchesProgressError: string;
    allbatchesStatus: allbatchesStatus;
}
