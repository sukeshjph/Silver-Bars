/* Rxjs/Redux observable error handling 
      https://github.com/redux-observable/redux-observable/blob/master/docs/recipes/ErrorHandling.md
*/
import { of, forkJoin } from 'rxjs';
import { mergeMap, switchMap, catchError, map, filter } from 'rxjs/operators';
import { combineEpics, ActionsObservable } from 'redux-observable';
import { isActionOf } from 'typesafe-actions';
import { getConfig } from '../../common/config';
import fromEventSource from './batchscheduleEvents';
import * as ScheduleActions from './batchScheduleActions';
import http from '../../helpers/http';
import { BatchScheduleActionsType } from './batchSchedule.types';

const fetchBatchesByDate = (action$: ActionsObservable<BatchScheduleActionsType>) =>
    action$.pipe(
        filter(isActionOf(ScheduleActions.fetchBatchesByDate)),
        mergeMap(action => {
            const { fromDate, toDate } = action.payload;
            return http
                .getData(
                    `${
                        getConfig().SdxService
                    }/batchmanagement/batchesToRun?fromDate=${fromDate}&toDate=${toDate}`,
                )
                .pipe(
                    map(({ batchesByDate, batchMap }) =>
                        ScheduleActions.fetchBatchesByDateComplete(batchesByDate, batchMap),
                    ),
                    catchError(error => of(ScheduleActions.fetchBatchesByDateError({ error }))),
                );
        }),
    );

const fetchBatchStatusEvents = (action$: ActionsObservable<BatchScheduleActionsType>) =>
    action$.pipe(
        filter(isActionOf(ScheduleActions.fetchBatchStatus)),
        switchMap(action => {
            const { events } = action.payload;
            return fromEventSource(`${getConfig().SdxService}/batchmanagement/listen`, events).pipe(
                map((event: any) =>
                    ScheduleActions.fetchBatchStatusComplete({
                        eventType: event.type,
                        eventData: JSON.parse(event.data),
                    }),
                ),
                catchError(error => of(ScheduleActions.fetchBatchStatusError({ error }))),
            );
        }),
    );

const requestBatchProgressForBatches = (action$: ActionsObservable<BatchScheduleActionsType>) =>
    action$.pipe(
        filter(isActionOf(ScheduleActions.requestBatchProgressForBatches)),
        mergeMap(action => {
            const { batches, subscriptionId } = action.payload;
            const batchProgressRequests = batches.reduce(
                (finalReq, curBatch) => ({
                    ...finalReq,
                    [curBatch.ukId]: http
                        .getData(
                            `${getConfig().SdxService}/batchmanagement/subscribe/batchprogress/${
                                curBatch.ukId
                            }/${curBatch.id}`,
                            {
                                headers: {
                                    subscriptionId,
                                },
                            },
                        )
                        .pipe(
                            catchError(error =>
                                of(ScheduleActions.requestBatchProgressForBatchesError({ error })),
                            ),
                        ),
                }),
                {},
            );

            return forkJoin(batchProgressRequests).pipe(
                map(curBatchesStatus =>
                    ScheduleActions.requestBatchProgressForBatchesComplete(curBatchesStatus),
                ),
            );
        }),
    );

const fetchPastBatchProgressStatus = (action$: ActionsObservable<BatchScheduleActionsType>) =>
    action$.pipe(
        filter(isActionOf(ScheduleActions.fetchPastBatchProgressStatus)),
        mergeMap(action =>
            forkJoin(
                action.payload.batches.map(batch =>
                    http
                        .getData(
                            `${getConfig().SdxService}/batchmanagement/progress/Batch/${
                                batch.ukId
                            }/${batch.id}`,
                        )
                        .pipe(
                            catchError(error =>
                                of(ScheduleActions.fetchPastBatchProgressStatusError({ error })),
                            ),
                        ),
                ),
            ).pipe(map(batches => ScheduleActions.fetchPastBatchProgressStatusComplete(batches))),
        ),
    );

export default combineEpics(
    fetchBatchesByDate,
    fetchBatchStatusEvents,
    requestBatchProgressForBatches,
    fetchPastBatchProgressStatus,
);
