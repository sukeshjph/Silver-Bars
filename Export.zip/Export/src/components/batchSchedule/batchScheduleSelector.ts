import { createSelector } from 'reselect';
import { RootState } from 'typesafe-actions';

export const getBatchesByDate = createSelector(
    (state: RootState) => state.BATCH_SCHEDULES.batchesByDate,
    batchesByDate => batchesByDate,
);

export const getIsFetchingBatchesByDate = createSelector(
    (state: RootState) => state.BATCH_SCHEDULES.isFetchingBatchesByDate,
    isFetchingBatchesByDate => isFetchingBatchesByDate,
);

export const getIsFetchingPastBatchesProgress = createSelector(
    (state: RootState) => state.BATCH_SCHEDULES.isFetchingPastBatchesProgress,
    isFetchingPastBatchesProgress => isFetchingPastBatchesProgress,
);

export const getAllbatchesStatus = createSelector(
    (state: RootState) => state.BATCH_SCHEDULES.allbatchesStatus,
    allbatchesStatus => allbatchesStatus,
);

export const getPastBatchesProgress = createSelector(
    (state: RootState) => state.BATCH_SCHEDULES.pastBatchesProgress,
    pastBatchesProgress => pastBatchesProgress,
);
