import React, { FunctionComponent } from 'react';
import moment from 'moment';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import Button from '@material-ui/core/Button';
import NextIcon from 'mdi-material-ui/ChevronDoubleRight';
import PrevIcon from 'mdi-material-ui/ChevronDoubleLeft';

interface BatchCalendarProps {
    data: {
        selectedDate: any;
        isFetchingBatchesByDate: boolean;
    };
    methods: {
        handleChange(date: any): boolean;
    };
}

const BatchCalendar: FunctionComponent<BatchCalendarProps> = React.memo(
    ({ methods: { handleChange }, data: { selectedDate, isFetchingBatchesByDate } }) => {
        
        const handleWeekChange = (weektype: boolean) => () => {
            const startOrEndWeek = weektype
                ? moment(selectedDate)
                    .startOf('week')
                    .subtract(7, 'days')
                : moment(selectedDate)
                    .startOf('week')
                    .add(7, 'days');

            handleChange(startOrEndWeek);
        };

        return (
            <div className="batch-schedule-date">
                <h2 className="batch-schedule-date__title">Run Date</h2>
                <DatePicker
                    selected={selectedDate}
                    inline
                    onChange={handleChange}
                    peekNextMonth
                    showMonthDropdown
                    showYearDropdown
                    dropdownMode="select"
                >
                    <div className="batch-schedule-week-container">
                        <Button
                            variant="text"
                            className="batch-schedule-week-nav batch-schedule-week-nav--left"
                            size="small"
                            onClick={handleWeekChange(true)}
                            disabled={isFetchingBatchesByDate}
                        >
                            <PrevIcon /> Prev Week
                        </Button>
                        <Button
                            variant="text"
                            className="batch-schedule-week-nav batch-schedule-week-nav--right"
                            size="small"
                            onClick={handleWeekChange(false)}
                            disabled={isFetchingBatchesByDate}
                        >
                            Next Week <NextIcon />
                        </Button>
                    </div>
                </DatePicker>
            </div>
        );
    },
);

export default BatchCalendar;
