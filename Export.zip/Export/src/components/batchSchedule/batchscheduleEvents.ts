import { Observable } from 'rxjs';

const fromEventSource = (url, events:MessageEvent[]) =>
    new Observable(observer => {
        const source = new EventSource(url);
        const handler = e => observer.next(e);
        const eventTypes = events.length === 0 ? ['message'] : events;

        eventTypes.forEach(eventType => source.addEventListener(eventType, handler, false));

        source.onerror = error => observer.error(error);

        // This is called when event source is unsubscribed
        return () => {
            eventTypes.forEach(type => source.removeEventListener(type, handler, false));
            source.close();
        };
    });

export default fromEventSource;
