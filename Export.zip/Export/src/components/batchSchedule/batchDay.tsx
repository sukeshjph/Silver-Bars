import React, { FunctionComponent } from 'react';
import moment from 'moment';
import { dateFormat } from './batchScheduleConstants';

const BatchDay: FunctionComponent<{
    batchDay: { date: any; weekDay: string };
    children: React.ReactNode;
    firstPageLoad: boolean;
}> = React.memo(({ batchDay: { date, weekDay }, children = null, firstPageLoad }) => (
    <div className="batch-schedule-day">
        <div className="batch-schedule-day__header">
            <h2 className="main-title">
                {firstPageLoad ? weekDay : moment(date).format(dateFormat)}
            </h2>
            <span className="sub-title">{moment(date).format('Do MMMM YYYY')}</span>
        </div>
        <div className="batch-schedule-day__content">{children}</div>
    </div>
));

export default BatchDay;
