import orderBy from 'lodash.orderby';
import { createReducer, StateType } from 'typesafe-actions';
import fileDownload from 'js-file-download';
import * as InboxActions from './inboxActions';
import { IInboxReducerState, InboxActionsType } from './inbox.types';

const initialState = {
    inbox: [],
    isFetchingInbox: false,
    isSaving: false,
    hasInboxSaved: false,
    isDownloadingFile: false,
} as IInboxReducerState;

const organiseInbox = (inbox, scenarios) => {
    const inboxWithCurrentFileVersionsAppended = inbox.map(inboxItem => ({
        ...inboxItem,
        currentActiveFileVersion: scenarios.find(({ ukId }) => ukId === inboxItem.ukId)
            .activeFileVersion,
    }));
    return orderBy(inboxWithCurrentFileVersionsAppended, ['validFrom'], 'desc');
};

const InboxReducer = createReducer<IInboxReducerState, InboxActionsType>(initialState)
    .handleAction(InboxActions.fetchInbox, state => ({
        ...state,
        isFetchingInbox: true,
        hasInboxSaved: false,
        inboxError: '',
    }))
    .handleAction(InboxActions.fetchInboxComplete, (state, action) => ({
        ...state,
        isFetchingInbox: false,
        inbox: organiseInbox(action.payload.inbox, action.payload.scenarios),
    }))
    .handleAction(InboxActions.fetchInboxError, (state, action) => ({
        ...state,
        isFetchingInbox: false,
        inboxError: action.payload.error,
    }))
    .handleAction(InboxActions.downloadScenarioFile, state => ({
        ...state,
        isDownloadingFile: true,
    }))
    .handleAction(
        InboxActions.downloadScenarioFileComplete,
        (state, action) => {
            const { blob, fileName } = action.payload;
            fileDownload(blob, fileName);
            return {
                ...state,
                isDownloadingFile: false,
            };
        },
    )
    .handleAction(InboxActions.downloadScenarioFileError, (state, action) => ({
        ...state,
        isDownloadingFile: false,
        inboxError: action.payload.error,
    }))
    .handleAction(InboxActions.approveScenario, state => ({
        ...state,
        isSaving: true,
        saveError: '',
        hasInboxSaved: false,
    }))
    .handleAction(InboxActions.approveScenarioComplete, state => ({
        ...state,
        isSaving: false,
        hasInboxSaved: true,
    }))
    .handleAction(InboxActions.approveScenarioError, (state, action) => ({
        ...state,
        isSaving: false,
        saveError: action.payload.error,
        hasInboxSaved: false,
    }))
    .handleAction(InboxActions.declineScenario, state => ({
        ...state,
        isSaving: false,
        hasInboxSaved: false,
    }))
    .handleAction(InboxActions.declineScenarioComplete, state => ({
        ...state,
        isSaving: false,
        hasInboxSaved: true,
    }))
    .handleAction(InboxActions.declineScenarioError, (state, action) => ({
        ...state,
        isSaving: false,
        saveError: action.payload.error,
        hasInboxSaved: false,
    }));

export type InboxReducerType = StateType<typeof InboxReducer>;

export default InboxReducer;
