import { createStandardAction, createCustomAction, createAction } from 'typesafe-actions';
import { IInboxResponse, ErrorType, InBoxBlobFile } from './inbox.types';
import { inboxActionTypes } from './inboxConstants';
import { IScenario } from '../../interfaces/globals';

const changeStatus = (scenario: IScenario, comments: any, committee: any) => {
    const formData = new FormData();
    const approvalData = {
        id: scenario.id,
        ukId: scenario.ukId,
        type: 'ApprovalDetails',
        comments,
        mtcrApprovalCommittee: committee,
    };
    formData.append(
        'approvalDetails',
        new Blob([JSON.stringify(approvalData)], {
            type: 'application/json',
        }),
    );

    // Testing the Blob / FormData stuff is painful, so adding
    // json property to payload for testing only
    return {
        payload: formData,
        json: approvalData,
    };
};

// Inbox Actions
export const fetchInbox = createStandardAction(inboxActionTypes.FETCH_INBOX)<undefined>();
export const fetchInboxComplete = createStandardAction(inboxActionTypes.FETCH_INBOX_COMPLETE).map(
    ({ inbox, scenarios }: IInboxResponse) => ({
        payload: { inbox, scenarios },
    }),
);
export const fetchInboxError = createStandardAction(inboxActionTypes.FETCH_INBOX_ERROR)<
    ErrorType
>();

export const downloadScenarioFile = createAction(
    inboxActionTypes.DOWNLOAD_SCENARIO_FILE,
    action => (
        scenarioVersion: Pick<IScenario, 'ukId' | 'name' | 'validFrom' | 'pending'> & {
            version: number;
        },
        versionType,
    ) => action({ scenarioVersion, versionType }),
);

export const downloadScenarioFileComplete = createAction(
    inboxActionTypes.DOWNLOAD_SCENARIO_FILE_COMPLETE,
    action => (file: InBoxBlobFile) => action(file),
);

export const downloadScenarioFileError = createStandardAction(
    inboxActionTypes.DOWNLOAD_SCENARIO_FILE_ERROR,
)<ErrorType>();

export const approveScenario = createCustomAction(inboxActionTypes.APPROVE_SCENARIO, type => {
    return (scenario: IScenario, comments: any, committee: any) => ({
        type,
        ...changeStatus(scenario, comments, committee),
    });
});

export const approveScenarioComplete = createAction(inboxActionTypes.APPROVE_SCENARIO_COMPLETE);

export const approveScenarioError = createStandardAction(inboxActionTypes.APPROVE_SCENARIO_ERROR)<
    ErrorType
>();

export const declineScenario = createCustomAction(inboxActionTypes.DECLINE_SCENARIO, type => {
    return (scenario: IScenario, comments: any, committee: any) => ({
        type,
        ...changeStatus(scenario, comments, committee),
    });
});

export const declineScenarioComplete = createAction(inboxActionTypes.DECLINE_SCENARIO_COMPLETE);

export const declineScenarioError = createStandardAction(inboxActionTypes.DECLINE_SCENARIO_ERROR)<
    ErrorType
>();
