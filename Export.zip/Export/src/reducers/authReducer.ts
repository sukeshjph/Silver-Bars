import { authActionTypes } from '../constants';

const initialState = {
    isSigningIn: false,
    failedAuthentication: false,
    userDisplayName: '',
    entitlements: '',
};

export default (state = initialState, action) => {
    switch (action.type) {
        case authActionTypes.AUTHENTICATE: {
            return {
                ...state,
                isSigningIn: true,
                failedAuthentication: false,
            };
        }

        case authActionTypes.RELOAD_SESSION:
        case authActionTypes.AUTHENTICATION_COMPLETE: {
            return {
                ...state,
                ...action.payload.uvaData,
            };
        }

        case authActionTypes.ENTITLEMENTS_COMPLETE: {
            return {
                ...state,
                ...action.payload,
                isSigningIn: false,
                failedAuthentication: action.payload.entitlements === 'UNAUTHORISED',
            };
        }

        case authActionTypes.AUTHENTICATION_ERROR: {
            return {
                ...state,
                isSigningIn: false,
                failedAuthentication: true,
            };
        }

        case authActionTypes.SIGN_OUT: {
            return {
                ...initialState,
            };
        }

        default:
            return state;
    }
};
