import _ from 'lodash';

const getAffectedBatches = (batches, scenario, returnArrayOnly) => {

    if (!scenario) {
        return '';
    }

    const affectedBatches = _.uniq(
        _.compact(
            _.flatten(
                _.map(batches, batch =>
                    _.map(batch.scenarios, scenarioInBatch =>
                        scenario.ukId === scenarioInBatch.ukId ? batch.name : false
                    )
                )
            )
        )
    );
    if (affectedBatches.length > 0) {
        if (returnArrayOnly) {
            return affectedBatches;
        }
        return `Batches affected by this action: ${affectedBatches.join(', ')}`;
    }
    return '';
};

export default getAffectedBatches;