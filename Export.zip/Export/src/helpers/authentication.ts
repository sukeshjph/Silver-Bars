import crypto from 'crypto';
import UUID from 'uuid-js';
import { Observable, Subject, merge } from 'rxjs';
import { ajax } from 'rxjs/ajax';
import { map, share, take, tap } from 'rxjs/operators';
import moment from 'moment';
import _ from 'lodash';

import { getConfig } from '../common/config';

const LS_AUTHENTICATION_CREDENTIALS_KEY = 'userData';
const LS_AUTHENTICATION_TOKEN_KEY = 'uvaToken';

const buildAuthenticationToken = (username, sessionKey, sessionKeyExpires) => {
    const challenge = UUID.create().toString();
    const hours = sessionKeyExpires.split(':')[0];
    const expiryDate = moment()
        .add(hours, 'h')
        .format();

    return {
        challenge: btoa(challenge),
        hash: btoa(
            crypto
                .createHash('sha1')
                .update(sessionKey + challenge)
                .digest('hex'),
        ),
        user: username,
        expiryDate,
    };
};

const signInUrl = (username, password) =>
    `${getConfig().UvaService}/servlet/JSONLoginServlet?ACTION=LDAPLOGIN` +
    '&appName=SDF&userType=LDAP&isSsnExtnReqd=True' +
    `&LOGON_ID=${encodeURIComponent(username)}` +
    `&PASSWORD=${encodeURIComponent(password)}`;

const signInErrorTrigger = new Subject();

export const setAuthenticationCredentials = credentials => {
    localStorage.setItem(LS_AUTHENTICATION_CREDENTIALS_KEY, JSON.stringify(credentials));
};

export const authenticationCredentials = () => {
    const credentials = localStorage.getItem(LS_AUTHENTICATION_CREDENTIALS_KEY);
    return credentials && JSON.parse(credentials);
};

export const authenticationToken = () => {
    const token = localStorage.getItem(LS_AUTHENTICATION_TOKEN_KEY);
    return token && JSON.parse(token);
};

export const setEntitlements = entitlements => {
    const credentials = authenticationCredentials();
    setAuthenticationCredentials({ ...credentials, ...entitlements });
};

export const getSessionFromStorage = () => {
    try {
        if (new Date() < new Date(authenticationToken().expiryDate)) {
            return authenticationCredentials();
        }
        return false;
    } catch (e) {
        return false;
    }
};

export const hasAccess = () =>
    _.includes(['R', 'RW', 'SU'], _.get(getSessionFromStorage(), 'entitlements', ''));

export const isSuperUser = () =>
    _.includes(['SU'], _.get(getSessionFromStorage(), 'entitlements', ''));

export const readWrite = () =>
    _.includes(['RW', 'SU'], _.get(getSessionFromStorage(), 'entitlements', ''));

export const readOnly = () => _.includes(['R'], _.get(getSessionFromStorage(), 'entitlements', ''));

const authenticate$ = (observer, username, password) => {
    const subscription = merge(
        signInErrorTrigger.pipe(
            map(() => {
                throw new Error('Pending sign-in was superseded');
            }),
        ),
        ajax({ crossDomain: true, url: signInUrl(username, password) }).pipe(
            tap(({ response }) => {
                const { authCred } = response;
                const sessionKeyExpires = response.session_key_expires_after;

                if (authCred) {
                    const { location, sessionKey, userName, userFullName } = authCred;

                    setAuthenticationCredentials({
                        location,
                        userDisplayName: userFullName,
                        userName,
                    });

                    localStorage.setItem(
                        LS_AUTHENTICATION_TOKEN_KEY,
                        JSON.stringify(
                            buildAuthenticationToken(username, sessionKey, sessionKeyExpires),
                        ),
                    );
                } else {
                    throw new Error(response.error);
                }
            }),
            map(authenticationCredentials),
        ),
    ).subscribe(observer);

    return () => subscription.unsubscribe();
};

export const signIn = (username, password) => {
    signInErrorTrigger.next();
    return Observable.create(observer => authenticate$(observer, username, password)).pipe(
        take(1),
        share(),
    );
};

export const signOut = () => {
    signInErrorTrigger.next();
    localStorage.removeItem(LS_AUTHENTICATION_CREDENTIALS_KEY);
    localStorage.removeItem(LS_AUTHENTICATION_TOKEN_KEY);
};
