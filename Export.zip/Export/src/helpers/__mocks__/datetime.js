export const now =  () => '2018-01-01';
export const formatDateTime = () => '2018-01-01';
export const formatDate = () => '2018-01-01';