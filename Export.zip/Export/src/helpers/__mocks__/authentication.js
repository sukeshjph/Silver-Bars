export const authenticationToken =  () => ({
    challenge: 'Y2ZiMGFkMmMtMTg5OC00ZjBjLWI3YzgtYzJmZWIzNDI5MGNm',
    hash: 'MWExOTAzNzc5YTJjNzIyNTdjMzc2ZTBmOTI0YmI4NzBlNTI3MTY4OA==',
    user: '1395651',
    expiryDate: '2018-04-16T17:02:53+01:00',
});

export const authenticationCredentials =  () => ({
    location: 'SG',
    userDisplayName: '1395651',
    userName: '1395651',
});

export const getSessionFromStorage = () => ({});

export const readWrite = jest.fn(() => true);
export const isSuperUser = jest.fn(() => true);