import { StringTMap } from '../interfaces/globals';

export const pipe = functions => data => functions.reduce((value, func) => func(value), data);

export const getformattedColumnfromCamel = (column: string): string => {
    let i: number;
    let l: number;
    const regexCaps = /[A-Z]/;

    if (typeof column !== 'string') {
        throw new Error('The column must be a string.');
    }
    const output: string[] = [];
    for (i = 0, l = column.length; i < l; i += 1) {
        if (i === 0) {
            output.push(column[i].toUpperCase());
        } else {
            if (i > 0 && regexCaps.test(column[i])) {
                output.push(' ');
            }
            output.push(column[i]);
        }
    }

    return output.join('');
};

export const get = (obj, path, defaultValue) =>
    path.split('.').reduce((a, c) => (a && a[c] ? a[c] : defaultValue || null), obj);

export const flatten = <T extends {}>(arrToBeFlattened: T[]): T[] =>
    arrToBeFlattened.reduce((a, b) => a.concat(b), [] as T[]);

export const isUndefined = val => typeof val === 'undefined' || val === undefined;

export const uniq = <T extends {}>(inArray: T[]): T[] => [...new Set(inArray)];

export const pick = <T extends {}>(inObject: StringTMap<T>, keys: string[]): StringTMap<T> =>
    keys.reduce(
        (finalObj, key) => (inObject[key] ? { ...finalObj, [key]: inObject[key] } : finalObj),
        {},
    );

export const stringToJsonObject = (givenString: string): any => {
    if (givenString.indexOf(',') === -1) {
        const KeyValue = givenString.substring(1, givenString.length - 1).split(':');
        return JSON.stringify({ [KeyValue[0]]: KeyValue[1] });
    }

    return '';
};

export const getPascalCase = (inputStr: string): string => {
    const allLowCase = inputStr.toLowerCase();
    return allLowCase[0].toUpperCase() + allLowCase.slice(1);
};

export const setObjectValues = <T extends {}>(inputObject: StringTMap<T>, value: T) =>
    Object.keys(inputObject).reduce(
        (acc, curKey) => ({
            ...acc,
            [curKey]: value,
        }),
        {},
    );

export const ObjectWithoutKey = <T extends {}>(
    inputObject: StringTMap<T>,
    excludeKey: string,
): StringTMap<T> =>
        Object.keys(inputObject)
            .filter(key => key !== excludeKey)
            .reduce((finalObj, key) => ({ ...finalObj, [key]: inputObject[key] }), {});
