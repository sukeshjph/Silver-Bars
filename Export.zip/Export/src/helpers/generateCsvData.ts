const generateCsvData = (data, columns) =>
    data.map(audit => {
        const row = {};
        columns.forEach(column => {
            row[column.key] = column.csvFormatter ? column.csvFormatter(audit[column.key]) : audit[column.key];
        });
        return row;
    });


export default generateCsvData;