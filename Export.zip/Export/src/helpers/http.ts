import { from as fromPromise} from 'rxjs';
import 'whatwg-fetch';
import { authenticationToken, authenticationCredentials } from './authentication';
import { configUrl, apiUrls } from '../constants';
import { get } from './utilities';



const getJSON = input => {
    let result = {};
    try {
        result = JSON.parse(input);
    } catch (e) {
        result = {};
    }
    return result;
};

const respond = async response => {
    const json = getJSON(await response.text());
    const defaultError = 'An unknown error has occurred';
    if (!`${response.status}`.startsWith('2') && response.status !== 0) {
        const error =
            get(json, 'apiError.message', defaultError) || get(json, 'error', defaultError);
        throw new Error(error);
    }
    return json;
};

const getConfigFromServer = async () => {
    if (ISLOCAL === true) return apiUrls;
    const response = await fetch(configUrl);
    const json = getJSON(await response.text());
    if (!`${response.status}`.startsWith('2') && response.status !== 0) {
        throw new Error('Unable to get app configuration');
    }
    return json;
};

const addAuthorization = options => {
    const { hash, challenge } = authenticationToken();
    const username = authenticationCredentials().userName;
    return {
        ...options,
        headers: {
            ...options.headers,
            hash,
            challenge,
            username,
        },
    };
};
const getData = (url, options = {}) =>
    fromPromise(
        fetch(
            url,
            addAuthorization({
                ...options,
                headers: {
                    ...options.headers,
                    'Content-Type': 'application/json',
                },
            }),
        ).then(response => respond(response, url)),
    );

const getFile = (url, options = {}) =>
    fromPromise(
        fetch(
            url,
            addAuthorization(
                Object.assign(
                    {
                        headers: {
                            'Content-Type': 'application/json',
                        },
                    },
                    options,
                ),
            ),
        ).then(response => {
            if (!`${response.status}`.startsWith('2') && response.status !== 0) {
                throw new Error({
                    status: response.status,
                    url,
                    message: `Received status ${response.status} for url ${url}`,
                });
            }
            return response.blob().then(blob => blob);
        }),
    );

const postData = (url, data, options = {}) =>
    fromPromise(
        fetch(
            url,
            addAuthorization(
                Object.assign(
                    {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: data ? JSON.stringify(data) : null,
                    },
                    options,
                ),
            ),
        ).then(response => respond(response, url)),
    );

const postFormData = (url, data, options = {}) =>
    fromPromise(
        fetch(
            url,
            addAuthorization(
                Object.assign(
                    {
                        method: 'POST',
                        body: data,
                    },
                    options,
                ),
            ),
        ).then(response => respond(response, url)),
    );

const putData = (url, data, options = {}) =>
    fromPromise(
        fetch(
            url,
            addAuthorization(
                Object.assign(
                    {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: data ? JSON.stringify(data) : null,
                    },
                    options,
                ),
            ),
        ).then(response => respond(response, url)),
    );

const deleteData = (url, data, options = {}) =>
    fromPromise(
        fetch(
            url,
            addAuthorization(
                Object.assign(
                    {
                        method: 'DELETE',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: data ? JSON.stringify(data) : null,
                    },
                    options,
                ),
            ),
        ).then(response => respond(response, url)),
    );

const getDataFromSabreStore = (url, options = {}) =>
    getData(url, {
        ...options,
        headers: {
            ...options.headers,
            User: authenticationCredentials().userName,
        },
    });

const getFileFromSabreStore = (url, options = {}) =>
    getFile(url, {
        ...options,
        headers: {
            ...options.headers,
            User: authenticationCredentials().userName,
        },
    });

const getDataFromMDS = (url, data, options = {}) =>
    fromPromise(
        fetch(
            url,
            Object.assign(
                {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        Accept: 'application/json',
                        Authorization: `UVA user=${
                            authenticationCredentials().userName
                        }, challenge=${authenticationToken().challenge}, hash=${
                            authenticationToken().hash
                        }`,
                    },
                    body: data ? JSON.stringify(data) : null,
                },
                options,
            ),
        ).then(response => respond(response, url)),
    );

export default {
    getConfigFromServer,
    getFile,
    getData,
    postData,
    postFormData,
    putData,
    deleteData,
    getDataFromSabreStore,
    getFileFromSabreStore,
    getDataFromMDS,
};
