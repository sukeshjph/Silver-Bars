const getFormFieldClass = isValid => isValid ? 'stress__form__field' : 'stress__form__field--error';

export default getFormFieldClass;