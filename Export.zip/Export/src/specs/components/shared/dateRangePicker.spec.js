import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import moment from 'moment';
import DateRangePicker from '../../../components/shared/dateRangePicker';
import { DEFAULT_NUMBER_OF_AUDIT_DAYS_DISPLAYED, API_DATE_FORMAT } from '../../../constants';





describe('DateRangePicker component', () => {
    let wrapper;
    const testDate = '01/01/2018';
    const initialProps = {
        fetchByDateRange: jest.fn(),
    };

    beforeEach(() => {
        // Mock internal Date to ensure Moment output is consistent
        Date.now = jest.fn(() => 1528105933097); // 4th June 2018

        jest.spyOn(initialProps, 'fetchByDateRange');
        jest.spyOn(DateRangePicker.prototype, 'viewLastMonth');
        wrapper = shallow(<DateRangePicker { ...initialProps } />);
    });

    afterEach(() => {
        jest.restoreAllMocks();
    });

    describe('rendering', () => {
        it('should render a date range component', () => {
            expect(toJson(wrapper)).toMatchSnapshot();
        });
        it('sets the initialState.validToDate to today', () => {
            const today = moment().format(API_DATE_FORMAT);
            const validToDate = wrapper.state('validToDate').format(API_DATE_FORMAT);
            expect(validToDate).toEqual(today);
        });
        it('sets the initialState.validFromDate to DEFAULT_NUMBER_OF_AUDIT_DAYS_DISPLAYED days in the past', () => {
            const expectedPastDate = moment().subtract(DEFAULT_NUMBER_OF_AUDIT_DAYS_DISPLAYED, 'days').format(API_DATE_FORMAT);
            const validFromDate = wrapper.state('validFromDate').format(API_DATE_FORMAT);
            expect(validFromDate).toEqual(expectedPastDate);
        });
        it('displays a button that links to last month', () => {
            expect(wrapper.find('.stress--date-range--last-month').text()).toContain('May');
        });
        it('renders a DatePicker component to handle validFromDate', () => {
            const datePicker = wrapper.find('DatePicker').at(0);
            expect(datePicker.props().selectsStart).toBe(true);
            expect(datePicker.props().selected).toBe(wrapper.state('validFromDate'));
            expect(datePicker.props().dateFormat).toBe('DD/MM/YYYY');
            expect(datePicker.props().placeholderText).toBe('Start date');
        });
        it('renders a DatePicker component to handle validToDate', () => {
            const datePicker = wrapper.find('DatePicker').at(1);
            expect(datePicker.props().selectsEnd).toBe(true);
            expect(datePicker.props().selected).toBe(wrapper.state('validToDate'));
            expect(datePicker.props().dateFormat).toBe('DD/MM/YYYY');
            expect(datePicker.props().placeholderText).toBe('End date');
        });
    });

    describe('selecting new FROM date', () => {
        it('sets state.validFromDate', () => {
            wrapper.instance().changeValidFromDateSelection(testDate);
            expect(wrapper.state('validFromDate')).toBe(testDate);
        });
        it('calls the fetch method', () => {
            const spy = jest.spyOn(initialProps, 'fetchByDateRange');
            wrapper.instance().changeValidFromDateSelection(testDate);
            expect(spy).toHaveBeenCalledWith(testDate, wrapper.state('validToDate'));
        });
    });

    describe('selecting new TO date', () => {
        it('sets state.validToDate', () => {
            wrapper.instance().changeValidToDateSelection(testDate);
            expect(wrapper.state('validToDate')).toBe(testDate);
        });
        it('calls the fetch method', () => {
            const spy = jest.spyOn(initialProps, 'fetchByDateRange');
            wrapper.instance().changeValidToDateSelection(testDate);
            expect(spy).toHaveBeenCalledWith(wrapper.state('validFromDate'), testDate);
        });
        describe('TO date field has been cleared', () => {
            it('sets state.validFromDate to initialState.validFromDate', () => {
                wrapper.instance().changeValidToDateSelection();
                expect(wrapper.state('validFromDate')).toBe(wrapper.instance().initialState.validFromDate);
            });
            it('calls the fetch method', () => {
                const spy = jest.spyOn(initialProps, 'fetchByDateRange');
                wrapper.instance().changeValidToDateSelection();
                expect(spy).toHaveBeenCalledWith(wrapper.instance().initialState.validFromDate, undefined);
            });
        });
    });

    describe('previous month button', () => {
        it('handles the click', () => {
            wrapper.find('.stress--date-range--last-month').at(0).simulate('click');
            expect(DateRangePicker.prototype.viewLastMonth).toHaveBeenCalled();
        });
        it('sets state.validFromDate to the first day of previous month', () => {
            wrapper.instance().viewLastMonth();
            expect(moment(wrapper.state('validFromDate')).isSame('2018-05-01T09:52:13.097Z')).toBe(true);
        });
        it('sets state.validToDate to the last day of previous month', () => {
            wrapper.instance().viewLastMonth();
            expect(moment(wrapper.state('validToDate')).isSame('2018-05-31T09:52:13.097Z')).toBe(true);
        });
        it('triggers a fetch with last month\'s start and end dates', () => {
            wrapper.instance().viewLastMonth();
            expect(initialProps.fetchByDateRange).toHaveBeenCalled();
        });
    });

    describe('clicking reset button', () => {
        let resetButton;
        beforeEach(() => {
            resetButton = wrapper.find('.stress--date-range--reset');
        });
        it('sets state.validFromDate to the initialState', () => {
            wrapper.setState({ validFromDate: 'nonsense' });
            resetButton.simulate('click');
            expect(wrapper.state('validFromDate')).toEqual(wrapper.instance().initialState.validFromDate);
        });
        it('sets state.validToDate to the initialState', () => {
            wrapper.setState({ validToDate: 'nonsense' });
            resetButton.simulate('click');
            expect(wrapper.state('validToDate')).toEqual(wrapper.instance().initialState.validToDate);
        });
        it('triggers a fetch', () => {
            wrapper.setState({
                validFromDate: 'nonsense',
                validToDate: 'nonsense',
            });
            wrapper.instance().resetDates();
            expect(initialProps.fetchByDateRange).toHaveBeenCalledWith(
                wrapper.instance().initialState.validFromDate,
                wrapper.instance().initialState.validToDate,
            );
        });
    });
});