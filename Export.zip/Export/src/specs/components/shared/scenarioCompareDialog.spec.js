import React from 'react';
import _ from 'lodash';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import ScenarioCompareDialog, {
    convertDiffChangesToStrings,
} from '../../../components/shared/scenarioCompareDialog';
import mockDiff from '../../mocks/mockDiff';
import { TableHeadWithSorting } from '../../../components/shared/tableHeadWithSorting';
import ErrorMessage from '../../../components/shared/errorMessage';

jest.mock('../../../helpers/csvToBlobUrl');

describe('Scenario Compare Dialog', () => {
    const initialProps = {
        fetchDiff: () => undefined,
        closeHandler: () => undefined,
        fileVersionToCompare: 1,
        scenario: { ukId: '1' },
        diff: {},
        isFetchingDiff: false,
        fetchDiffError: '',
    };
    const setup = props => shallow(<ScenarioCompareDialog {...props} />);
    let wrapper;

    it('should render', () => {
        wrapper = setup(initialProps);
        expect(toJson(wrapper)).toMatchSnapshot();
    });

    describe('mounting', () => {
        describe('file version is greater than 1', () => {
            const fetchDiff = jest.fn();
            const props = {
                ...initialProps,
                fetchDiff,
                scenario: {
                    ukId: 1,
                    activeFileVersion: 2,
                },
            };
            it('fetches a diff', () => {
                wrapper = setup(props);
                wrapper.instance().componentDidMount(); // can't mount dialogs for some reason
                expect(fetchDiff).toHaveBeenCalledWith(
                    props.scenario.ukId,
                    props.scenario.activeFileVersion,
                    initialProps.fileVersionToCompare,
                );
            });
            it('displays a spinner', () => {
                wrapper = setup({ ...props, isFetchingDiff: true });
                expect(wrapper.find('.stress-loading')).toHaveLength(1);
            });
        });

        describe('file version is 0', () => {
            const props = {
                ...initialProps,
                fetchDiff: jest.fn(),
                scenario: {
                    ukId: 1,
                    activeFileVersion: 0,
                },
            };
            it("doesn't fetch a diff", () => {
                jest.spyOn(props, 'fetchDiff');
                wrapper = setup(props);
                wrapper.instance().componentDidMount(); // can't mount dialogs for some reason
                expect(props.fetchDiff).not.toHaveBeenCalled();
            });
            it('displays an error', () => {
                wrapper = setup({ ...props, isFetchingDiff: true });
                expect(wrapper.find(ErrorMessage).props().message).toContain(
                    'This is version 1 of the file. There is nothing to compare it to.',
                );
            });
        });
    });

    describe('filter buttons', () => {
        beforeEach(() => {
            const props = {
                ...initialProps,
            };
            wrapper = setup(props);
            wrapper.setProps({
                diff: {
                    comparison: mockDiff,
                    ukId: '1',
                },
            });
        });

        
        describe('added filter', () => {
            it('shows only rows that were added', () => {
                wrapper.find('.stress--file-compare--key--button-added').simulate('click');
                expect(
                    wrapper
                        .find('.stress-table')
                        .at(0)
                        .hasClass('stress--file-compare__show-added'),
                ).toBeTruthy();
            });
        });
        describe('removed filter', () => {
            it('shows only rows that were removed', () => {
                wrapper.find('.stress--file-compare--key--button-removed').simulate('click');
                expect(
                    wrapper
                        .find('.stress-table')
                        .at(0)
                        .hasClass('stress--file-compare__show-removed'),
                ).toBeTruthy();
            });
        });
        describe('modified filter', () => {
            it('shows only rows that were modified', () => {
                wrapper.find('.stress--file-compare--key--button-modified').simulate('click');
                expect(
                    wrapper
                        .find('.stress-table')
                        .at(0)
                        .hasClass('stress--file-compare__show-modified'),
                ).toBeTruthy();
            });
        });
        describe('all changes filter', () => {
            it('shows rows that were added, removed and modified', () => {
                wrapper.find('.stress--file-compare--key--button-all').simulate('click');
                expect(
                    wrapper
                        .find('.stress-table')
                        .at(0)
                        .hasClass('stress--file-compare__show-all'),
                ).toBeTruthy();
            });
        });
        describe('everything filter', () => {
            it('shows every row in the file', () => {
                wrapper.find('.stress--file-compare--key--button-unchanged').simulate('click');
                expect(
                    wrapper
                        .find('.stress-table')
                        .at(0)
                        .hasClass('stress--file-compare__show-unchanged'),
                ).toBeTruthy();
            });
        });
    });

    describe('rendering the title', () => {
        it('sets the title for active versions', () => {
            wrapper = setup({
                ...initialProps,
                fileVersionToCompare: 1,
                scenario: { ukId: '1', activeFileVersion: 2, name: 'test scenario' },
            });
            expect(
                wrapper
                    .find('.stress--file-compare--title--text')
                    .at(0)
                    .text(),
            ).toBe(
                'Showing differences applied to version 1 of test scenario (compared to version 2)',
            );
        });
        it('sets the title for activeFileVersion of zero', () => {
            wrapper = setup({
                ...initialProps,
                fileVersionToCompare: 1,
                scenario: { ukId: '1', activeFileVersion: 0, name: 'test scenario' },
            });
            expect(
                wrapper
                    .find('.stress--file-compare--title--text')
                    .at(0)
                    .text(),
            ).toBe('No previous version exists for comparison');
        });
        it('sets the title for pending versions', () => {
            wrapper = setup({
                ...initialProps,
                fileVersionToCompare: 'PENDING',
                scenario: { ukId: '1', activeFileVersion: 1, name: 'test scenario' },
            });
            expect(
                wrapper
                    .find('.stress--file-compare--title--text')
                    .at(0)
                    .text(),
            ).toBe(
                'Showing differences applied to the proposed version of test scenario (compared to version 1)',
            );
        });
    });

    describe('rendering the diff', () => {
        beforeEach(() => {
            const props = {
                ...initialProps,
            };
            wrapper = setup(props);
            wrapper.setProps({
                diff: {
                    comparison: mockDiff,
                    ukId: '1',
                },
            });
        });
        it('renders a sortable header', () => {
            const header = wrapper.find(TableHeadWithSorting);
            expect(header).toHaveLength(1);
        });
        it('sorts by descending order', () => {
            const header = wrapper.find(TableHeadWithSorting);
            expect(header.props().order).toBe('desc');
        });
        it('has the correct column headings', () => {
            const header = wrapper.find(TableHeadWithSorting);
            const { columnDefs } = header.props();
            expect(columnDefs).toHaveLength(mockDiff[0].length - 1);
            expect(columnDefs[0].label).toBe(mockDiff[0][1]); // Check first cell is correct
            expect(columnDefs[columnDefs.length - 1].label).toBe(
                mockDiff[0][mockDiff[0].length - 1],
            ); // Check last cell is correct
        });
        it('styles new rows', () => {
            expect(
                wrapper
                    .find('.stress-table tbody tr')
                    .at(0)
                    .hasClass('add-row'),
            ).toBeTruthy();
        });
        it('styles removed rows', () => {
            expect(
                wrapper
                    .find('.stress-table tbody tr')
                    .at(1)
                    .hasClass('remove-row'),
            ).toBeTruthy();
        });
        it('styles modified rows', () => {
            expect(
                wrapper
                    .find('.stress-table tbody tr')
                    .at(2)
                    .hasClass('modify-row'),
            ).toBeTruthy();
        });
        it('styles changes within the modified rows', () => {
            expect(
                wrapper
                    .find('.stress-table tbody tr')
                    .at(2)
                    .find('td')
                    .at(3)
                    .find('span.add')
                    .exists(),
            ).toBeTruthy();
            expect(
                wrapper
                    .find('.stress-table tbody tr')
                    .at(2)
                    .find('td')
                    .at(3)
                    .find('span.remove')
                    .exists(),
            ).toBeTruthy();
        });
        it("doesn't render a diff if ukId is different", () => {
            const props = {
                ...initialProps,
                diff: {
                    comparison: mockDiff,
                    ukId: '2',
                },
            };
            wrapper = setup(props);
            expect(wrapper.find('.stress-table')).toHaveLength(0);
        });
    });

    describe('closing the dialog', () => {
        it('calls props.closeHandler it top button is clicked', () => {
            jest.spyOn(initialProps, 'closeHandler');
            wrapper = setup(initialProps);
            wrapper
                .find('.stress--file-compare--close')
                .at(0)
                .simulate('click');
            expect(initialProps.closeHandler).toHaveBeenCalled();
        });
        it('calls props.closeHandler it bottom button is clicked', () => {
            jest.spyOn(initialProps, 'closeHandler');
            wrapper = setup(initialProps);
            wrapper
                .find('.stress--file-compare--close')
                .at(1)
                .simulate('click');
            expect(initialProps.closeHandler).toHaveBeenCalled();
        });
    });

    describe('downloading the diff', () => {
        it('joins modified cells with "vs"', () => {
            const diff = convertDiffChangesToStrings(mockDiff);
            expect(_.includes(diff[3][4], ' (vs) ')).toBeTruthy();
        });
    });
});
