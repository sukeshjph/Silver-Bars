import React from 'react';
import { shallow, mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import { BatchManager } from '../../../components/batchManager';
import {
    PATHS_LIMIT,
    SCENARIO_LIMIT,
} from '../../../components/batchManager/batchManagerConstants';
import LoadingData from '../../../components/shared/loadingData';
import ErrorMessage from '../../../components/shared/errorMessage';
import mockBatchAuditListResponse from '../../mocks/mockBatchAuditListResponse';
import mockBatchListResponse from '../../mocks/mockBatchListResponse';
import mockScenarioResponse from '../../mocks/mockScenarioResponse';

jest.mock('../../../common/config');
jest.mock('../../../helpers/dateTime');
jest.mock('../../../helpers/tableSorter');
jest.mock('../../../helpers/authentication');
jest.mock('../../../components/shared/userPopover');

describe('BatchManager component', () => {
    const initialProps = {
        actions: {
            saveBatch: () => undefined,
            signOut: () => undefined,
            fetchBatchesAndScenarios: () => undefined,
        },
        model: {
            batches: mockBatchListResponse,
            batchAudits: mockBatchAuditListResponse,
            scenarios: mockScenarioResponse,
            isSavingBatch: false,
            isFetchingBatches: false,
            isFetchingScenarios: false,
        },
        user: {
            userDisplayName: '',
            entitlements: '',
            userName: 'Steve',
        },
    };

    const testBatch = {
        ukId: 'tuesday',
        name: 'Tuesday',
        scenarios: [{ ukId: '1', name: '1' }, { ukId: '2', name: '2' }],
    };

    let wrapper;

    beforeEach(() => {
        wrapper = shallow(<BatchManager {...initialProps} />);
    });

    describe('rendering', () => {
        it('should render with initial props and state', () => {
            expect(toJson(wrapper)).toMatchSnapshot();
        });
        it('sets the scenario selection limit to SCENARIO_LIMIT', () => {
            expect(wrapper.state('limit')).toBe(SCENARIO_LIMIT);
        });
    });

    describe('loading', () => {
        it('displays a spinner', () => {
            const newProps = {
                ...initialProps,
                model: {
                    ...initialProps.model,
                    isFetchingBatches: true,
                    isFetchingScenarios: true,
                },
            };
            wrapper.setProps(newProps);
            expect(
                wrapper
                    .find(LoadingData)
                    .shallow()
                    .childAt(0),
            ).toHaveLength(1);
        });
    });

    describe('loading error', () => {
        it('displays if an error is returned with no batches', () => {
            const newProps = {
                ...initialProps,
                model: {
                    ...initialProps.model,
                    error: {},
                    batches: [],
                },
            };
            wrapper.setProps(newProps);
            expect(wrapper.find(ErrorMessage)).toHaveLength(1);
        });
        it('displays if an error is returned with no scenarios', () => {
            const newProps = {
                ...initialProps,
                model: {
                    ...initialProps.model,
                    error: {},
                    scenarios: [],
                },
            };
            wrapper.setProps(newProps);
            expect(wrapper.find(ErrorMessage)).toHaveLength(1);
        });
    });

    describe('component mounting', () => {
        it('fetches batch and scenario data', () => {
            const spy = jest.spyOn(initialProps.actions, 'fetchBatchesAndScenarios');
            mount(<BatchManager {...initialProps} />);
            expect(spy).toHaveBeenCalled();
        });
    });

    describe('receiving props', () => {
        const newProps = {
            ...initialProps,
            model: {
                ...initialProps.model,
                batches: [testBatch, mockBatchListResponse[5]],
            },
        };
        it('determines user edit permissions', () => {
            wrapper.setProps(newProps);
            expect(wrapper.state('userCanEdit')).toBe(true);
        });
        it('updates state.selectedBatch if one is selected', () => {
            wrapper.setState({
                selectedBatch: testBatch,
            });
            wrapper.setProps(newProps);
            expect(wrapper.state('selectedBatch').name).toBe(testBatch.name);
        });
        it('defaults state.selectedBatch to Monday if none is selected', () => {
            wrapper.setState({
                selectedBatch: null,
            });
            wrapper.setProps(newProps);
            expect(wrapper.state('selectedBatch').name).toBe('Monday');
        });
    });

    describe('selecting a batch', () => {
        beforeEach(() => {
            wrapper.setState({
                removed: 2,
                added: 2,
                limit: 28,
                availableFilterText: 'something',
                deltaFilterText: 'something',
                selectedBatch: mockBatchListResponse[0],
            });
        });
        it('sets different scenario selection limit for PATHS batch', () => {
            wrapper.instance().setSelectedBatch({}, 'paths');
            expect(wrapper.state('limit')).toBe(PATHS_LIMIT);
        });
        it('updates the scenarioDelta list', () => {
            jest.spyOn(wrapper.instance(), 'updateAddedAndRemovedList');
            wrapper.instance().setSelectedBatch({}, 'paths');
            expect(wrapper.instance().updateAddedAndRemovedList).toHaveBeenCalled();
        });
        it('adds the selected batch to state', () => {
            wrapper.instance().setSelectedBatch({}, 'paths');
            expect(wrapper.state('selectedBatch').name).toEqual('Paths');
        });
    });

    describe('getting batch data from store', () => {
        it('returns matching batch if ukId arg is passed ', () => {
            const batch = wrapper.instance().getBatchFromStore('friday');
            expect(batch.name).toBe('Friday');
        });
        it('returns currently selected batch if no ukId arg is passed', () => {
            wrapper.setState({
                selectedBatch: mockBatchListResponse[0],
            });
            const batch = wrapper.instance().getBatchFromStore();
            expect(batch.name).toBe('Thursday');
        });
    });

    describe('adding a scenario to a batch', () => {
        it('does nothing if user has read-only permissions', () => {
            wrapper.setState({ userCanEdit: false });
            const outcome = wrapper.instance().addScenarioToBatch({});
            expect(outcome).toBe(false);
        });

        it('does nothing if user is trying to breach selection limit', () => {
            wrapper.setState({
                limit: 2,
                userCanEdit: true,
                selectedBatch: mockBatchListResponse[0],
            });
            const outcome = wrapper.instance().addScenarioToBatch({});
            expect(outcome).toBe(false);
        });

        it('adds the scenario to state.selectedBatch', () => {
            wrapper.setState({
                userCanEdit: true,
                selectedBatch: testBatch,
            });
            wrapper.instance().addScenarioToBatch({ ukId: '4', name: '4' });
            expect(wrapper.state('selectedBatch').scenarios).toEqual([
                { ukId: '1', name: '1' },
                { ukId: '2', name: '2' },
                { ukId: '4', name: '4' },
            ]);
        });

        it('updates the list of added items', () => {
            wrapper.setState({
                limit: 3,
                userCanEdit: true,
                selectedBatch: testBatch,
            });
            jest.spyOn(wrapper.instance(), 'updateAddedAndRemovedList');
            wrapper.instance().addScenarioToBatch({ ukId: '3', name: '3' });
            expect(wrapper.instance().updateAddedAndRemovedList).toHaveBeenCalled();
        });
    });

    describe('removing a scenario from a batch', () => {
        it('does nothing if user has read-only permissions', () => {
            wrapper.setState({ userCanEdit: false });
            const outcome = wrapper.instance().removeScenarioFromBatch({});
            expect(outcome).toBe(false);
        });

        it('removes the scenario from state.selectedBatch', () => {
            wrapper.setState({
                userCanEdit: true,
                selectedBatch: testBatch,
            });
            wrapper.instance().removeScenarioFromBatch({ ukId: '2', name: '2' });
            expect(wrapper.state('selectedBatch').scenarios).toEqual([{ ukId: '1', name: '1' }]);
        });

        it('updates the list of removed items', () => {
            wrapper.setState({
                limit: 3,
                userCanEdit: true,
                selectedBatch: testBatch,
            });
            jest.spyOn(wrapper.instance(), 'updateAddedAndRemovedList');
            wrapper.instance().removeScenarioFromBatch({ ukId: '2', name: '2' });
            expect(wrapper.instance().updateAddedAndRemovedList).toHaveBeenCalled();
        });
    });

    describe('saving changes to a batch', () => {
        it('dispatches the "saveBatch" action with the user\'s comments', () => {
            jest.spyOn(initialProps.actions, 'saveBatch');
            wrapper.instance().handleSaveClick('some comments');
            expect(initialProps.actions.saveBatch).toHaveBeenCalledWith({
                ...wrapper.state('selectedBatch'),
                comments: 'some comments',
            });
        });
    });

    describe('Undo and ok buttons', () => {
        let spy;
        beforeAll(() => {
            spy = jest
                .spyOn(BatchManager.prototype, 'setSelectedBatch')
                .mockImplementation(() => undefined);
        });
        afterEach(() => {
            spy.mockClear();
        });
        it('clicking the "undo" button', () => {
            wrapper.instance().handleUndoClick();
            expect(spy).toHaveBeenCalled();
        });
        it('clicking the "OK" button', () => {
            wrapper.instance().handleDoneClick();
            expect(spy).toHaveBeenCalled();
        });
    });
});
