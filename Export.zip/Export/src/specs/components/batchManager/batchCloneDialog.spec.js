import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import Dialog from '@material-ui/core/Dialog';
import ListItem from '@material-ui/core/ListItem';
import BatchCloneDialog from '../../../components/batchManager/batchCloneDialog';


describe('Clone Dialog', () => {

    let wrapper;

    const initialProps = {
        cloneBatch: () => undefined,
        closeCloneDialog: () => undefined,
        batches: [{ id: '1', ukId: '1' }, { id: '2', ukId: '2' }, { id: '3', ukId: '3' }],
        selectedBatch: { id: '1', ukId: '1' },
    };

    beforeEach(() => {
        wrapper = shallow(<BatchCloneDialog { ...initialProps } />);
    });

    it('renders a Dialog', () => {
        expect(toJson(wrapper)).toMatchSnapshot();
        expect(wrapper.find(Dialog)).toHaveLength(1);
    });

    it('renders a list batches', () => {
        expect(wrapper.find('.stress__clone-list__batch')).toHaveLength(initialProps.batches.length);
    });

    it('disables the selected batch', () => {
        expect(wrapper.find(ListItem).at(0).props().disabled).toBe(true);
        expect(wrapper.find(ListItem).at(1).props().disabled).toBe(false);
    });

    describe('clicking a batch', () => {
        beforeEach(() => {
            jest.spyOn(initialProps, 'cloneBatch');
            jest.spyOn(initialProps, 'closeCloneDialog');
            wrapper = shallow(<BatchCloneDialog { ...initialProps } />);
            wrapper.find(ListItem).at(1).simulate('click');
        });
        it('closes the dialog', () => {
            expect(initialProps.closeCloneDialog).toHaveBeenCalled();
        });
        it('selects the batch', () => {
            expect(initialProps.cloneBatch).toHaveBeenCalledWith('2');
        });
    });

    describe('clicking the cancel button', () => {
        beforeEach(() => {
            jest.spyOn(initialProps, 'closeCloneDialog');
            wrapper = shallow(<BatchCloneDialog { ...initialProps } />);
            wrapper.find('.stress__clone-list__cancel').at(0).simulate('click');
        });
        it('closes the dialog', () => {
            expect(initialProps.closeCloneDialog).toHaveBeenCalled();
        });
    });

});