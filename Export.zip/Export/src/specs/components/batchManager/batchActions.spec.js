import _ from 'lodash';
import * as batchManagerActions from '../../../components/batchManager/batchManagerActions';
import { batchActionTypes } from '../../../components/batchManager/batchManagerConstants';

describe('Batch "fetchBatches" action', () => {
    it('dispatches a FETCH_BATCHES action', () => {
        expect(batchManagerActions.fetchBatches().type)
            .toEqual(batchActionTypes.FETCH_BATCHES);
    });
});

describe('Batch "fetchBatchesAndScenarios" action', () => {
    it('dispatches a FETCH_BATCHES_AND_SCENARIOS action', () => {
        expect(batchManagerActions.fetchBatchesAndScenarios().type)
            .toEqual(batchActionTypes.FETCH_BATCHES_AND_SCENARIOS);
    });
});

describe('Batch "saveBatch" action', () => {
    it('dispatches a SAVE_BATCH action', () => {
        expect(batchManagerActions.saveBatch().type)
            .toEqual(batchActionTypes.SAVE_BATCH);
    });
    it('picks 7 properties from the batch for the payload', () => {
        const sampleBatch = {
            type: '',
            ukId: '',
            id: '1',
            comments: '',
            name: '',
            scenarios: '',
            cobDate: '',
            unwanted1: '',
            unwanted2: '',
            unwanted3: '',
        };
        const payloadProps = Object.keys(batchManagerActions.saveBatch(sampleBatch).payload.batch);

        expect(payloadProps).toHaveLength(7);
        expect(_.includes(payloadProps,
            'type', 'id', 'ukId', 'comments', 'name', 'scenarios', 'cobDate')).toEqual(true);
    });
});