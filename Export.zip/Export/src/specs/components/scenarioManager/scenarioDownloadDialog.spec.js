import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import ScenarioDownloadsDialog from '../../../components/scenarioManager/scenarioDownloadsDialog';


describe('Scenario File Download Dialog', () => {
    const initialProps = {
        actions:{
            cancelHandler: () => undefined,
            fetchScenarioDetails: () => undefined,
            downloadScenarioFile: () => undefined,    
        },
        model:{
            scenario: {
                'type':'Scenario',
                'id':'102957',
                'ukId':'102954',
                'comments':'Tetsing scenario download',
                'validFrom':'2018-03-26 13:17:18.227',
                'validTo':'9999-12-31 00:00:00.639',
                'modifiedBy':'1395651',
                'addedBy':'1545727',
                'name':'Created_by_API_1522056129676',
                'description':'Create scenario by write API',
                'action':'UPDATE',
                'activeFileVersion':2,
                'category':'Global'},
            scenarioVersions: [{
                'action':'UPDATE',
                'activeFileVersion':2,
                'addedBy':'SMR_DEV_RO',
                'category':'Global',
                'comments':'Old one as activedddddd',
                'description':'CNY Rout 13.0',
                'id':'102957',
                'modifiedBy':'1395651',
                'name':'Created_by_API_1522056129676',
                'type':'Scenario',
                'ukId':'102954',
                'validFrom':'2018-03-28 08:42:30.751',
                'validTo':'9999-12-31 00:00:00.065',  
            },
            {
                'action':'UPDATE',
                'activeFileVersion':1,
                'addedBy':'SMR_DEV_RO',
                'category':'Global',
                'comments':'Old one 444',
                'description':'CNY Rout 12.0',
                'id':'102957',
                'modifiedBy':'1395651',
                'name':'Created_by_API_1522056129676',
                'type':'Scenario',
                'ukId':'102954',
                'validFrom':'2018-03-28 08:42:30.751',
                'validTo':'9999-12-31 00:00:00.065',  
            }],    
        },
    };

    let wrapper;
    const setup = () => {
        wrapper = shallow(<ScenarioDownloadsDialog { ...initialProps } />);
    };
    
    it('should render without error', () => {
        setup();
        expect(toJson(wrapper)).toMatchSnapshot();        
    });

    it('fetches scenario details on initialisation', () => {
        const spy = jest.spyOn(initialProps.actions, 'fetchScenarioDetails');
        setup();
        expect(spy).toHaveBeenCalledWith(initialProps.model.scenario.ukId);
    });

    it('fetches the download details', () => {
        const spy = jest.spyOn(initialProps.actions, 'downloadScenarioFile');
        setup();
        const ukId = '45555';
        const version = {
            activeFileVersion:2,
            validFrom:'test',
        };
        wrapper.instance().downloadScenarioFileVersion(ukId, version)();
        expect(spy).toHaveBeenCalledWith({ ukId, validFrom: 'test', version: 2 });
    });

    describe('cancel button', () => {
        it('calls props.cancelHandler on click', () => {
            const spy = jest.spyOn(initialProps.actions, 'cancelHandler');
            setup();
            wrapper.find('.stress__downloads__cancel').at(0).simulate('click');
            expect(spy).toHaveBeenCalled();
        });
    });
});