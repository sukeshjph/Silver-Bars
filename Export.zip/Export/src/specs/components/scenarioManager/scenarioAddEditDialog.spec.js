import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import {
    SCENARIO_COMPILATION_STATES,
    SCENARIO_COMPILATION_TYPES,
} from '../../../components/scenarioManager/scenarioConstants';
import ScenarioAddEditDialog from '../../../components/scenarioManager/scenarioAddEditDialog';

describe('Scenario AddEdit Dialog', () => {
    const initialProps = {
        confirmHandler: () => undefined,
        cancelHandler: () => undefined,
        doneHandler: () => undefined,
        handleFieldChange: () => undefined,
        handleNameChange: () => undefined,
        handleTagChange: () => undefined,
        data: {
            isSavingScenario: false,
            scenarioError: '',
            isCompilingScenario: false,
            compilationResult: { result: '', message: '' },
        },
        actions: {
            compileScenarioFile: () => undefined,
            compileScenarioFileReset: () => undefined,
        },
    };

    let wrapper;

    const setup = props => {
        const p = props || initialProps;
        wrapper = shallow(<ScenarioAddEditDialog {...p} />);
    };

    describe('creating a new scenario', () => {
        beforeEach(() => {
            setup();
        });
        it('should render without error', () => {
            expect(toJson(wrapper)).toMatchSnapshot();
        });
        it('has the correct title in the header', () => {
            expect(
                wrapper
                    .find('#stress--scenario-dialog--title')
                    .dive()
                    .children()
                    .text(),
            ).toBe('Create scenario');
        });
        it('sets state.isEditing to false', () => {
            expect(wrapper.state('isEditing')).toBeFalsy();
        });
    });

    describe('editing a scenario', () => {
        const scenario = {
            name: 'Test Scenario',
            tags: ['Global', 'Localised'],
            description: 'The description',
            category: 'Localised',
            data: '',
        };
        beforeEach(() => {
            setup({
                ...initialProps,
                data: {
                    ...initialProps.data,
                    selectedScenario: scenario,
                },
            });
        });
        it('sets state.isEditing to true', () => {
            expect(wrapper.state('isEditing')).toBeTruthy();
        });
        it('adds the selectedScenario to the state', () => {
            expect(wrapper.state('selectedScenario')).toEqual(scenario);
        });
        it('has the correct title in the header', () => {
            expect(
                wrapper
                    .find('#stress--scenario-dialog--title')
                    .dive()
                    .children()
                    .text(),
            ).toBe('Update scenario');
        });
    });

    describe('confirm handler', () => {
        it('is called by the ReasonForChange component to save the scenario', () => {
            const spy = jest.spyOn(initialProps, 'confirmHandler');
            const comments = 'some comments';
            const scenario = { name: 'whatever' };
            setup();
            wrapper.setState({ selectedScenario: scenario });
            wrapper.instance().confirmHandler(comments);
            expect(spy).toHaveBeenCalledWith({ ...scenario, comments });
        });
    });

    describe('undo handler', () => {
        it('is called by the ReasonForChange component to undo changes', () => {
            const scenario = { name: 'whatever' };
            wrapper.setState({ selectedScenario: scenario });
            wrapper.instance().undoHandler();
            expect(wrapper.state()).toEqual(wrapper.instance().initialState);
        });
    });

    describe('handling changing the scenario file', () => {
        const scenario = { activeFileVersion: 1 };
        const csv = 'csv string data';
        const theFile = { name: 'file.csv', size: 1 };
        const compileScenarioFileReset = jest.fn();
        const newProps = {
            ...initialProps,
            actions: {
                ...initialProps.actions,
                compileScenarioFileReset,
            },
        };

        describe('valid scenario file', () => {
            const scenarioFileValidation = () => {
                it('removes activeFileVersion from the selectedScenario', () => {
                    expect(wrapper.state('selectedScenario').activeFileVersion).toBeUndefined();
                });
                it('sets state.selectedScenario.data to the value passed in the first parameter', () => {
                    expect(wrapper.state('selectedScenario').data).toEqual(csv);
                });
                it('sets state.fileIsValid to true', () => {
                    expect(wrapper.state('fileIsValid')).toBeTruthy();
                });
                it('marks the field as being touched', () => {
                    expect(wrapper.state('touched')).toContain('data');
                });
                it('changes the message that will be displayed after saving successfully', () => {
                    expect(wrapper.state('saveSuccessMessage')).toBe(
                        'Changes saved and queued for approval. Check Approval Inbox.',
                    );
                });
            };

            const initialise = changeType => {
                setup(newProps);
                wrapper.setState({ selectedScenario: scenario });
                wrapper.instance().handleFileChange(csv, true, theFile, changeType);
            };

            describe('when new file is uploaded', () => {
                beforeAll(() => {
                    initialise(SCENARIO_COMPILATION_TYPES.FILEUPLOAD);
                });
                afterAll(() => {
                    compileScenarioFileReset.mockClear();
                });

                describe('state validations', () => {
                    scenarioFileValidation();
                });

                it('compiler button is enabled', () => {
                    expect(wrapper.state('enableCompilation')).toBeTruthy();
                });

                describe('compilation result reset', () => {
                    it('first file upload, no reset called', () => {
                        expect(compileScenarioFileReset).not.toHaveBeenCalled();
                    });
                    it('another file is uploaded and reset called', () => {
                        wrapper
                            .instance()
                            .handleFileChange(
                                csv,
                                true,
                                theFile,
                                SCENARIO_COMPILATION_TYPES.FILEUPLOAD,
                            );
                        expect(compileScenarioFileReset).toHaveBeenCalled();
                    });
                });
            });

            describe('when user selects a new/different category', () => {
                beforeAll(() => {
                    initialise(SCENARIO_COMPILATION_TYPES.CATEGORY);
                });

                afterAll(() => {
                    compileScenarioFileReset.mockClear();
                });

                describe('state validations', () => {
                    scenarioFileValidation();
                });

                it('should not reset compilation status', () => {
                    expect(compileScenarioFileReset).not.toHaveBeenCalled();
                });

                describe('compilation done and category', () => {
                    it('compiled and chose category', () => {
                        wrapper.setState({ enableCompilation: false, isScenarioCompiled: true }); // it has been compiled and button is disabled
                        expect(wrapper.state('enableCompilation')).toBeFalsy();
                    });

                    it('file is not yet compiled', () => {
                        wrapper.setState({ enableCompilation: true, isScenarioCompiled: false });
                        expect(wrapper.state('enableCompilation')).toBeTruthy();
                    });
                });
            });
        });

        describe('invalid scenario file', () => {
            beforeAll(() => {
                setup(newProps);
                wrapper.instance().handleFileChange(csv, false, theFile);
            });

            it('sets state.fileIsValid to false', () => {
                expect(wrapper.state('fileIsValid')).toBeFalsy();
            });

            it('disables compile button', () => {
                expect(wrapper.state('enableCompilation')).toBeFalsy();
            });

            it('resets earlier compilation status', () => {
                expect(compileScenarioFileReset).toHaveBeenCalled();
            });
        });
    });

    describe('handling changing the scenario name', () => {
        const scenario = { name: 'first name' };
        const secondName = 'second name';

        beforeEach(() => {
            setup();
            wrapper.setState({ selectedScenario: scenario });
            wrapper.instance().handleNameChange(secondName, true);
        });
        it('sets state.selectedScenario.name', () => {
            expect(wrapper.state('selectedScenario').name).toEqual(secondName);
        });
        it('sets state.nameIsValid to the second parameter', () => {
            expect(wrapper.state('nameIsValid')).toBeTruthy();
            wrapper.instance().handleNameChange(secondName, false);
            expect(wrapper.state('nameIsValid')).toBeFalsy();
        });
    });

    describe('handling changing a tag', () => {
        const scenario = { tags: [] };
        const newTags = ['second tags'];

        beforeEach(() => {
            setup();
            wrapper.setState({ selectedScenario: scenario });
            wrapper.instance().handleTagChange(newTags);
        });
        it('sets state.selectedScenario.tags', () => {
            expect(wrapper.state('selectedScenario').tags).toEqual(newTags);
        });
    });

    describe('changing the category', () => {
        beforeEach(() => {
            setup();
            wrapper.find('#scenario-category').simulate('change', { target: { value: 'Global' } });
        });
        it('sets state.selectedScenario.category', () => {
            expect(wrapper.state('selectedScenario').category).toEqual('Global');
        });
        it('sets state.categoryIsValid to true', () => {
            expect(wrapper.state('categoryIsValid')).toBeTruthy();
        });
        it('adds category to the array of touched elements', () => {
            expect(wrapper.state('touched')).toContain('category');
        });
        it('sets categoryIsValid to false if a bad value is selected', () => {
            wrapper.find('#scenario-category').simulate('change', { target: { value: null } });
            expect(wrapper.state('categoryIsValid')).toBeFalsy();
        });
    });

    describe('changing the description', () => {
        beforeEach(() => {
            setup();
            wrapper.find('#scenario-description').simulate('change', { target: { value: 'Text' } });
        });
        it('sets state.selectedScenario.description', () => {
            expect(wrapper.state('selectedScenario').description).toEqual('Text');
        });
        it('sets state.descriptionIsValid to true', () => {
            expect(wrapper.state('descriptionIsValid')).toBeTruthy();
        });
        it('adds description to the array of touched elements', () => {
            expect(wrapper.state('touched')).toContain('description');
        });
        it('sets descriptionIsValid to false if no value is entered', () => {
            wrapper.find('#scenario-description').simulate('change', { target: { value: '' } });
            expect(wrapper.state('descriptionIsValid')).toBeFalsy();
        });
    });

    describe('enabling the submit button', () => {
        it('is enabled when everything is valid', () => {
            setup();
            wrapper.setState({
                nameIsValid: true,
                categoryIsValid: true,
                descriptionIsValid: true,
                fileIsValid: true,
            });
            expect(wrapper.instance().checkFormIsValid()).toBeTruthy();
        });
        it('is disabled if something is not valid', () => {
            setup();
            wrapper.setState({
                nameIsValid: false,
                categoryIsValid: true,
                descriptionIsValid: true,
                fileIsValid: true,
            });
            expect(wrapper.instance().checkFormIsValid()).toBeFalsy();
        });
    });

    describe('field error state', () => {
        it('adds an error state if a field is not valid', () => {
            setup();
            wrapper.setState({
                descriptionIsValid: false,
                touched: ['description'],
            });
            expect(
                wrapper
                    .find('.stress__add-edit__description')
                    .at(0)
                    .hasClass('stress__form__field--error'),
            ).toBeTruthy();
        });
        it('removes the error state if the field is valid', () => {
            setup();
            wrapper.setState({
                descriptionIsValid: true,
                touched: ['description'],
            });
            expect(
                wrapper
                    .find('.stress__add-edit__description')
                    .at(0)
                    .hasClass('stress__form__field'),
            ).toBeTruthy();
            expect(
                wrapper
                    .find('.stress__add-edit__description')
                    .at(0)
                    .hasClass('stress__form__field--error'),
            ).toBeFalsy();
        });
        it.skip('removes the error state if the field has not been touched yet', () => {
            setup();
            wrapper.setState({
                descriptionIsValid: false,
            });
            expect(
                wrapper
                    .find('.stress__add-edit__description')
                    .at(0)
                    .hasClass('stress__form__field'),
            ).toBeTruthy();
            expect(
                wrapper
                    .find('.scenario__add-edit__description')
                    .at(0)
                    .hasClass('stress__form__field--error'),
            ).toBeFalsy();
        });
    });

    describe('scenario compilation', () => {
        it('handle compile scenario', () => {
            const compileScenarioFile = jest.fn();
            setup({
                ...initialProps,
                actions: { ...initialProps.actions, compileScenarioFile },
            });
            wrapper.instance().handleCompileScenario();
            expect(compileScenarioFile).toHaveBeenCalled();
        });

        describe('get Compilation error message from result', () => {
            setup({ ...initialProps });
            const compilationResult = { result: '', message: '' };

            it('Compilation passed', () => {
                compilationResult.result = SCENARIO_COMPILATION_STATES.COMPILED;
                expect(wrapper.instance().getCompilationError(compilationResult)).toBeFalsy();
            });

            it('Compilation failed', () => {
                compilationResult.result = SCENARIO_COMPILATION_STATES.FAILED;
                compilationResult.message = 'error occurred';
                expect(wrapper.instance().getCompilationError(compilationResult)).toBe(
                    'error occurred',
                );
            });
        });
    });

    afterEach(() => {
        jest.restoreAllMocks();
    });
});
