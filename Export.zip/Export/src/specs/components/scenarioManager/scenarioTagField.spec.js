import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import ScenarioTagField from '../../../components/scenarioManager/scenarioTagField';
import { SCENARIO_TAGS } from '../../../components/scenarioManager/scenarioConstants';

jest.mock('../../../helpers/getAffectedBatches', () => () => 'Monday, Tuesday');
jest.mock('shortid', () => ({
    generate: jest.fn(() => 1),
}));

describe('Scenario Tag Form Field', () => {
    const initialProps = {
        handleTagChange: () => undefined,
        disabled: false,
        tags: ['Global', 'ESA'],
    };

    let wrapper;
    const setup = () => {
        wrapper = shallow(<ScenarioTagField { ...initialProps } />);
    };
    
    it('should render without error', () => {
        setup();
        expect(toJson(wrapper)).toMatchSnapshot();        
    });

    it('displays one checkbox for each tag in SCENARIO_CONSTANTS', () => {
        setup();
        const numberOfConstants = SCENARIO_TAGS.length;
        expect(wrapper.find('.stress__scenario__tag')).toHaveLength(numberOfConstants);
    });

    describe('changing a checkbox', () => {
        let spy;
        let event;
        let checkbox;
        beforeEach(() => {
            spy = jest.spyOn(initialProps, 'handleTagChange');
            setup();
            checkbox = wrapper.find('.stress__scenario__tag').at(0);
            event = {
                target: {
                    value: '',
                },
            };
        });
        it('adds the tags provided in props to state', () => {
            expect(wrapper.state('tags')).toEqual(initialProps.tags);
        });
        it('adds the value to state if not already checked', () => {
            event = {
                target: {
                    checked: true,
                    value: SCENARIO_TAGS[1],
                },
            };
            checkbox.simulate('change', event);
            expect(wrapper.state('tags')).toContain(event.target.value);
        });
        it('removes the value from state if already checked', () => {
            event.target.checked = false;
            event = {
                target: {
                    checked: false,
                    value: SCENARIO_TAGS[0],
                },
            };
            checkbox.simulate('change', event);
            expect(wrapper.state('tags')).not.toContain(event.target.value);
        });
        it('calls props.handleTagChange', () => {
            checkbox.simulate('change', event);
            expect(spy).toHaveBeenCalled();
        });
    });
});