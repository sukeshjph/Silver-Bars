import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import ScenarioNameField from '../../../components/scenarioManager/scenarioNameField';

describe('Scenario Name Field', () => {
    const initialProps = {
        handleNameChange: () => undefined,
        disabled: false,
        scenarioName: '',
    };

    let wrapper;
    const setup = () => {
        wrapper = shallow(<ScenarioNameField { ...initialProps } />);
    };
    
    it('should render without error', () => {
        setup();
        expect(toJson(wrapper)).toMatchSnapshot();        
    });

    describe('name validation', () => {
        it('returns false if no name is present', () => {
            const name = '';
            expect(ScenarioNameField.isScenarioNameValid(name)).toBe(false);
        });
        it('must be alphanumeric', () => {
            const name = 'aazzAAZZ123';
            expect(ScenarioNameField.isScenarioNameValid(name)).toBe(true);
        });
        it('can contain hyphens', () => {
            const name = 'aazzAAZZ123---';
            expect(ScenarioNameField.isScenarioNameValid(name)).toBe(true);
        });
        it('can contain underscores', () => {
            const name = 'aazzAAZZ123---___';
            expect(ScenarioNameField.isScenarioNameValid(name)).toBe(true);
        });
        it('cannot contain any other characters', () => {
            let name = 'aazzAAZZ123---___!!!';
            expect(ScenarioNameField.isScenarioNameValid(name)).toBe(false);
            name = 'aazzAAZZ123---___!!!';
            expect(ScenarioNameField.isScenarioNameValid(name)).toBe(false);
            name = 'aazzAAZZ123---___!!!';
            expect(ScenarioNameField.isScenarioNameValid(name)).toBe(false);
        });
    });

    describe('help text', () => {
        it('explains when an entered name is not valid', () => {
            const name = 'name';
            const isValid = false;
            expect(ScenarioNameField.scenarioNameFieldHelpText(name, isValid)).toBe('Name can only contain letters, numbers, - or _ ');
        });
        it('says required if field is empty', () => {
            const name = '';
            const isValid = true;
            expect(ScenarioNameField.scenarioNameFieldHelpText(name, isValid)).toBe('Required');
        });
        it('says required if field is valid', () => {
            const name = 'sdfsdfsdfsdf';
            const isValid = true;
            expect(ScenarioNameField.scenarioNameFieldHelpText(name, isValid)).toBe('Required');
        });
    });

    describe('changing the name', () => {
        let spy;
        let event;
        let input;
        beforeEach(() => {
            spy = jest.spyOn(initialProps, 'handleNameChange');
            setup();
            input = wrapper.find('.stress__form__input').at(0);
            event = {
                target: {
                    value: '',
                },
            };
        });
        it('marks the input as having been touched', () => {
            input.simulate('change', event);
            expect(wrapper.state('touched')).toEqual(true);
        });
        it('adds the entered value to state.name', () => {
            event.target.value = 'something';
            input.simulate('change', event);
            expect(wrapper.state('name')).toEqual('something');
        });
        it('validates the name', () => {
            spy = jest.spyOn(ScenarioNameField, 'isScenarioNameValid');
            setup();
            event.target.value = 'anything';
            input.simulate('change', event);
            expect(spy).toHaveBeenCalledWith('anything');
        });
        it('calls props.handleTagChange', () => {
            input.simulate('change', event);
            expect(spy).toHaveBeenCalled();
        });

        it('displays field error state', () => {
            wrapper.setState({
                touched: true,
                nameIsValid: false,
            });
            expect(wrapper.find('.stress__add-edit__name').at(0).hasClass('stress__form__field--error')).toBe(true);
        });
    });
});