import scenarioColumnHeadingsValidator from '../../../components/scenarioManager/scenarioColumnHeadingsValidator';
import { localisedHeadings, commonHeadings } from '../../../components/scenarioManager/scenarioConstants';


describe('invalid parameters', () => {
    it('returns isValid: true', () => {
        const results = scenarioColumnHeadingsValidator();
        expect(results.isValid).toBe(true);
    });
});

describe('validating Cortex_Path shock file', () => {

    const fileType = 'Global';
    const fileName = 'Cortex_Path';

    it('is always valid', () => {
        const mockCsv = `${localisedHeadings.join(',')}\r\n`;
        const results = scenarioColumnHeadingsValidator(mockCsv, fileType, fileName);
        expect(results.isValid).toBe(true);
        expect(results.localisedHeadingsError).not.toBeDefined();
        expect(results.commonHeadingsError).not.toBeDefined();
    });
});

describe('validating localised shock file', () => {

    const fileType = 'Localised';

    it('MUST have all of the localised headings', () => {
        const mockCsv = `${localisedHeadings.join(',')}\r\n`;
        const results = scenarioColumnHeadingsValidator(mockCsv, fileType);
        expect(results.isValid).toBe(true);
        expect(results.localisedHeadingsError).toBe(false);
        expect(results.commonHeadingsError).toBe(false);
    });

    it('is invalid if missing a localised heading', () => {
        const mockCsv = `${localisedHeadings.slice(1).join(',')}\r\n`;
        const results = scenarioColumnHeadingsValidator(mockCsv, fileType);
        expect(results.isValid).toBe(false);
        expect(results.localisedHeadingsError).toBe(true);
        expect(results.commonHeadingsError).toBe(false);
    });

    it('OPTIONALLY contains any of the common headings', () => {
        const mockCsv = `${[...localisedHeadings, ...commonHeadings].join(',')}\r\n`;
        const results = scenarioColumnHeadingsValidator(mockCsv, fileType);
        expect(results.isValid).toBe(true);
        expect(results.localisedHeadingsError).toBe(false);
        expect(results.commonHeadingsError).toBe(false);
    });

    it('MUST NOT contain anything else', () => {
        const mockCsv = `${[...localisedHeadings, ...commonHeadings, 'unknown heading'].join(',')}\r\n`;
        const results = scenarioColumnHeadingsValidator(mockCsv, fileType);
        expect(results.isValid).toBe(false);
        expect(results.localisedHeadingsError).toBe(false);
        expect(results.commonHeadingsError).toBe(true);
    });

    it('Returns unrecognised headings', () => {
        const mockCsv = `${[...localisedHeadings, ...commonHeadings, 'bad heading 1', 'bad heading 2'].join(',')}\r\n`;
        const results = scenarioColumnHeadingsValidator(mockCsv, fileType);
        expect(results.unrecognisedHeadings).toBe('bad heading 1, bad heading 2');
    });
});

describe('validating global shock file', () => {

    const fileType = 'Global';

    it('OPTIONALLY contains any of the common headings', () => {
        const mockCsv = `${commonHeadings.slice(3).join(',')}\r\n`;
        const results = scenarioColumnHeadingsValidator(mockCsv, fileType);
        expect(results.isValid).toBe(true);
        expect(results.localisedHeadingsError).toBe(false);
        expect(results.commonHeadingsError).toBe(false);
    });

    it('MUST NOT contain anything else', () => {
        const mockCsv = `${[...commonHeadings, 'unknown heading'].join(',')}\r\n`;
        const results = scenarioColumnHeadingsValidator(mockCsv, fileType);
        expect(results.isValid).toBe(false);
        expect(results.localisedHeadingsError).toBe(false);
        expect(results.commonHeadingsError).toBe(true);
    });

    it('Returns unrecognised headings', () => {
        const mockCsv = `${[...commonHeadings, 'bad heading 1', 'bad heading 2'].join(',')}\r\n`;
        const results = scenarioColumnHeadingsValidator(mockCsv, fileType);
        expect(results.unrecognisedHeadings).toBe('bad heading 1, bad heading 2');
    });
});
