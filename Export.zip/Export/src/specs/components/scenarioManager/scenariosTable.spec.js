import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import _ from 'lodash';
import mockScenarioResponse from '../../mocks/mockScenarioResponse';
import ScenariosTable from '../../../components/scenarioManager/scenariosTable';

describe('Scenario Table component', () => {

    let initialProps;
    let wrapper;

    beforeEach(() => {
        initialProps = {
            scenarios: mockScenarioResponse,
            setSelectedScenario: jest.fn(),
            selectedScenarioUkId: '',
        };
        wrapper = shallow(<ScenariosTable { ...initialProps }/>);
    });
    
    it('should render without error', () => {
        expect(toJson(wrapper)).toMatchSnapshot();
    });

    it('componentWillReceiveProps()', () => {
        const newScenarios = [
            ...initialProps.scenarios,
            {
                'type': 'Scenario',
                'ukId': '15',
                'validFrom': '2018-02-23 09:10:09.758',
                'validTo': '9999-12-31 00:00:00.520',
                'activeFileVersion': 6,
            },
        ];
        wrapper.setProps({
            ...initialProps,
            scenarios: newScenarios,
        });
        expect(wrapper.state('scenarios')).toEqual(newScenarios);
    });

    describe('sortHandler()', () => {
        it('toggles ascending / descending order', () => {
            wrapper.setState({
                order: 'asc',
                orderBy: 'anything',
            });
            wrapper.instance().sortHandler({}, 'anything');
            expect(wrapper.state('order')).toBe('desc');
            wrapper.instance().sortHandler({}, 'anything');
            expect(wrapper.state('order')).toBe('asc');
        });
        it('sets state.orderBy', () => {
            wrapper.instance().sortHandler({}, 'new column heading');
            expect(wrapper.state('orderBy')).toBe('new column heading');
        });
    });

    describe.skip('sorting scenarios', () => {
        let sortedScenarios;
        beforeEach(() => {
            sortedScenarios = _.sortBy(initialProps.scenarios, wrapper.state('orderBy'));
        });
        it('sorts scenarios in ascending order', () => {
            wrapper.setState({ order:'asc' });
            expect(wrapper.instance().sortScenarios(initialProps.scenarios)).toEqual(sortedScenarios);
        });
        it('sorts scenarios in descending order', () => {
            wrapper.setState({ order:'desc' });
            expect(wrapper.instance().sortScenarios(initialProps.scenarios)).toEqual(_.reverse(sortedScenarios));
        });
    });

    describe('selecting a scenario', () => {
        let spy;
        let row;
        const scenarios = _.reverse(_.sortBy(mockScenarioResponse, 'validFrom'));
        beforeEach(() => {
            const props = {
                ...initialProps,
                setSelectedScenario: jest.fn(),
                selectedScenarioUkId: scenarios[0].ukId,
            };
            wrapper.setProps(props);
            spy = jest.spyOn(props, 'setSelectedScenario');
            row = wrapper.find('.stress-table .stress-table--row').at(0);
            row.simulate('click');
        });
        it('adds className to clicked table row', () => {
            expect(row.hasClass('stress-table--row_selected')).toBeTruthy();
        });
        it('triggers the action', () => {
            expect(spy).toHaveBeenCalledWith(scenarios[0].ukId);
        });
    });

    afterEach(() => {
        jest.restoreAllMocks();
    });
});
