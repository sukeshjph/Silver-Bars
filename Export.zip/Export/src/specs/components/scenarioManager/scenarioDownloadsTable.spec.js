import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import ScenarioDownloadsTable from '../../../components/scenarioManager/scenarioDownloadsTable';
import mockScenarioVersions from '../../mocks/mockScenarioWithVersions';

describe('Scenario downloads table', () => {
    const initialProps = {
        approvedScenarios: mockScenarioVersions.scenarioVersions,
        pendingScenarios: [{ ...mockScenarioVersions.scenarioVersions[0], pending: true }],
        downloadScenarioFileVersion: () => undefined,
        scenario: mockScenarioVersions.Scenario,
    };

    const wrapper = shallow(<ScenarioDownloadsTable { ...initialProps } />);
    
    it('should render without error', () => {
        expect(toJson(wrapper)).toMatchSnapshot();
        expect(wrapper.find('.stress-version-table__header--first')).toHaveLength(1);
        expect(wrapper.find('.stress-version-table__header--first').text()).toBe('File Versions');
        expect(wrapper.find('tbody .stress-table--row')).toHaveLength(3);
    });

    it('selects the active file version',() =>{
        const selectedVersion = wrapper.find('.stress-table--row_selected');
        expect(selectedVersion).toHaveLength(1);
        expect(selectedVersion.find('.stress__downloads__button').at(0).text()).toContain('version 2');
    });

    it('Testing Download button',() =>{
        const downloadScenarioFileVersion = jest.fn();
        const localProps = {
            ...initialProps,
            downloadScenarioFileVersion,
        };
        const newWrapper = shallow(<ScenarioDownloadsTable {...localProps}/>);
        newWrapper.find('.stress__downloads__button').at(0).simulate('click');
        expect(downloadScenarioFileVersion).toHaveBeenCalled();
        expect(downloadScenarioFileVersion).toHaveBeenCalledWith('102954',mockScenarioVersions.scenarioVersions[0]);
    });

    afterEach(() => {
        // jest.restoreAllMocks();
    });

});