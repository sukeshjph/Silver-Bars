import React from 'react';
import { shallow, mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import FilePicker from '../../../components/scenarioManager/filePicker';
import { SCENARIO_COMPILATION_TYPES } from '../../../components/scenarioManager/scenarioConstants';
import { MAX_FILE_SIZE } from '../../../constants';

jest.mock('papaparse', () => ({
    parse: jest.fn(),
    unparse: jest.fn(),
}));

jest.mock('../../../components/scenarioManager/scenarioColumnHeadingsValidator');

describe('FilePicker component', () => {
    const initialProps = {
        handleFileChange: jest.fn(),
        isRequired: false,
        fileType: 'Global',
        compilationError: '',
        children: null,
        
    };
    let mockEvent;
    let wrapper;
   
    const setup = () => {
        wrapper = shallow(<FilePicker {...initialProps} />);
        mockEvent = {
            target: {
                files: [],
            },
        };
    };

    describe('rendering', () => {
        setup();
        it('should render a form input', () => {
            expect(toJson(wrapper)).toMatchSnapshot();
        });
    });

    describe('clicking the upload icon', () => {
        setup();
        it('triggers a click on the hidden fileInput ref', () => {
            const mountedWrapper = mount(<FilePicker {...initialProps} />);
            const spy = jest.spyOn(mountedWrapper.instance().fileInput, 'click');
            mountedWrapper
                .find('.stress__button')
                .first()
                .simulate('click');
            expect(spy).toHaveBeenCalled();
        });
    });

    describe('selecting a file', () => {
        setup();
        describe('error handling', () => {
            describe('file extension is not .csv', () => {
                it('adds the file to state', () => {
                    mockEvent.target.files = [{ name: 'file.doc', size: 1 }];
                    wrapper.instance().handleFileChange(mockEvent);
                    expect(wrapper.state('theFile')).toEqual(mockEvent.target.files[0]);
                });
                it('renders an error', () => {
                    mockEvent.target.files = [{ name: 'file.doc', size: 1 }];
                    wrapper.instance().handleFileChange(mockEvent);
                    expect(wrapper.state('fileTypeError')).toBe(true);
                });
                it('triggers handleFileChange', () => {
                    const spy = jest.spyOn(initialProps, 'handleFileChange');
                    mockEvent.target.files = [{ name: 'file.doc', size: 1 }];
                    wrapper.instance().handleFileChange(mockEvent);
                    expect(spy).toHaveBeenCalledWith(null, false);
                });
            });

            describe('file size exceeds MAX_FILE_SIZE', () => {
                it('adds the file to state', () => {
                    mockEvent.target.files = [{ name: 'file.csv', size: MAX_FILE_SIZE + 1 }];
                    wrapper.instance().handleFileChange(mockEvent);
                    expect(wrapper.state('theFile')).toEqual(mockEvent.target.files[0]);
                });
                it('renders an error', () => {
                    mockEvent.target.files = [{ name: 'file.csv', size: MAX_FILE_SIZE + 1 }];
                    wrapper.instance().handleFileChange(mockEvent);
                    expect(wrapper.state('fileSizeError')).toBe(true);
                });
                it('triggers handleFileChange', () => {
                    const spy = jest.spyOn(initialProps, 'handleFileChange');
                    mockEvent.target.files = [{ name: 'file.csv', size: MAX_FILE_SIZE + 1 }];
                    wrapper.instance().handleFileChange(mockEvent);
                    expect(spy).toHaveBeenCalledWith(null, false);
                });
            });
        });

        describe('valid file selection', () => {
            const theFile = { name: 'file.csv', size: 1 };

            beforeEach(() => {
                mockEvent.target.files = [theFile];
            });

            it('triggers parseTheFile method', () => {
                const spy = jest.spyOn(wrapper.instance(), 'parseTheFile');
                wrapper.instance().handleFileChange(mockEvent);
                expect(spy).toHaveBeenCalledWith(theFile, SCENARIO_COMPILATION_TYPES.FILEUPLOAD);
            });

            it('validates the headings', () => {
                wrapper.instance().validateHeadings([], theFile);
                expect(wrapper.state('columnHeadingsAreValid')).toBe(true);
                expect(wrapper.state('localisedHeadingsError')).toBe(false);
                expect(wrapper.state('commonHeadingsError')).toBe(false);
            });

            it('hides all the errors', () => {
                wrapper.setState({
                    fileSizeError: true,
                    fileTypeError: true,
                });
                wrapper.instance().validateHeadings([], theFile);
                expect(wrapper.state('fileSizeError')).toBe(false);
                expect(wrapper.state('fileTypeError')).toBe(false);
            });

            it('adds the file to state', () => {
                wrapper.instance().validateHeadings([], theFile);
                expect(wrapper.state('theFile')).toEqual(theFile);
            });

            describe('headings are valid', () => {
                it('triggers handleFileChange', () => {
                    const changeType = SCENARIO_COMPILATION_TYPES.FILEUPLOAD;
                    const spy = jest.spyOn(initialProps, 'handleFileChange');
                    wrapper.instance().validateHeadings([], theFile, changeType);
                    expect(spy).toHaveBeenCalledWith([], true, theFile, changeType);
                });
            });
        });
    });
});
