import moment from 'moment';
import * as actions from '../../../components/batchAudit/batchAuditActions';
import { batchAuditActionTypes } from '../../../components/batchAudit/batchAuditConstants';

jest.mock('../../../helpers/authentication');

describe('"fetchBatchAudits"', () => {
    it('dispatches a FETCH_BATCH_AUDITS action', () => {
        expect(actions.fetchBatchAudits().type)
            .toEqual(batchAuditActionTypes.FETCH_BATCH_AUDITS);
    });
    it('sends validFrom and validTo params', () => {
        expect(actions.fetchBatchAudits(moment('01/01/2018', 'DD/MM/YYYY'), moment('01/01/2019', 'DD/MM/YYYY')).payload)
            .toEqual({ validFromDate: '2018-01-01 00:00:00.000', validToDate: '2019-01-01 23:59:59.999' });
    });
    it('sets validFromDate to null if no param is passed', () => {
        Date.now = jest.fn(() => 1528105933097); // 4th June 2018
        expect(actions.fetchBatchAudits().payload.validFromDate)
            .toBe(null);
    });
    it('sets validToDate to null if no param is passed', () => {
        Date.now = jest.fn(() => 1528105933097); // 4th June 2018
        expect(actions.fetchBatchAudits().payload.validToDate)
            .toBe(null);
    });
});