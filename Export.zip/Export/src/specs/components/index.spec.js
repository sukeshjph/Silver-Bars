// import React from 'react';
// import { shallow, mount } from 'enzyme';
// import toJson from 'enzyme-to-json';
// import { StressTesting } from '../../components';
// import { hasAccess } from '../../helpers/authentication';

// jest.mock('react-router-dom', () => ({
//     Route: () => null,
//     withRouter: jest.fn(),
// }));
// jest.mock('../../helpers/authentication', () => ({
//     hasAccess: jest.fn(),
// }));
// jest.mock('../../components/shared/loginForm', () => () => <div id='login-form'>Login</div>);

describe.skip('StressTesting', () => {
    const initialProps = {
        actions: {
            reloadSession: () => undefined,
            signIn: () => undefined,
        },
        user: {
            failedAuthentication: true,
            isSigningIn: true,
        },
    };
    let wrapper;

    describe('rendering', () => {
        it('should render with initial props and state', () => {
            wrapper = shallow(<StressTesting { ...initialProps } />);
            expect(toJson(wrapper)).toMatchSnapshot();
        });
        it('should attempt to reload an existing session on mount', () => {
            jest.spyOn(initialProps.actions, 'reloadSession');
            mount(<StressTesting { ...initialProps } />);
            expect(initialProps.actions.reloadSession).toHaveBeenCalled();
        });
    });

    describe('user is authenticated', () => {
        it('renders the routes', () => {
            hasAccess.mockImplementation(() => true);
            wrapper = mount(<StressTesting { ...initialProps } />);
            expect(wrapper.find('#stress-ui-components')).toHaveLength(1);
        });
    });

    describe('user is not authenticated', () => {
        it('renders the LoginForm', () => {
            hasAccess.mockImplementation(() => false);
            wrapper = mount(<StressTesting { ...initialProps } />);
            expect(wrapper.find('#login-form')).toHaveLength(1);
        });
    });
});

it('nothing..', () => {
    
});