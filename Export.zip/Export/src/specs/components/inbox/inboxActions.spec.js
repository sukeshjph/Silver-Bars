import * as actions from '../../../components/inbox/inboxActions';
import { inboxActionTypes } from '../../../components/inbox/inboxConstants';

jest.mock('../../../helpers/authentication');

describe('"fetchInbox"', () => {
    it('dispatches a FETCH_FILE_LIST action', () => {
        expect(actions.fetchInbox().type)
            .toEqual(inboxActionTypes.FETCH_INBOX);
    });
});

describe('inbox Scenario actions', () => {
    let action;
    let payload;
    const scenario = { id: '1', ukId: 10 };
    const comments = 'test comments';
    const committee = 'test committee';

    describe('"approveScenario"', () => {
        beforeEach(() => {
            action = actions.approveScenario(scenario, comments, committee);
            payload = action.payload.get('approvalDetails');
        });
        it('dispatches an APPROVE_SCENARIO action', () => {
            expect(action.type).toEqual(inboxActionTypes.APPROVE_SCENARIO);
        });
        it('adds approvalDetails FormData to payload', () => {
            expect(payload).toBeDefined();
        });
        it('sets approvalDetails FormData value as blob', () => {
            expect(payload.name).toEqual('blob');
        });
        it('sets FormData type to application/json', () => {
            expect(payload.type).toEqual('application/json');
        });
        it('adds ukId to FormData payload', () => {
            expect(action.json.ukId).toEqual(scenario.ukId);
        });
        it('adds id to FormData payload', () => {
            expect(action.json.id).toEqual(scenario.id);
        });
        it('adds type of ApprovalDetails to FormData payload', () => {
            expect(action.json.type).toEqual('ApprovalDetails');
        });
        it('adds comments to FormData payload', () => {
            expect(action.json.comments).toEqual(comments);
        });
        it('adds mtcrApprovalCommittee to FormData payload', () => {
            expect(action.json.mtcrApprovalCommittee).toEqual(committee);
        });
    });

    describe('"declineScenario"', () => {
        beforeEach(() => {
            action = actions.declineScenario(scenario, comments, committee);
            payload = action.payload.get('approvalDetails');
        });
        it('dispatches an DECLINE_SCENARIO action', () => {
            expect(action.type).toEqual(inboxActionTypes.DECLINE_SCENARIO);
        });
        it('adds approvalDetails FormData to payload', () => {
            expect(payload).toBeDefined();
        });
        it('sets approvalDetails FormData value as blob', () => {
            expect(payload.name).toEqual('blob');
        });
        it('sets FormData type to application/json', () => {
            expect(payload.type).toEqual('application/json');
        });
        it('adds ukId to FormData payload', () => {
            expect(action.json.ukId).toEqual(scenario.ukId);
        });
        it('adds id to FormData payload', () => {
            expect(action.json.id).toEqual(scenario.id);
        });
        it('adds type of ApprovalDetails to FormData payload', () => {
            expect(action.json.type).toEqual('ApprovalDetails');
        });
        it('adds comments to FormData payload', () => {
            expect(action.json.comments).toEqual(comments);
        });
        it('adds mtcrApprovalCommittee to FormData payload', () => {
            expect(action.json.mtcrApprovalCommittee).toEqual(committee);
        });
    });
});