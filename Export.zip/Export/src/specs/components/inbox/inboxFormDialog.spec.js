import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import DialogTitle from '@material-ui/core/DialogTitle';
import InboxFormDialog from '../../../components/inbox/inboxFormDialog';
import ErrorMessage from '../../../components/shared/errorMessage';

jest.mock('../../../common/config');
jest.mock('../../../helpers/authentication');

const setup = props => shallow(<InboxFormDialog {...props} />);

describe('InboxFormDialog component', () => {
    const initialProps = {
        userAction: 'approve',
        fileAction: 'CREATE',
        open: true,
        isSaving: false,
        saveError: '',
        saveHandler: () => jest.fn(),
        cancelHandler: () => jest.fn(),
        affectedBatches: 'Batches affected',
    };

    let wrapper;

    beforeEach(() => {
        wrapper = setup(initialProps);
    });

    describe('rendering', () => {
        it('should render with initial props and state', () => {
            expect(toJson(wrapper)).toMatchSnapshot();
        });
    });

    describe('receiving props', () => {
        it('determines whether save has completed', () => {
            wrapper.setProps({
                isSaving: true,
            });
            expect(wrapper.state('saveActionCompleted')).toBe(false);
            wrapper.setProps({
                isSaving: false,
            });
            expect(wrapper.state('saveActionCompleted')).toBe(true);
        });

        it('displays a save error', () => {
            const testError = 'Ah say somethin went wrong yo';
            wrapper.setProps({
                saveError: testError,
            });
            expect(wrapper.state('saveError')).toEqual(testError);
        });
    });

    describe('approving the scenario', () => {
        const nineteenChars = '1234567890123456789';
        const twentyChars = '12345678901234567890';

        it('displays correct dialog title', () => {
            expect(
                wrapper
                    .find(DialogTitle)
                    .dive()
                    .children()
                    .at(0)
                    .text(),
            ).toContain('Approve');
        });
        it('displays correct dialog helper text', () => {
            expect(
                wrapper
                    .find('.stress__inbox-dialog__intro')
                    .at(0)
                    .text(),
            ).toContain('Please give a reason for approving this scenario file. Batches affected');
        });
        it('displays correct comments input label', () => {
            expect(
                wrapper
                    .find('.stress__inbox-dialog__comments label')
                    .at(0)
                    .text(),
            ).toContain('Reason for approving');
        });
        it('displays approve button', () => {
            expect(
                wrapper
                    .find('#stress__inbox-dialog__confirm')
                    .at(0)
                    .text(),
            ).toContain('Approve');
        });
        it('validates form if comments are changed', () => {
            wrapper
                .find('#stress__inbox-dialog__comments')
                .simulate('change', { target: { value: nineteenChars } });
            expect(wrapper.state('valid')).toBe(false);
            wrapper
                .find('#stress__inbox-dialog__comments')
                .simulate('change', { target: { value: twentyChars } });
            expect(wrapper.state('valid')).toBe(true);
        });
        it('disables approve button if form is not valid', () => {
            wrapper.setState({ valid: false });
            expect(
                wrapper
                    .find('#stress__inbox-dialog__confirm')
                    .at(0)
                    .props().disabled,
            ).toBe(true);
            wrapper.setState({ valid: true });
            expect(
                wrapper
                    .find('#stress__inbox-dialog__confirm')
                    .at(0)
                    .props().disabled,
            ).toBe(false);
        });

        describe('submitting the form', () => {
            it('passes the form data to the saveHandler', () => {
                spyOn(initialProps, 'saveHandler');
                wrapper = setup(initialProps);
                wrapper.setState({
                    valid: true,
                    reasonForChange: twentyChars,
                    approvalCommittee: 'me',
                });
                wrapper
                    .find('#stress__inbox-dialog__confirm')
                    .at(0)
                    .simulate('click');
                expect(initialProps.saveHandler).toHaveBeenCalledWith(twentyChars, 'me');
            });
            it('disables the fields if request is sent', () => {
                wrapper.setProps({
                    isSaving: true,
                });
                expect(
                    wrapper
                        .find('#stress__inbox-dialog__comments')
                        .at(0)
                        .props().disabled,
                ).toBe(true);
                expect(
                    wrapper
                        .find('#stress__inbox-dialog__committee')
                        .at(0)
                        .props().disabled,
                ).toBe(true);
            });
            describe('success', () => {
                beforeEach(() => {
                    wrapper.setState({
                        saveActionCompleted: true,
                    });
                });
                it('disables the form fields', () => {
                    expect(
                        wrapper
                            .find('#stress__inbox-dialog__comments')
                            .at(0)
                            .props().disabled,
                    ).toBe(true);
                    expect(
                        wrapper
                            .find('#stress__inbox-dialog__committee')
                            .at(0)
                            .props().disabled,
                    ).toBe(true);
                });
                it('displays a success message', () => {
                    expect(
                        wrapper
                            .find('.stress__inbox-dialog__outcome')
                            .at(0)
                            .text(),
                    ).toContain('File created and set as ACTIVE version.');
                });
                it('displays an ok button', () => {
                    expect(
                        wrapper
                            .find('#stress__inbox-dialog__action .stress__button-secondary')
                            .at(0)
                            .text(),
                    ).toContain('OK');
                });
                it('displays a close button', () => {
                    expect(wrapper.find('#stress__inbox-dialog__close').exists()).toBe(true);
                });
                it('hides the action buttons', () => {
                    expect(wrapper.find('#stress__inbox-dialog__cancel').exists()).toBe(false);
                    expect(wrapper.find('#stress__inbox-dialog__confirm').exists()).toBe(false);
                });
            });
            describe('failure', () => {
                beforeEach(() => {
                    wrapper.setState({
                        saveActionCompleted: true,
                    });
                    wrapper.setProps({
                        saveError: 'an error',
                    });
                });
                it('displays an error message', () => {
                    expect(wrapper.find(ErrorMessage).props().message).toContain('an error');
                });
                it('displays a close button', () => {
                    expect(wrapper.find('#stress__inbox-dialog__close').exists()).toBe(true);
                });
                it('hides the action buttons', () => {
                    expect(wrapper.find('#stress__inbox-dialog__cancel').exists()).toBe(false);
                    expect(wrapper.find('#stress__inbox-dialog__confirm').exists()).toBe(false);
                });
            });
        });
    });

    describe('declining the scenario', () => {
        const twentyChars = '12345678901234567890';

        beforeEach(() => {
            wrapper.setProps({ userAction: 'decline' });
        });

        it('displays correct dialog title', () => {
            expect(
                wrapper
                    .find(DialogTitle)
                    .dive()
                    .children()
                    .at(0)
                    .text(),
            ).toContain('Decline');
        });
        it('displays correct dialog helper text', () => {
            expect(
                wrapper
                    .find('.stress__inbox-dialog__intro')
                    .at(0)
                    .text(),
            ).toContain('Please give a reason for declining this scenario file.');
        });
        it('displays correct comments input label', () => {
            expect(
                wrapper
                    .find('.stress__inbox-dialog__comments label')
                    .at(0)
                    .text(),
            ).toContain('Reason for declining');
        });
        it('displays decline button', () => {
            expect(
                wrapper
                    .find('#stress__inbox-dialog__confirm')
                    .at(0)
                    .text(),
            ).toContain('Decline');
        });

        describe('submitting the form', () => {
            it('passes the form data to the declineHandler', () => {
                spyOn(initialProps, 'saveHandler');
                wrapper = setup({ ...initialProps, approve: false });
                wrapper.setState({
                    valid: true,
                    reasonForChange: twentyChars,
                    approvalCommittee: 'me',
                });
                wrapper
                    .find('#stress__inbox-dialog__confirm')
                    .at(0)
                    .simulate('click');
                expect(initialProps.saveHandler).toHaveBeenCalledWith(twentyChars, 'me');
            });
            describe('success', () => {
                beforeEach(() => {
                    wrapper.setState({
                        saveActionCompleted: true,
                    });
                });
                it('displays a success message', () => {
                    expect(
                        wrapper
                            .find('.stress__inbox-dialog__outcome')
                            .at(0)
                            .text(),
                    ).toContain('New file rejected and file status has been marked as DECLINED.');
                });
            });
            // Everything else uses same functionality as "approving the scenario" test suite
        });
    });
});
