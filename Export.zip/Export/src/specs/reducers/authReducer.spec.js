import { authActionTypes } from '../../constants';
import reducer from '../../reducers/authReducer';

const initialState = {
    isSigningIn: false,
    failedAuthentication: false,
    userDisplayName: '',
    entitlements: '',
};

describe('Auth reducer', () => {
    it('returns the initial state', () => {
        expect(reducer(undefined, {})).toEqual(initialState);
    });

    describe('AUTHENTICATE reducer', () => {
        const action = {
            type: authActionTypes.AUTHENTICATE,
        };
        it('sets isSigningIn flag to true', () => {
            expect(reducer(initialState, action).isSigningIn).toEqual(true);
        });
        it('sets failedAuthentication to false', () => {
            const state = {
                ...initialState,
                failedAuthentication: true,
            };
            expect(reducer(state, action).failedAuthentication).toEqual(false);
        });
    });

    describe('RELOAD_SESSION and AUTHENTICATION_COMPLETE reducer', () => {
        const uvaData = { entitlements: 'RW' };
        const createAction = action => ({
            type: authActionTypes[action],
            payload: {
                uvaData,
            },
        });
        ['RELOAD_SESSION', 'AUTHENTICATION_COMPLETE'].forEach(actionName => {
            const action = createAction(actionName);
            it('adds uvaData to state', () => {
                expect(reducer(initialState, action).entitlements).toEqual(uvaData.entitlements);
            });
        });
    });

    describe('ENTITLEMENTS_COMPLETE reducer', () => {
        const state = {
            isSigningIn: true,
        };
        const action = {
            type: authActionTypes.ENTITLEMENTS_COMPLETE,
            payload: {
                entitlements: 'RW',
            },
        };
        it('sets isSigningIn to false', () => {
            expect(reducer(state, action).isSigningIn).toEqual(false);
        });
        it('adds entitlements to state', () => {
            expect(reducer(state, action).entitlements).toEqual('RW');
        });
        it('sets failedAuthentication to false', () => {
            expect(reducer(state, action).failedAuthentication).toEqual(false);
        });

        describe('user is no authorised', () => {
            it('sets failedAuthentication to true', () => {
                expect(reducer(state, {
                    type: authActionTypes.ENTITLEMENTS_COMPLETE,
                    payload: {
                        entitlements: 'UNAUTHORISED',
                    },
                }).failedAuthentication).toEqual(true);
            });
        });
    });

    describe('AUTHENTICATION_ERROR reducer', () => {
        const action = {
            type: authActionTypes.AUTHENTICATION_ERROR,
        };
        const state = {
            isSigningIn: true,
            failedAuthentication: false,
        };
        it('sets isSigningIn to false', () => {
            expect(reducer(state, action).isSigningIn).toEqual(false);
        });
        it('sets failedAuthentication to true', () => {
            expect(reducer(state, action).failedAuthentication).toEqual(true);
        })
    });

    describe('SIGN_OUT reducer', () => {
        const action = {
            type: authActionTypes.SIGN_OUT,
        };
        const state = {
            isSigningIn: false,
            failedAuthentication: false,
            entitlements: 'RW',
        };
        it('resets initialState', () => {
            expect(reducer(state, action)).toEqual(initialState);
        });
    });
});
