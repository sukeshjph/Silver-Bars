import * as http from '../../helpers/http';

jest.mock('../../helpers/authentication', () => ({
    authenticationToken: () => ({
        challenge: 'Y2ZiMGFkMmMtMTg5OC00ZjBjLWI3YzgtYzJmZWIzNDI5MGNm',
        hash: 'MWExOTAzNzc5YTJjNzIyNTdjMzc2ZTBmOTI0YmI4NzBlNTI3MTY4OA==',
        user: '1395651',
        expiryDate: '2018-04-16T17:02:53+01:00',
    }),
    authenticationCredentials: () => ({
        location: 'SG',
        userDisplayName: '1395651',
        userName: '1395651',
    }),
}));
jest.mock('../../common/config', () => ({ initialise: () => undefined }));


describe('http service tests', () => {
    let mockText = JSON.stringify({
        'type': 'Scenario',
        'id': '3',
        'validFrom': '2018-02-09 09:10:09.758',
        'validTo': '9999-12-31 00:00:00.520',
        'name': 'Scenario 3',
    });    

    let mockResp = {
        status: '200',
        text: () => Promise.resolve(mockText),
    }

    window.fetch = jest.fn();
    
    describe('getData()', () => {
        
        beforeAll(() => {
            window.fetch.mockImplementation(() =>
                Promise.resolve(mockResp)
            );
        });
        
    
        it('With proper Json', done => http.default.getData('/api/endpoint').toPromise().then(res => {
            expect(window.fetch.mock.calls[0][0]).toBe('/api/endpoint');
            expect(res).toEqual(JSON.parse(mockText));
            done();
        }));
    
        it('With improper Json', done => 
        {
            mockText = '';
            return http.default.getData('/api/endpoint').toPromise().then(res => {
                expect(window.fetch.mock.calls[0][0]).toBe('/api/endpoint');
                expect(res).toEqual({});
                done();
            })
        });
    
        it('should return error when not 200', done => {
            delete mockResp.status;
            return http.default.getData('testUrl').toPromise().catch(error => {
                expect(typeof error).toBe('object');
                done();
            })
             
        });

     
        afterAll(() => {
            mockText = JSON.stringify({
                'type': 'Scenario',
                'id': '3',
                'validFrom': '2018-02-09 09:10:09.758',
                'validTo': '9999-12-31 00:00:00.520',
                'name': 'Scenario 3',        
            });
    
            mockResp = {
                status: '200',
                text: () => Promise.resolve(mockText),
            }
            window.fetch.mockRestore();
            
        });
    })
    
    describe('postData()', () => {
        const mockPostData = {
            'type': 'Batch',
            'id': '13',
            'validFrom': '2018-02-11 09:10:09.758',
            'validTo': '9999-12-31 00:00:00.520',
            'name': 'Friday',
            'scenarios': [{ ukId: '1', name: '1' }, { ukId: '2', name: '2' }],
            'ukId': 'friday',
        }
    
        beforeAll(() => {
            window.fetch.mockImplementation(() =>
                Promise.resolve(mockResp)
            );
        });
    
        it('With proper post Json', done => http.default.postData('/api/endpoint',mockPostData).toPromise().then(res => {
            expect(window.fetch.mock.calls[0][0]).toBe('/api/endpoint');
            expect(res).toEqual(JSON.parse(mockText));
            done();
        }));
    
        it('With improper post Json', done => 
        {
            mockText = '';
            return http.default.postData('/api/endpoint').toPromise().then(res => {
                expect(window.fetch.mock.calls[0][0]).toBe('/api/endpoint');
                expect(res).toEqual({});
                done();
            })
        });
    
        it('should return error when not 200 post', done => {
            delete mockResp.status;
            return http.default.postData('/api/endpoint').toPromise().catch(error => {
                expect(typeof error).toBe('object');
                done();
            })
             
        });
    
        afterAll(() => {
            mockText = JSON.stringify({
                'type': 'Scenario',
                'id': '3',
                'validFrom': '2018-02-09 09:10:09.758',
                'validTo': '9999-12-31 00:00:00.520',
                'name': 'Scenario 3',        
            });
    
            mockResp = {
                status: '200',
                text: () => Promise.resolve(mockText),
            }

            window.fetch.mockRestore();
        });
    })
})









