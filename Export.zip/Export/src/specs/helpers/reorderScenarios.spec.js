import reorderScenarios from '../../helpers/reorderScenarios';

describe('the "reorderScenarios" helper', () => {

    it('sorts scenarios by name', () => {
        const scenarios = [
            { name: 'scenario-4', ukId: 4, tags: null },
            { name: 'scenario-3', ukId: 3, tags: null },
            { name: 'scenario-1', ukId: 1, tags: null },
            { name: 'scenario-2', ukId: 2, tags: null },
        ];
        expect(reorderScenarios(scenarios, [], [])).toEqual([
            { name: 'scenario-1', ukId: 1, affectedBatches: '', tags: '' },
            { name: 'scenario-2', ukId: 2, affectedBatches: '', tags: '' },
            { name: 'scenario-3', ukId: 3, affectedBatches: '', tags: '' },
            { name: 'scenario-4', ukId: 4, affectedBatches: '', tags: '' },
        ]);
    });

    it('adds pending: true if there is a matching scenario pending approval', () => {
        const pendingScenarios = [
            { name: 'scenario-4', ukId: 4 },
        ];
        const scenarios = [
            { name: 'scenario-1', ukId: 1, tags: null },
            { name: 'scenario-2', ukId: 2, tags: null },
            { name: 'scenario-3', ukId: 3, tags: null },
            { name: 'scenario-4', ukId: 4, tags: null },
        ];
        expect(reorderScenarios(scenarios, pendingScenarios, [])).toEqual([
            { name: 'scenario-1', ukId: 1, affectedBatches: '', tags: '' },
            { name: 'scenario-2', ukId: 2, affectedBatches: '', tags: '' },
            { name: 'scenario-3', ukId: 3, affectedBatches: '', tags: '' },
            { name: 'scenario-4', ukId: 4, affectedBatches: '', tags: '', pending: true },
        ]);
    });

    it('parses string of tags into an Array', () => {
        const scenarios = [
            { name: 'scenario-1', ukId: 1, tags: 'Global, Localised, ESA' },
            { name: 'scenario-2', ukId: 2, tags: 'Global, Localised' },
            { name: 'scenario-3', ukId: 3, tags: null },
            { name: 'scenario-4', ukId: 4, tags: null },
        ];
        expect(reorderScenarios(scenarios, [], [])).toEqual([
            { name: 'scenario-1', ukId: 1, affectedBatches: '', tags: ['Global', 'Localised', 'ESA'] },
            { name: 'scenario-2', ukId: 2, affectedBatches: '', tags: ['Global', 'Localised'] },
            { name: 'scenario-3', ukId: 3, affectedBatches: '', tags: '' },
            { name: 'scenario-4', ukId: 4, affectedBatches: '', tags: '' },
        ]);
    });

    describe('affectedBatches', () => {
        const batches = [
            {name: 'Monday', scenarios: [{ukId: 1}, {ukId: 6}]},
            {name: 'Tuesday', scenarios: [{ukId: 1}, {ukId: 2}]},
            {name: 'Wednesday', scenarios: [{ukId: 4}, {ukId: 5}]},
            {name: 'Thursday', scenarios: [{ukId: 2}]},
            {name: 'Friday', scenarios: [{ukId: 1}, {ukId: 2}]},
            {name: 'non weekday', scenarios: [{ukId: 1}, {ukId: 2}, {ukId: 7}]},
            {name: 'non weekday 2', scenarios: [{ukId: 7}]},
        ];
        it('Truncates week days to three letters', () => {
            const scenarios = [
                { name: 'scenario-7', ukId: 7, tags: null },
            ];
            expect(reorderScenarios(scenarios, [], batches)).toEqual([
                { name: 'scenario-7', ukId: 7, tags: '', affectedBatches: 'non weekday, non weekday 2' },
            ]);
        });
        it('adds a list of batches which the scenario is linked to', () => {
            const scenarios = [
                {name: 'scenario-1', ukId: 1, tags: null},
                {name: 'scenario-2', ukId: 2, tags: null},
                {name: 'scenario-3', ukId: 3, tags: null},
                {name: 'scenario-4', ukId: 4, tags: null},
            ];
            expect(reorderScenarios(scenarios, [], batches)).toEqual([
                {name: 'scenario-1', ukId: 1, tags: '', affectedBatches: 'Mon, Tue, Fri, non weekday'},
                {name: 'scenario-2', ukId: 2, tags: '', affectedBatches: 'Tue, Thu, Fri, non weekday'},
                {name: 'scenario-3', ukId: 3, tags: '', affectedBatches: ''},
                {name: 'scenario-4', ukId: 4, tags: '', affectedBatches: 'Wed'},
            ]);
        });
    });
});