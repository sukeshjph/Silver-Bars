import * as dateTime from '../../helpers/dateTime';





describe('dateTime helpers', () => {
    beforeEach(() => {
        Date.now = jest.fn(() => 1528105933097); // 4th June 2018
    });
    describe('dateTime.now', () => {
        it('returns a formatted timestamp representing NOW', () => {
            expect(dateTime.now()).toBe('20180604105213');
        });
    });
    describe('dateTime.formatDateTime', () => {
        it('returns a formatted date and time string', () => {
            expect(dateTime.formatDateTime('20180604105213')).toBe('04 Jun 2018 10:52');
        });
    });
    describe('dateTime.formatDate', () => {
        it('returns a formatted date string', () => {
            expect(dateTime.formatDate('20180604105213')).toBe('04 Jun 2018');
        });
    });
});