// import 'whatwg-fetch';
// import fetchMock from 'fetch-mock';
// import configureMockStore from 'redux-mock-store';
// import { createEpicMiddleware } from 'redux-observable';
// import { expect } from 'chai';
//
// import * as actionTypes from '../constants';
// import mockFileListResponse from './mockFileListResponse';
// import {initialise, getConfig} from '../../../common/config';
// import BatchDownloadEpics from '../epics';
//
// const epicMiddleware = createEpicMiddleware(BatchDownloadEpics);
// const mockStore = configureMockStore([epicMiddleware]);
//
// describe('Batch Download Epics', () => {
//
//     beforeEach(() => {
//         initialise({
//             downloadService: 'https://dev.riskview.uk.standardchartered.com:4888/rave/api/v2/download',
//         });
//     });
//
//     afterEach(() => {
//         fetchMock.restore();
//     });
//
//     it('fetches a list of files', (done) => {
//         fetchMock.get(`${getConfig().DownloadService}/list`, mockFileListResponse.FILE_LIST);
//
//         const store = mockStore({});
//         const inputAction = { type: actionTypes.FETCH_FILE_LIST };
//         store.dispatch(inputAction);
//
//         setTimeout(() => {
//             const dispatched = store.getActions();
//             expect(dispatched).to.deep.equal([
//                 inputAction,
//                 {
//                     type: actionTypes.FETCH_FILE_LIST_COMPLETE,
//                     payload: mockFileListResponse,
//                 },
//             ]);
//             done();
//         }, 0);
//     });
// });

it('should work', () => undefined);
