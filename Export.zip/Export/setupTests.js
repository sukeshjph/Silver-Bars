/* eslint-disable import/no-extraneous-dependencies */
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import requestAnimationFrame from './tempPolyfills';//eslint-disable-line

Enzyme.configure({ adapter: new Adapter(), disableLifecycleMethods: true });
