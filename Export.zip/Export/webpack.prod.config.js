const merge = require('webpack-merge');
const CleanWebpackPlugin = require('clean-webpack-plugin');
const generateBaseConfig = require('./packaging/webpack.base.config');
const production = require('./packaging/webpack.prod.base.config');

module.exports = merge(
    generateBaseConfig(
        {
            app: ['./src/index.js'],
        },
        __dirname,
        'production',
        [new CleanWebpackPlugin(['dist']), ...production.plugins],
    ),
    production.config,
);
