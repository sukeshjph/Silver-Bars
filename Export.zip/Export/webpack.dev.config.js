const merge = require('webpack-merge');
const path = require('path');
const webpack = require('webpack');
// const ForkTsCheckerWebpackPlugin = require('fork-ts-checker-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const generateBaseConfig = require('./packaging/webpack.base.config');

const developConfig = {
    devtool: 'eval-source-map',
    output: {
        crossOriginLoading: 'anonymous',
    },
    devServer: {
        contentBase: path.resolve(__dirname, 'dist'),
        stats: { children: false },
        hot: true,
        compress: true,
        port: 9000,
        historyApiFallback: true,
        open: 'Chrome',
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH, OPTIONS',
            'Access-Control-Allow-Headers': 'X-Requested-With, content-type, Authorization',
        },
        proxy: {
            '/api2': {
                target: 'http://uklpadsab104a:9401/api',
                secure: false,
                changeOrigin: true,
            },
        },
    },
    /* keeping below configs for testing tree shaking in dev mode */
    optimization: {
        usedExports: false,
        sideEffects: false,
    },
};

module.exports = merge(
    generateBaseConfig(
        {
            app: ['./src/index.js'],
        },
        __dirname,
        'development',
        [
            new HtmlWebpackPlugin({
                template: './src/index.html',
                inject: true,
                hash: true,
                filename: 'index.html',
            }),
            new webpack.HotModuleReplacementPlugin(),
            // new ForkTsCheckerWebpackPlugin({
            //     reportFiles: ['src/**/*.{ts,tsx}', '!src/skip.ts'],
            //     watch: ['src/**'],
            // }),
            new webpack.DefinePlugin({
                ISLOCAL: JSON.stringify(true),
            }),
        ],
    ),
    developConfig,
);
