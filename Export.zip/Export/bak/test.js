/* eslint-disable */
import ReactPlaceholder from 'react-placeholder';
import 'react-placeholder/lib/reactPlaceholder.css';

<ReactPlaceholder
    ready={!isFetchingBatchesByDate}
    customPlaceholder={BatchListPlaceholder}
    showLoadingAnimation
    delay={800}
    key={shortid.generate()}
>
    <BatchList
        batchList={this.getBatchListByDay(day.date, batchesByDate)}
        isFetchingPastBatchesProgress={isFetchingPastBatchesProgress}
        allbatchesStatus={allbatchesStatus}
        pastBatchesProgress={pastBatchesProgress}
        batchDate={day.date}
    />
</ReactPlaceholder>;
