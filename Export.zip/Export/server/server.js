const express = require('express');
// const request = require('request');
// const url = require('url');
const cors = require('cors');
const config = require('./config');
const batchResponse = require('./mocks/batchScheduleResponse');

const app = express();
app.use(cors());

// app.use('/', (req, res) => {
//     const parsedUrl = url.parse(req.url);
//     req.pipe(
//         request({
//             uri: `${config.downloadService}?${parsedUrl.query}`,
//         }),
//     ).pipe(res);
// });

app.get('/batchmanagement/batchesToRun', (req, res) => {
    res.send(batchResponse);
});

// Start the server by listening on a port
app.listen(config.port, () => {
    console.log('+---------------------------------------+');
    console.log('|                                       |');
    console.log(
        `|  [\x1b[34mSERVER\x1b[37m] Listening on port: \x1b[36m${config.port} 🤖  \x1b[37m |`,
    );
    console.log('|                                       |');
    console.log('\x1b[37m+---------------------------------------+');
});
