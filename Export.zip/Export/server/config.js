const config =  {
    downloadService: 'http://10.193.29.168:9091/api/1/datasets/list',
    port: process.env.PORT || 3000,
};

module.exports = config;