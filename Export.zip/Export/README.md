# Stress UI


## Getting Started

The only pre-requisite is node JS.

You need to update your npm config with the following three commands:
1. npm config set http-proxy http://10.192.116.73:8080/
2. npm config set https-proxy http://10.192.116.73:8080/
3. npm config set @scb:registry https://artifactory.global.standardchartered.com/artifactory/api/npm/npm-release

Install all dependencies:
```
npm install
```

## Start the application

```
npm run devs
```

The application will now be running on http://localhost:8080 and you can log in at http://localhost:8080/?#/mrStressTesting

To kick off the testing run:

```
npm run test
```

To see the deployment output within the "lib" directory run:

```
npm run lib
```